/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. and/or its licensors.
 * Without the prior written permission of MediaTek inc. and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 */
/* MediaTek Inc. (C) 2010. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER ON
 * AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek Software")
 * have been modified by MediaTek Inc. All revisions are subject to any receiver's
 * applicable license agreements with MediaTek Inc.
 */

#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <fcntl.h>
#include <errno.h>
#include <pthread.h>
#include <sys/mount.h>
#include <sys/statfs.h>
#include <sys/types.h>
#include <sys/wait.h>

#include "cust_mcard.h"
#include "common.h"
#include "miniui.h"
#include "ftm.h"

#ifdef FEATURE_FTM_MEMORY

#define TAG                 "[MEMORY] "
#define mod_to_mts_data(p) (struct mts_data*)((char*)(p) + sizeof(struct ftm_module))

enum {
   
    ITEM_PASS,
    ITEM_FAIL,
};

static item_t mtest_items[] = {
    item(ITEM_PASS,   uistr_pass),
    item(ITEM_FAIL,   uistr_fail),
    item(-1, NULL),
};

struct mts_data
{
    /*common for each factory mode*/
    char  info[4096];
    //bool  avail;
    bool  exit_thd;

    text_t    title;
    text_t    text;
    text_t    left_btn;
    text_t    center_btn;
    text_t    right_btn;
    
    pthread_t update_thd;
    struct ftm_module *mod;
    //struct textview tv;
    struct itemview *iv;	
};

#include <fcntl.h>
#define CMDLINE_PATH "/proc/jlink_hwinfo"
#define CMDLINE_MAX_SIZE 256

static int getHardwareInfoFor(int infoId) {
	char buffer[CMDLINE_MAX_SIZE];
	int i = 0;
	int info = 0;
	memset(buffer, 0, CMDLINE_MAX_SIZE);
	int fd = open(CMDLINE_PATH, 0);
	if (fd != -1) {
		int size = read(fd, buffer, CMDLINE_MAX_SIZE);
		if (size > 0) {
			info = buffer[infoId];
		}
		close(fd);
		return info;
	}
	return 0;
}

static bool thread_exit = false;
static void *mtest_update_iv_thread(void *priv)
{
    struct mts_data *dat = (struct mts_data *)priv; 
    struct itemview *iv = dat->iv;    
    int err = 0, len = 0,l=0;
    char *status;
    int cnt=0;
    char *cmd=NULL;
    cmd = malloc(128);    
	//mem_test  -M 650  -s 10 -m 4 -C 4 -W
    char mtscmd[]="mem_test -s 10 -m 4 -C 4 -W\0 ";
    memset(cmd,'\0',128);
    //cmd = ftm_get_prop("mtest");
    if(NULL == cmd || strlen(cmd)<10)
		memcpy(cmd,mtscmd,sizeof(mtscmd));

    //bsp hack for modify mem test time
    if (getHardwareInfoFor(20)>1 && getHardwareInfoFor(20) < 18) {
           memset(cmd,'\0',128);
           snprintf(cmd, 128, "mem_test -s %d -m 4 -C 4 -W\0 ", getHardwareInfoFor(20)*10);
    }
    printf("----------command:%s\n", cmd);
    char *buf=NULL;
    buf = malloc(64);
    //char buffer[128]="********************************\n";
    memset(buf,'\0',64);	
    memset(&dat->info[0],0x0,sizeof(&dat->info[0]));
    char ispass[]="PASS";
    char isfail[] = "Report";
    char zeroerror[] ="0 errors";
    LOGD(TAG "%s: Start\n", __FUNCTION__);
     iv->set_text(iv, &dat->text);
     iv->redraw(iv);
     FILE *pf;	
     pf = popen((const char*)cmd,"r");	
    while (fgets(buf,64,pf)!=NULL)
    {
        if (dat->exit_thd)
            break;
	if(strstr(buf,ispass)!=NULL)
		dat->mod->test_result = FTM_TEST_PASS;
	if(strstr(buf,isfail)!=NULL)
		dat->mod->test_result = FTM_TEST_FAIL;
	if(len>=4000)
		len=0;
	 memcpy(&dat->info[0]+len,buf,strlen(buf));
	 len = len+ strlen(buf);
        iv->redraw(iv);
	memset(buf,'\0',64);
	int status = get_is_ata();
        if(status == 1)
        { 
            thread_exit = true;  
            break;
        }
		    
    }
    //mtest_close(mts);
    LOGD(TAG "%s: Exit\n", __FUNCTION__);    
    pthread_exit(NULL);    
    return NULL;
}

int mtest_entry(struct ftm_param *param, void *priv)
{
    char *ptr;
    int chosen;
    struct mts_data *dat = (struct mts_data *)priv;
    struct textview *tv;
    struct itemview *iv;
    //struct statfs stat;
    int err;

    LOGD(TAG "%s\n", __FUNCTION__);

    init_text(&dat->title, param->name, COLOR_YELLOW);
    init_text(&dat->text, &dat->info[0], COLOR_YELLOW);
    init_text(&dat->left_btn, uistr_info_fail, COLOR_YELLOW);
    init_text(&dat->center_btn, uistr_info_pass, COLOR_YELLOW);
    init_text(&dat->right_btn, uistr_info_sensor_back, COLOR_YELLOW);
       
    snprintf(dat->info, sizeof(dat->info), uistr_info_sensor_initializing);
    dat->exit_thd = false;  

    if (!dat->iv) {
        iv = ui_new_itemview();
        if (!iv) {
            LOGD(TAG "No memory");
            return -1;
        }
        dat->iv = iv;
    }
    iv = dat->iv;
    iv->set_title(iv, &dat->title);
    iv->set_items(iv, mtest_items, 0);
    iv->set_text(iv, &dat->text);

    pthread_create(&dat->update_thd, NULL, mtest_update_iv_thread, priv);
    do {
        if(get_is_ata() != 1){
        chosen = iv->run(iv, &thread_exit);
        switch (chosen) {
        case ITEM_PASS:
        case ITEM_FAIL:
            if (chosen == ITEM_PASS) {
                //dat->mod->test_result = FTM_TEST_PASS;
                ;
            } else if (chosen == ITEM_FAIL) {
                dat->mod->test_result = FTM_TEST_FAIL;
            } 
            thread_exit = true;              
            break;
        }
        }
        iv->redraw(iv);
        if (thread_exit) {
            dat->exit_thd = true;
            break;
        }        
    } while (1);
    pthread_join(dat->update_thd, NULL);

    return 0;
}


int mtest_init(void)
{
    int ret = 0;
    struct ftm_module *mod;
    struct mts_data *dat;

    LOGD(TAG "%s\n", __FUNCTION__);
    
    mod = ftm_alloc(ITEM_MEMORY, sizeof(struct mts_data));
    dat  = mod_to_mts_data(mod);

    memset(dat, 0x00, sizeof(*dat));
    //mtest_init_priv(&dat->lps);
        
    /*NOTE: the assignment MUST be done, or exception happens when tester press Test Pass/Test Fail*/    
    dat->mod = mod; 
    
    if (!mod)
        return -ENOMEM;

    ret = ftm_register(mod, mtest_entry, (void*)dat);

    return ret;
}

#endif
