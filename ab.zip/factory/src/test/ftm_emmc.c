/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. and/or its licensors.
 * Without the prior written permission of MediaTek inc. and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 */
/* MediaTek Inc. (C) 2010. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER ON
 * AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek Software")
 * have been modified by MediaTek Inc. All revisions are subject to any receiver's
 * applicable license agreements with MediaTek Inc.
 */

#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <fcntl.h>
#include <pthread.h>
#include <sys/mount.h>
#include <sys/statfs.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/reboot.h>
//#include "include/linux/mmc/sd_misc.h"
#include "common.h"
#include "miniui.h"
#include "ftm.h"
#include "mounts.h"
#include "make_ext4fs.h"

#include <selinux/selinux.h>
#include <selinux/label.h>
#include <selinux/android.h>
#include <cutils/properties.h>

#include <fs_mgr.h>

#ifdef FEATURE_FTM_EMMC
extern sp_ata_data return_data;

#define TAG                 "[EMMC] "
#define DATA_MEDIA_PARTITION "/data/media"
#define DATA_PARTITION      "/data"
#define NVDATA_PARTITION    "/nvdata"
/* should be moved to customized part */
#define MAX_NUM_SDCARDS     (3)
#define MIN_SDCARD_IDX      (0)
#define MAX_SDCARD_IDX      (MAX_NUM_SDCARDS + MIN_SDCARD_IDX - 1)

#define FSTAB_PREFIX "/fstab."
#define MAX_SERVICE_CNT (16)
#define MAX_SERVICE_LEN (32)
struct fstab *fstab;

char g_data_related_services[MAX_SERVICE_CNT][MAX_SERVICE_LEN] = {
	"mobile_log_d",
	"mnld",
	"NULL"
};

typedef unsigned int u32;
enum {
	ITEM_PASS,
	ITEM_FAIL,
};
typedef unsigned long long u64;

static item_t emmc_items[] = {
	//    item(ITEM_PASS,   uistr_pass),
	//    item(ITEM_FAIL,   uistr_fail),
	item(-1, NULL),
};

static item_t emmc_items_manu[] = {
#ifndef FEATURE_FTM_TOUCH_MODE
	item(ITEM_PASS,   uistr_pass),
	item(ITEM_FAIL,   uistr_fail),
#endif
	item(-1, NULL),
};


int g_test_result_emmc = 0;

struct emmc {
	int id;
	char sys_path[512];
	char info[1024];
	u32 csd[4];
	unsigned char ext_csd[512];
	unsigned int capacity;
	unsigned int boot_size;
	bool avail;

	text_t title;
	text_t text;
	bool exit_thd;
	pthread_t update_thd;
	struct ftm_module *mod;
	struct itemview *iv;
};

//#define DEVICE_PATH "/dev/misc-sd"
//#define DEVICE_PATH "/dev/simple-mt6573-sd0"


#define UNSTUFF_BITS(resp,start,size)					\
	({								\
		const int __size = size;				\
		const u32 __mask = (__size < 32 ? 1 << __size : 0) - 1;	\
		const int __off = 3 - ((start) / 32);			\
		const int __shft = (start) & 31;			\
		u32 __res;						\
									\
		__res = resp[__off] >> __shft;				\
		if (__size + __shft > 32)				\
			__res |= resp[__off-1] << ((32 - __shft) % 32);	\
		__res & __mask;						\
	})

#define mod_to_emmc(p)  (struct emmc*)((char*)(p) + sizeof(struct ftm_module))

#define FREEIF(p)   do { if(p) free(p); (p) = NULL; } while(0)


static bool emmc_avail(struct emmc *mc)
{
	char name[20];
	char *ptr;
	DIR *dp;
	struct dirent *dirp;

	if (mc->id < MIN_SDCARD_IDX || mc->id > MAX_SDCARD_IDX)
		return false;

	sprintf(name, "mmc%d", mc->id - MIN_SDCARD_IDX);

	ptr  = &(mc->sys_path[0]);
	ptr += sprintf(ptr, "/sys/class/mmc_host/%s", name);

	if (NULL == (dp = opendir(mc->sys_path)))
		goto error;

	while (NULL != (dirp = readdir(dp))) {
		if (strstr(dirp->d_name, name)) {
			ptr += sprintf(ptr, "/%s", dirp->d_name);
			break;
		}
	}

	closedir(dp);

	if (!dirp)
		goto error;

	return true;

error:
	return false;
}

static void emmc_update_info(struct emmc *mc, char *info)
{
	char *ptr;
	bool old_avail = mc->avail;
	int inode = 0;
	u64 e_size = 0;
	g_test_result_emmc = 0;  /* 0: test no pass, 1: test pass */
	char buf[1024];
	ssize_t pemmcsize;

	mc->avail = emmc_avail(mc);

	inode = open("/sys/class/block/mmcblk0/size", O_RDONLY);
	if (inode < 0) {
		printf("open error!\n");
		return;
	}

	memset(buf, 0, sizeof(buf));
	pemmcsize = read(inode, buf, sizeof(buf) - 1);
	e_size = atol(buf);

	mc->capacity      = (float)(e_size * 512 / 1024);
	close(inode);

	ptr  = info;
	ptr += sprintf(ptr, "%s\n",uistr_info_emmc);

	ptr += sprintf(ptr, "%s: %s\n", uistr_info_emmc_sd_avail,mc->avail ? uistr_info_emmc_sd_yes : uistr_info_emmc_sd_no);
	ptr += sprintf(ptr, "%s: %.2f GB\n",uistr_info_emmc_sd_total_size,
		(float)(mc->capacity)/(1024*1024));
	return_data.emmc.capacity=(float)(mc->capacity)/(1024*1024);
	g_test_result_emmc = 1;  /* all things done, mark successful */
	return;
}

static void *emmc_update_iv_thread(void *priv)
{
	struct emmc *mc = (struct emmc *)priv;
	struct itemview *iv = mc->iv;
	struct statfs stat;
	int count = 1, chkcnt = 10;
	int index = 0;

	LOGD(TAG "%s: Start\n", __FUNCTION__);

 	/*
 	while (1) {
		usleep(100000);
		chkcnt--;

		if (mc->exit_thd)
			break;

		if (chkcnt > 0)
			continue;

		chkcnt = 10;

		emmc_update_info(mc, mc->info);
		iv->redraw(iv);
		mc->exit_thd = true;
	}
	*/
	//pthread_exit(NULL);
	emmc_update_info(mc, mc->info);
	iv->start_menu(iv,0);
	iv->redraw(iv);

	LOGD(TAG "%s: Exit\n", __FUNCTION__);

	return NULL;
}

int emmc_entry(struct ftm_param *param, void *priv)
{
	char *ptr;
	int chosen;
	int index = 0;
	bool exit = false;
	struct emmc *mc = (struct emmc *)priv;
	struct itemview *iv;
	struct statfs stat;

	LOGD(TAG "%s\n", __FUNCTION__);

	init_text(&mc->title, param->name, COLOR_YELLOW);
	init_text(&mc->text, &mc->info[0], COLOR_YELLOW);

	emmc_update_info(mc, mc->info);

	mc->exit_thd = false;

	if (!mc->iv) {
		iv = ui_new_itemview();
		if (!iv) {
			LOGD(TAG "No memory");
			return -1;
		}
		mc->iv = iv;
	}

	iv = mc->iv;
	iv->set_title(iv, &mc->title);
	if (FTM_AUTO_ITEM == param->test_type) {
		iv->set_items(iv, emmc_items, 0);
	} else {
#ifdef FEATURE_FTM_TOUCH_MODE
		text_t lbtn ;
		text_t cbtn ;
		text_t rbtn ;
		init_text(&lbtn, uistr_key_fail, COLOR_YELLOW);
		init_text(&cbtn, uistr_key_back, COLOR_YELLOW);
		init_text(&rbtn, uistr_key_pass, COLOR_YELLOW);
		iv->set_btn(iv, &lbtn, &cbtn, &rbtn);
#endif
		iv->set_items(iv, emmc_items_manu, 0);
	}
	iv->set_text(iv, &mc->text);
	iv->start_menu(iv,0);
	iv->redraw(iv);

	if (FTM_AUTO_ITEM == param->test_type) {
		emmc_update_iv_thread(priv);
	} else if(FTM_MANUAL_ITEM == param->test_type) {
		pthread_create(&mc->update_thd, NULL, emmc_update_iv_thread, priv);
		do {
			chosen = iv->run(iv, &exit);

			switch (chosen) {
#ifndef FEATURE_FTM_TOUCH_MODE
				case ITEM_PASS:
				case ITEM_FAIL:
					if (chosen == ITEM_PASS) {
						mc->mod->test_result = FTM_TEST_PASS;
					} else if (chosen == ITEM_FAIL) {
						mc->mod->test_result = FTM_TEST_FAIL;
					}
					exit = true;
					break;
#endif
#ifdef FEATURE_FTM_TOUCH_MODE
				case L_BTN_DOWN:
					mc->mod->test_result = FTM_TEST_FAIL;
					exit = true;
					break;
				case C_BTN_DOWN:
					exit = true;
					break;
				case R_BTN_DOWN:
					mc->mod->test_result = FTM_TEST_PASS;
					exit = true;
					break;
#endif
			}

			if (exit) {
				mc->exit_thd = true;
				break;
			}

		} while (1);
		pthread_join(mc->update_thd, NULL);
	}

	if (g_test_result_emmc > 0) {
		mc->mod->test_result = FTM_TEST_PASS;
	} else {
		mc->mod->test_result = FTM_TEST_FAIL;
	}

	return 0;
}

int emmc_init(void)
{
	int ret = 0;
	int index = 0;
	struct ftm_module *mod;
	struct emmc *mmc = NULL;

	LOGD(TAG "%s\n", __FUNCTION__);

	mod = ftm_alloc(ITEM_EMMC, sizeof(struct emmc));
	if (!mod)
		return -ENOMEM;
	mmc  = mod_to_emmc(mod);

	mmc->mod      = mod;
#ifdef MTK_EMMC_SUPPORT
	mmc->id       = 0;
#endif
	mmc->avail    = false;

	emmc_update_info(mmc, mmc->info);

	ret = ftm_register(mod, (ftm_entry_fn)emmc_entry, (void*)mmc);

	return ret;
}

#endif

/*nfy add for clear emmc*/
#ifdef FEATURE_FTM_CLEAREMMC
int ensure_all_mount_point_unmounted(const char *root_path)
{
	const MountedVolume *volume;
	LOGE(TAG "ensure_all_mount_point_unmounted %s\n", root_path);
	while (1) {
		scan_mounted_volumes();
		volume = find_mounted_volume_by_device(root_path);
		if (volume == NULL)
			break;
		LOGE(TAG "unmount %s for %s\n", volume->mount_point, root_path);
		if (unmount_mounted_volume(volume) < 0) {
			sleep(2);
			LOGE(TAG "unmount fail: %s\n", strerror(errno));
			ui_printf("unmount %s fail: %s\n", volume->mount_point, strerror(errno));
			return -1;
		}
	}
	return 0;
}

int ensure_root_path_unmounted(const char *root_path)
{
	/* See if this root is already mounted. */
	int ret = scan_mounted_volumes();
	if (ret < 0) {
		LOGE(TAG "scan_mounted_volumes result %d\n", ret);
		return ret;
	}

	const MountedVolume *volume;
	volume = find_mounted_volume_by_mount_point(root_path);
	if (volume == NULL) {
		/* It's not mounted. */
		LOGE(TAG "The path %s is unmounted\n", root_path);
		return 0;
	}

	return unmount_mounted_volume(volume);
}

static int read_fstab(void)
{
	char fstab_filename[PROPERTY_VALUE_MAX + sizeof(FSTAB_PREFIX)];
	char propbuf[PROPERTY_VALUE_MAX];

	property_get("ro.hardware", propbuf, "");
	snprintf(fstab_filename, sizeof(fstab_filename), FSTAB_PREFIX"%s", propbuf);

	fstab = fs_mgr_read_fstab(fstab_filename);
	if (!fstab) {
		SLOGE("failed to open %s\n", fstab_filename);
		return -1;
	}

	return 0;
}

static char *get_device_path_in_fstab(const char *partition)
{
	struct fstab_rec *rec = NULL;
	char *source = NULL;

	rec = fs_mgr_get_entry_for_mount_point(fstab, partition);
	if (!rec) {
		SLOGE("failed to get entry for %s\n", partition);
		return NULL;
	}

	asprintf(&source, "%s", rec->blk_device);
	return source;
}

static int free_fstab(void)
{
	fs_mgr_free_fstab(fstab);
	return 0;
}

static char *get_device_path(const char *partition)
{
	char *path = NULL;
	read_fstab();
	path = get_device_path_in_fstab(partition);
	free_fstab();
	return path;
}

static bool is_permissive(void)
{
	int rc;
	bool result = false;

	rc = is_selinux_enabled();
	if (rc < 0) {
		printf("%s is_selinux_enabled() failed (%s)\n", __FUNCTION__, strerror(errno));
		return false;
	}
	if (rc == 1) {
		rc = security_getenforce();
		if (rc < 0) {
			printf("%s getenforce fail (%s)\n", __FUNCTION__, strerror(errno));
			return false;
		}
		if (rc == 0)
			result = true;
		else
			result = true;
	}
	return result;
}

static void list_services_usage(const char *root)
{
	DIR *dir_proc, *dir_fd;
	int fd;
	int len, len_process_cmd;
	char buf_fd_link[1025] ="";
	char process_cmd[1025] ="";
	char path_buf[1025] ="";
	struct dirent *ent_proc, *ent_fd;

	LOGD("list_services_usage\n");

	if (!is_permissive()) {
		LOGE("Can not query services which are using %s in enforcing mode, please set selinux to permissive to get this message\n", root);
		return;
	}

	dir_proc = opendir("/proc/");
	if (dir_proc) {
		while ((ent_proc = readdir(dir_proc)) != NULL) {
			if (ent_proc->d_name[0] >= '0' && ent_proc->d_name[0] <= '9') {
				snprintf(path_buf, sizeof(path_buf), "/proc/%s/cmdline", ent_proc->d_name);
				fd = open(path_buf, O_RDONLY);
				if (fd != -1) {
					len_process_cmd = read(fd, process_cmd, sizeof(process_cmd)-1);
					close(fd);
					snprintf(path_buf, sizeof(path_buf), "/proc/%s/fd", ent_proc->d_name);
					dir_fd = opendir(path_buf);
					if (dir_fd) {
						while ((ent_fd = readdir(dir_fd)) != NULL) {
							snprintf(path_buf, sizeof(path_buf), "/proc/%s/fd/%s", ent_proc->d_name, ent_fd->d_name);
							len = readlink(path_buf, buf_fd_link, sizeof(buf_fd_link)-1);
							if (len != -1) {
								if (strstr(buf_fd_link, root) == buf_fd_link) {
									if (len_process_cmd)
										LOGD(TAG "process(%s):%s\n", ent_proc->d_name, process_cmd);
									LOGD(TAG "file in used: %s\n", buf_fd_link);
								}
							}
						}
						closedir(dir_fd);
					}
				}
			}
		}
		closedir(dir_proc);
	}
}

int format_root_device(const char *root)
{
	int ret = 0, result;
	struct stat statbuf;
	char *device_path = NULL;
	struct selabel_handle *sehnd;
	struct selinux_opt seopts[] = {
		{ SELABEL_OPT_PATH, "/file_contexts" }
	};

	memset(&statbuf,0,sizeof(statbuf));
	/* Don't try to format a mounted device. */
	LOGD(TAG"ensure root patch unmounted\n");
	result = ensure_root_path_unmounted(root);
	if (result < 0) {
		LOGE(TAG"format_root_device: can't unmount \"%s\"\n", root);
		sleep(2);
		ui_printf("eMMC is busy can't format, please retry\n");
		list_services_usage(root);
		ret = -1;
		goto out_without_free;
	}

	sehnd = selabel_open(SELABEL_CTX_FILE, seopts, 1);

	device_path = get_device_path(root);
	if (!device_path) {
		LOGE("format_volume: error when get device path");
		ret = -2;
		goto out_without_free;
	}
	LOGE("[MSDC_DEBUG] data device path: %s\n", device_path);

	if (0 != make_ext4fs(device_path, 0, root, sehnd)) {
		LOGE("format_volume: make_extf4fs failed on %s\n", device_path);
		ret = -3;
	}

	free(device_path);

out_without_free:

	return ret;
}

static void stop_data_related_services() {
	int i;
	char cmd[MAX_SERVICE_LEN + 6]; //len("stop " + "\0") = 6

	for (i = 0; i < MAX_SERVICE_CNT; i++) {
		if (!strcmp(g_data_related_services[i], "NULL"))
			break;
		snprintf(cmd, sizeof(cmd) - 1, "stop %s", g_data_related_services[i]);
		LOGE(TAG "stopping service with command: %s\n", cmd);
		if (system(cmd) < 0)
			LOGE(TAG "%s fail: %s\n", cmd, strerror(errno));
	}
}

int clear_emmc_entry(struct ftm_param *param, void *priv)
{
	int result = 0, cnt = 0;

	ui_printf("%s\n",uistr_info_emmc_format_data_start);
	sleep(1);

	stop_data_related_services();

	/* /data/media might mounted after ensure_all_mount_point_unmounted before format_root_device(DATA_PARTITION)
	 * which will cause data partition unmount fail, add retry to make sure /data/media and /data are both unmount successfully
	 */
	while (cnt++ <= 3) {
		result = ensure_all_mount_point_unmounted(DATA_MEDIA_PARTITION);
		result += format_root_device(DATA_PARTITION);
		if (result)
			sleep(1);
		else
			break;
	}
	if (result) {
		sleep(5);
		return false;
	}
	sync();

	result = format_root_device(NVDATA_PARTITION);
	if (result) {
		if (result == -2) {
			LOGE("has no device path: \"%s\"\n", NVDATA_PARTITION);
		} else {
			sleep(5);
			return false;
		}
	}
	sync();
	sleep(1);
	reboot(RB_AUTOBOOT);

	return result;
}

int clear_emmc_init(void)
{
	int ret = 0;
	int index = 0;
	struct ftm_module *mod;
	struct emmc *mmc = NULL;

	mod = ftm_alloc(ITEM_CLREMMC, sizeof(struct emmc));
	if (!mod)
		return -ENOMEM;
	mmc = mod_to_emmc(mod);

	ret = ftm_register(mod, (ftm_entry_fn)clear_emmc_entry, (void*)mmc);
	return ret;
}
#endif
