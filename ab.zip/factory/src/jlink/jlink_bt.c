#include "jlinkui.h"
#include <dlfcn.h>
#include "ftm.h"

#ifndef BOOL
#define BOOL     bool
#endif
#ifndef FALSE
#define FALSE    0
#endif
#ifndef TRUE
#define TRUE     1
#endif

static int btrunning = 0;

typedef unsigned char UCHAR;
typedef unsigned char UINT8;
typedef unsigned short UINT16;
typedef unsigned int UINT32;
typedef int (*INIT)(void);
typedef int (*WRITE)(int fd, unsigned char *buf, unsigned int len);
typedef int (*READ)(int fd, unsigned char *buf, unsigned int len);

//extern void updateTextInfo(TEST_INFO_T *pTest, char *output_buf, int buf_len);
//extern BOOL FM_BT_init(void);
//extern BOOL FM_BT_inquiry(void);
//extern void FM_BT_deinit(void);
typedef struct _BT_INFO_T {
  struct _BT_INFO_T *pNext;
  UCHAR  btaddr[6];
  UCHAR  psr;
  UCHAR  cod[3];
  UCHAR  clkoffset[2];
  int    rssi;
  UCHAR  name[248];
} BT_INFO_T;

typedef struct {
  int test_type;
  int test_result;
} TEST_INFO_T;

typedef struct _BT_HCI_EVENT_T {
  UINT8 event;
  UINT8 len;
  UINT8 status;
  UINT8 parms[256];
} BT_HCI_EVENT_T;


enum {
  TEST_RESULT_UNKNOWN = 0,
  TEST_RESULT_PASS,
  TEST_RESULT_FAIL,
};

typedef int (*DEINIT)(int fd);

static TEST_INFO_T bf_test;
static BT_INFO_T *g_pBtListHear = NULL;
static BOOL  g_inquiry_complete = FALSE;
static BOOL  g_scan_complete = FALSE;
static BOOL fgKillThread = FALSE;
static pthread_t rxThread;
static void *glib_handle = NULL;
static int   bt_fd = -1;
static DEINIT  bt_restore = NULL;
static INIT    bt_init = NULL;
static WRITE   bt_send_data = NULL;
static READ    bt_receive_data = NULL;

static void updateTextInfo(TEST_INFO_T *pTest, char *output_buf, int buf_len)
{
    char cBuf[1024];
    static int loop = 0;
    BT_INFO_T *pBtInfo = NULL;

    memset(cBuf, 0, sizeof(cBuf));

    if (g_pBtListHear == NULL) {
        if (g_inquiry_complete == FALSE)
            snprintf(cBuf, sizeof(cBuf), "%s", uistr_info_bt_inquiry_start);
        else {
            /* Can not find any device */
            snprintf(cBuf, sizeof(cBuf), "%s", uistr_info_bt_no_dev);
            //if (FTM_MANUAL_ITEM != pTest->test_type)
                pTest->test_result = TEST_RESULT_FAIL;
        }
    } else if (g_scan_complete == FALSE) {

        if (g_inquiry_complete == FALSE) {
            if (loop == 0) {
                snprintf(cBuf, sizeof(cBuf), "%s", uistr_info_bt_inquiry_1);
                loop = 1;
            } else {
                snprintf(cBuf, sizeof(cBuf), "%s", uistr_info_bt_inquiry_2);
                loop = 0;
            }
        } else {
            if (loop == 0) {
                snprintf(cBuf, sizeof(cBuf), "%s", uistr_info_bt_scan_1);
                loop = 1;
            } else {
                snprintf(cBuf, sizeof(cBuf), "%s", uistr_info_bt_scan_2);
                loop = 0;
            }
        }
    } else
        snprintf(cBuf, sizeof(cBuf), "%s", uistr_info_bt_scan_complete);

    pBtInfo = g_pBtListHear;

    while (pBtInfo) {
        if (strlen((const char*)pBtInfo->name)) {
            int str_len = 0;
            str_len = strlen((const char*)pBtInfo->name);

            strncpy(cBuf  + strlen(cBuf), (const char*)pBtInfo->name, 12);
            if (str_len < 12)
                strncpy(cBuf  + strlen(cBuf), "            ", 12 - str_len);

            snprintf(cBuf  + strlen(cBuf), sizeof(cBuf) - strlen(cBuf), " %d\n", pBtInfo->rssi);
            
        }
        else {
            /* Inquiry result */
            snprintf(cBuf  + strlen(cBuf), sizeof(cBuf) - strlen(cBuf), "%02x%02x%02x%02x%02x%02x %d\n",
                     pBtInfo->btaddr[0], pBtInfo->btaddr[1], pBtInfo->btaddr[2],
                     pBtInfo->btaddr[3], pBtInfo->btaddr[4], pBtInfo->btaddr[5],
                     pBtInfo->rssi);
        }

        pBtInfo = pBtInfo->pNext;
    }

    if (g_pBtListHear) {
        if (g_scan_complete == FALSE) {
            if (g_inquiry_complete == TRUE)
                snprintf(cBuf + strlen(cBuf), sizeof(cBuf) - strlen(cBuf), "%s", uistr_info_bt_dev_list_end);
        } else {
            snprintf(cBuf + strlen(cBuf), sizeof(cBuf) - strlen(cBuf), "%s", uistr_info_bt_scan_list_end);
            //if (FTM_MANUAL_ITEM != pTest->test_type)
                pTest->test_result = TEST_RESULT_PASS;
        }
    }

    memcpy(output_buf, cBuf, strlen(cBuf) + 1);
    return;
}

static void FM_BT_deinit(void)
{
    BT_INFO_T *pBtInfo = NULL;
    /* Stop RX thread */
    fgKillThread = TRUE;
    /* Wait until thread exit */
    pthread_join(rxThread, NULL);

    if (!glib_handle)
        LOGE("mtk bt library is unloaded!\n");
    else {
        if (bt_fd < 0)
            LOGE("bt driver fd is invalid!\n");
        else {
            bt_restore(bt_fd);
            bt_fd = -1;
        }
        dlclose(glib_handle);
        glib_handle = NULL;
    }

    /* Clear globals */
    while (g_pBtListHear) {
        pBtInfo = g_pBtListHear;
        g_pBtListHear = g_pBtListHear->pNext;
        free(pBtInfo);
    }

    g_inquiry_complete = FALSE;
    g_scan_complete = FALSE;

    return;
}

static BOOL BT_Inquiry(void)
{
    UINT8 HCI_INQUIRY[] =
        {0x01, 0x01, 0x04, 0x05, 0x33, 0x8B, 0x9E, 0x05, 0x0A};
    char *config_val = NULL;

    config_val = ftm_get_prop("BT.DeviceNumber");
    if (config_val != NULL) {
        HCI_INQUIRY[8] = (UINT8)atoi(config_val);
    }

    if (!glib_handle) {
        LOGE("mtk bt library is unloaded!\n");
        return FALSE;
    }
    if (bt_fd < 0) {
        LOGE("bt driver fd is invalid!\n");
        return FALSE;
    }

    if (bt_send_data(bt_fd, HCI_INQUIRY, sizeof(HCI_INQUIRY)) < 0) {
        LOGE("Send inquiry command fails errno %d\n", errno);
        return FALSE;
    }

    return TRUE;
}

static BOOL FM_BT_inquiry(void)
{
    return BT_Inquiry();
}


static BOOL BT_Recv_HciEvent(BT_HCI_EVENT_T *pHciEvent)
{
    pHciEvent->status = FALSE;

    if (!glib_handle) {
        LOGE("mtk bt library is unloaded!\n");
        return FALSE;
    }
    if (bt_fd < 0) {
        LOGE("bt driver fd is invalid!\n");
        return FALSE;
    }

    if (bt_receive_data(bt_fd, &pHciEvent->event, 1) < 0) {
        LOGE("Read event code fails errno %d\n", errno);
        return FALSE;
    }

    LOGD("Read event code: %02x\n", pHciEvent->event);

    if (bt_receive_data(bt_fd, &pHciEvent->len, 1) < 0) {
        LOGE("Read event length fails errno %d\n", errno);
        return FALSE;
    }

    LOGD("Read event length: %02x\n", pHciEvent->len);

    if (pHciEvent->len) {
        if (bt_receive_data(bt_fd, pHciEvent->parms, pHciEvent->len) < 0) {
            LOGE("Read event param fails errno %d\n", errno);
            return FALSE;
        }
    }

    pHciEvent->status = TRUE;

    return TRUE;
}

static BOOL BT_RemoteNameReq(BT_INFO_T *pTmpBtInfo)
{
    UINT8 ucHeader = 0;
    int   count = 0;
    BOOL  bRet = FALSE;

    BT_HCI_EVENT_T hci_event;
    UINT8 HCI_REMOTE_NAME_REQ[] =
        {0x01, 0x19, 0x04, 0x0A, 0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x01, 0x00, 0xCC, 0xCC};

    HCI_REMOTE_NAME_REQ[4]  = pTmpBtInfo->btaddr[5];
    HCI_REMOTE_NAME_REQ[5]  = pTmpBtInfo->btaddr[4];
    HCI_REMOTE_NAME_REQ[6]  = pTmpBtInfo->btaddr[3];
    HCI_REMOTE_NAME_REQ[7]  = pTmpBtInfo->btaddr[2];
    HCI_REMOTE_NAME_REQ[8]  = pTmpBtInfo->btaddr[1];
    HCI_REMOTE_NAME_REQ[9]  = pTmpBtInfo->btaddr[0];
    HCI_REMOTE_NAME_REQ[10] = pTmpBtInfo->psr;
    HCI_REMOTE_NAME_REQ[12] = pTmpBtInfo->clkoffset[1];
    HCI_REMOTE_NAME_REQ[13] = pTmpBtInfo->clkoffset[0];

    if (!glib_handle) {
        LOGE("mtk bt library is unloaded!\n");
        return FALSE;
    }
    if (bt_fd < 0) {
        LOGE("bt driver fd is invalid!\n");
        return FALSE;
    }

    if (bt_send_data(bt_fd, HCI_REMOTE_NAME_REQ, sizeof(HCI_REMOTE_NAME_REQ)) < 0) {
        LOGE("Send remote name req command fails errno %d\n", errno);
        return FALSE;
    }

    while (!fgKillThread) {

        if (bt_receive_data(bt_fd, &ucHeader, sizeof(ucHeader)) < 0) {
            count ++;
            if (count < 5)
                continue;
            else
                break;
        }

        /* If not event */
        if (ucHeader != 0x04) {
            LOGE("Unexpected BT packet header %02x\n", ucHeader);
            return FALSE;
        }

        if (BT_Recv_HciEvent(&hci_event)) {
            /* Wait for remote name request complete event */
            if (hci_event.event == 0x07) {
                /* success */
                if (hci_event.parms[0] == 0) {
                    /* FIX ME need convert UTF8 -> ASCII */
                    memcpy(pTmpBtInfo->name, &hci_event.parms[7], 248);
                    //pTmpBtInfo->name[hci_event.len] = '\0';
                    LOGD("Remote name %s\n", pTmpBtInfo->name);
                    bRet = TRUE;
                    break;
                } else { /* faliure such as page time out */
                    LOGD("Unexpected result event %02x status %02x\n",
                        hci_event.event, hci_event.parms[0]);
                    /* FIX ME need convert UTF8 -> ASCII */
                    pTmpBtInfo->name[0] = 'U';
                    pTmpBtInfo->name[1] = 'N';
                    pTmpBtInfo->name[2] = 'K';
                    pTmpBtInfo->name[3] = 'N';
                    pTmpBtInfo->name[4] = 'O';
                    pTmpBtInfo->name[5] = 'W';
                    pTmpBtInfo->name[6] = 'N';
                    pTmpBtInfo->name[7] = '\0';
                    bRet = TRUE;
                    break;
                }
            }
        } else {
            LOGE("Receive event fails errno %d\n", errno);
            return FALSE;
        }
    }

    return bRet;
}

static void *BT_FM_Thread(void *ptr)
{
    BT_HCI_EVENT_T hci_event;
    UINT8 ucHeader = 0;
    BT_INFO_T *pBtInfo = NULL, *pBtInfoForList = NULL;
    int   rssi = 0;

    while (!fgKillThread) {

        if (g_scan_complete == TRUE) {
            LOGD("Scan complete\n");
            break;
        }

        if (!glib_handle) {
            LOGE("mtk bt library is unloaded!\n");
            break;
        }
        if (bt_fd < 0) {
            LOGE("bt driver fd is invalid!\n");
            break;
        }

        if (bt_receive_data(bt_fd, &ucHeader, sizeof(ucHeader)) < 0) {
            LOGE("Zero byte read\n");
            continue;
        }

        switch (ucHeader) {
          case 0x04:
            LOGD("Receive HCI event\n");
            if (BT_Recv_HciEvent(&hci_event)) {
                if (hci_event.event == 0x0F) {
                    /* Command status event */
                    if (hci_event.len != 0x04) {
                        LOGE("Unexpected command status event len %d", (int)hci_event.len);
                        goto CleanUp;
                    }

                    if (hci_event.parms[0] != 0x00) {
                        LOGE("Unexpected command status %02x", hci_event.parms[0]);
                        goto CleanUp;
                    }
                } else if (hci_event.event == 0x01) {
                    /* Inquiry complete event */
                    if (hci_event.len != 0x01) {
                        LOGE("Unexpected inquiry complete event len %d", (int)hci_event.len);
                        goto CleanUp;
                    }

                    if (hci_event.parms[0] != 0x00) {
                        LOGE("Unexpected inquiry complete status %02x", hci_event.parms[0]);
                        goto CleanUp;
                    }

                    g_inquiry_complete = TRUE;
                    LOGD("Inquiry complete\n");

                    pBtInfo = g_pBtListHear;
                    LOGD("Start remote name request\n");
                    while (pBtInfo && !fgKillThread) {
                        BT_RemoteNameReq(pBtInfo);
                        pBtInfo = pBtInfo->pNext;
                    }

                    g_scan_complete = TRUE;
                } else if (hci_event.event == 0x02) {
                    /* Inquiry result event */
                    /* should not be received */
                    goto CleanUp;
                } else if (hci_event.event == 0x22) {
                    /* Inquiry result with RSSI */
                    pBtInfo = (BT_INFO_T *)malloc(sizeof(BT_INFO_T));
                    memset(pBtInfo, 0, sizeof(BT_INFO_T));

                    if (hci_event.len != 0x0F) {
                        LOGE("Unexpected inquiry result event len %d\n", (int)hci_event.len);
                        goto CleanUp;
                    }

                    /* negative 2's complement */
                    rssi = hci_event.parms[14];
                    if (rssi >= 128)
                        rssi -= 256;

                    /* Update record */
                    pBtInfo->btaddr[0] = hci_event.parms[6];
                    pBtInfo->btaddr[1] = hci_event.parms[5];
                    pBtInfo->btaddr[2] = hci_event.parms[4];
                    pBtInfo->btaddr[3] = hci_event.parms[3];
                    pBtInfo->btaddr[4] = hci_event.parms[2];
                    pBtInfo->btaddr[5] = hci_event.parms[1];
                    pBtInfo->psr = hci_event.parms[7];
                    pBtInfo->cod[0] = hci_event.parms[11];
                    pBtInfo->cod[1] = hci_event.parms[10];
                    pBtInfo->cod[2] = hci_event.parms[9];
                    pBtInfo->clkoffset[0] = hci_event.parms[13];
                    pBtInfo->clkoffset[1] = hci_event.parms[12];
                    pBtInfo->rssi = rssi; //-120 - 20dbm

                    /* Insert into list */
                    if (g_pBtListHear == NULL)
                        g_pBtListHear = pBtInfo;
                    else {
                        pBtInfoForList = g_pBtListHear;
                        while(pBtInfoForList->pNext != NULL) {
                            pBtInfoForList = pBtInfoForList->pNext;
                        }
                        pBtInfoForList->pNext = pBtInfo;
                    }
                } else {
                    /* simply ignore it? */
                    LOGD("Unexpected event %02x len %d %02x-%02x-%02x-%02x\n",
                        hci_event.event, (int)hci_event.len,
                        hci_event.parms[0], hci_event.parms[1],
                        hci_event.parms[2], hci_event.parms[3]);
                }
            } else {
                LOGE("Read event fails errno %d\n", errno);
                goto CleanUp;
            }
            break;

          default:
            LOGE("Unexpected BT packet header %02x\n", ucHeader);
            goto CleanUp;
        }
    }

CleanUp:
    return NULL;
}

static BOOL BT_SetInquiryMode(UCHAR ucInquiryMode)
{
    UINT8 HCI_INQUIRY_MODE[] = {0x01, 0x45, 0x0C, 0x01, 0x00};
    UINT8 ucAckEvent[7];
    UINT8 ucEvent[] = {0x04, 0x0E, 0x04, 0x01, 0x45, 0x0C, 0x00};

    HCI_INQUIRY_MODE[4] = ucInquiryMode;

    if (!glib_handle) {
        LOGE("mtk bt library is unloaded!\n");
        return FALSE;
    }
    if (bt_fd < 0) {
        LOGE("bt driver fd is invalid!\n");
        return FALSE;
    }

    if (bt_send_data(bt_fd, HCI_INQUIRY_MODE, sizeof(HCI_INQUIRY_MODE)) < 0) {
        LOGE("Send inquiry mode command fails errno %d\n", errno);
        return FALSE;
    }

    if (bt_receive_data(bt_fd, ucAckEvent, sizeof(ucAckEvent)) < 0) {
        LOGE("Receive command complete event fails errno %d\n", errno);
        return FALSE;
    }

    if (memcmp(ucAckEvent, ucEvent, sizeof(ucEvent))) {
        LOGE("Receive unexpected event\n");
        return FALSE;
    }

    return TRUE;
}


static BOOL FM_BT_init(void)
{
    const char *errstr;

    glib_handle = dlopen("libbluetooth_mtk_pure.so", RTLD_LAZY);
    if (!glib_handle) {
        LOGE("%s\n", dlerror());
        goto error;
    }

    dlerror(); /* Clear any existing error */

    bt_init = dlsym(glib_handle, "bt_init");
    bt_restore = dlsym(glib_handle, "bt_restore");
    bt_send_data = dlsym(glib_handle, "bt_send_data");
    bt_receive_data = dlsym(glib_handle, "bt_receive_data");

    if ((errstr = dlerror()) != NULL) {
        LOGE("Can't find function symbols %s\n", errstr);
        goto error;
    }

    bt_fd = bt_init();
    if (bt_fd < 0)
        goto error;

    LOGD("BT is enabled success\n");

    /* Enable inquiry result with RSSI */
    if (!BT_SetInquiryMode(0x01)) {
        LOGE("Can't set BT inquiry mode\n");
        goto error;
    }

    /* Create RX thread */
    g_scan_complete = FALSE;
    g_inquiry_complete = FALSE;
    fgKillThread = FALSE;
    pthread_create(&rxThread, NULL, BT_FM_Thread, (void*)NULL);

    sched_yield();
    return TRUE;

error:
    if (bt_fd >= 0) {
        bt_restore(bt_fd);
        bt_fd = -1;
    }

    if (glib_handle) {
        dlclose(glib_handle);
        glib_handle = NULL;
    }

    return FALSE;
}
static void *bt_update_info(TestEntry *btentry)
{
    bf_test.test_result = TEST_RESULT_UNKNOWN;
    char bt_result[32] = {0};

    LOGD(TAG "%s: Start\n", __FUNCTION__);

    snprintf(btentry->value.name, sizeof(btentry->value.name), "%s", uistr_info_bt_init);
    drawItemValueBehindLine(btentry);
    btentry->state = TEST_FAIL;
    if (FM_BT_init() == false) {
        LOGD(TAG "%s: Exit\n", __FUNCTION__);
        snprintf(btentry->value.name, sizeof(btentry->value.name), "%s", uistr_info_bt_init_fail);
        drawItemValueBehindLine(btentry);
        goto exit;
    }
    btentry->value.color = GREENCOLOR;
    snprintf(btentry->value.name, sizeof(btentry->value.name), "%s", uistr_info_bt_init_ok);
    drawItemValueBehindLine(btentry);

    FM_BT_inquiry();

    while (bf_test.test_result==TEST_RESULT_UNKNOWN && btrunning == 1) {
        updateTextInfo(&bf_test, btentry->value.name, sizeof(btentry->value.name));
        drawItemValueBehindLine(btentry);
        //break;//一次就退出
        //usleep(200000);
    }
    if (bf_test.test_result!=TEST_RESULT_UNKNOWN){
    	btentry->state = TEST_PASS;
    }
    LOGD("bluetooth test over");

exit:
    FM_BT_deinit();
    setProinfoItemResult(btentry->id,btentry->state);
    LOGD(TAG "%s: Exit\n", __FUNCTION__);
    return NULL;
}


extern TestEntry btEntry;
pthread_mutex_t bt_fm_mutex = PTHREAD_MUTEX_INITIALIZER;
void * jlink_bt_start(void*para){
	btrunning = 1;
    drawTestItem(&btEntry);
    strcpy(btEntry.value.name, uistr_info_waiting);
    drawItemValueBehind(&btEntry);
    pthread_mutex_lock(&bt_fm_mutex);
    bt_update_info(&btEntry);
    pthread_mutex_unlock(&bt_fm_mutex);
    //drawItemValueBehind(&btEntry);
    return NULL;
}

void stopBt(){
	btrunning = 0;
}