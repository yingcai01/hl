#include "jlinkui.h"

extern TestEntry emmcEntry;
static int emmc_update_info(char *valuebuf)
{
	char *ptr;
	//bool old_avail = mc->avail;
	int inode = 0;
	unsigned long long e_size = 0;
	char buf[1024];
	float temsize = 0;
	ssize_t pemmcsize;
	inode = open("/sys/class/block/mmcblk0/size", O_RDONLY);
	if (inode < 0) {
		printf("open error!\n");
		emmcEntry.state = TEST_FAIL;
		setProinfoItemResult(emmcEntry.id,emmcEntry.state);
		return -1;
	}

	memset(buf, 0, sizeof(buf));
	pemmcsize = read(inode, buf, sizeof(buf) - 1);
	e_size = atol(buf);

	temsize      = (float)(e_size * 512 / 1024);
	close(inode);
	valuebuf += sprintf(valuebuf, "%s: %.2f GB\n",uistr_info_emmc_sd_total_size,
		(float)(temsize)/(1024*1024));

	emmcEntry.state = TEST_PASS;
	setProinfoItemResult(emmcEntry.id,emmcEntry.state);
	return 0;
}



void * jlink_emmc_start(void*para){

    drawTestItem(&emmcEntry);
    emmc_update_info(emmcEntry.value.name);
    drawItemValueBehind(&emmcEntry);
    return NULL;
}