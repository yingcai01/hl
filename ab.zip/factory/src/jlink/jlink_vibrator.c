#include "jlinkui.h"
#include "ftm.h"

extern TestEntry vibEntry;
extern Button vibbutton;
ButtonEntry vibbtnentry;
#define VIBRATOR_ENABLE "/sys/class/timed_output/vibrator/enable"
static int vibrator_time = 0;
static int write_int(char const* path, int value)
{
	int fd;
	if (path == NULL)
		return -1;

	fd = open(path, O_RDWR);
	if (fd >= 0) {
		char buffer[20];
		int bytes = sprintf(buffer, "%d\n", value);
		int amt = write(fd, buffer, bytes);
		close(fd);
		return amt == -1 ? -errno : 0;
	}

	LOGE("write_int failed to open %s\n", path);
	return -errno;
}

static void *update_vibrator_thread_default(void *priv)
{
	int ret = -1;
	int count = 5;
	LOGD("%s: Start\n", __FUNCTION__);
	LOGD("%s: write vibrator_enable=%d\n", __FUNCTION__, vibrator_time);
	vibEntry.state = TEST_PASS;
	ret = write_int(VIBRATOR_ENABLE, vibrator_time);
	if (ret < 0){ vibEntry.state = TEST_FAIL;};
	while(count--){	sleep(1);}
	ret = write_int(VIBRATOR_ENABLE, 0);
	if (ret < 0){ vibEntry.state = TEST_FAIL;};
	LOGD("%s: write vibrator_enable=0\n", __FUNCTION__);
	setProinfoItemResult(vibEntry.id,vibEntry.state);
	pthread_exit(NULL);

	LOGD("%s: Exit\n", __FUNCTION__);

	return NULL;
}



static void* vibrator_start(void *pram)
{
	int chosen;
	bool exit = false;
	char* vibr_time = NULL;
	pthread_t vibrator_thread;

	LOGD("%s\n", __FUNCTION__);
	vibr_time = ftm_get_prop("Vibrator_Last_Time");
	LOGD("%s: get vibrator last time=%s!\n", __FUNCTION__, vibr_time);
	if(vibr_time != NULL)
	{
		vibrator_time = (uint32_t)atoi(vibr_time);
		if (vibrator_time <=0) vibrator_time = 8000;
		LOGD("%s: get vibrator last time=%d!\n", __FUNCTION__, vibrator_time);
	}
	else
	{
		vibrator_time = 8000;
		LOGD("%s: get vibrator last time fail!\n", __FUNCTION__);
	}

	strcpy(vibEntry.value.name,uistr_info_testing);
    drawItemValueBehind(&vibEntry);
	pthread_create(&vibrator_thread, NULL, update_vibrator_thread_default, NULL);
	pthread_join(vibrator_thread, NULL);
	strcpy(vibEntry.value.name,uistr_info_testover);
    drawItemValueBehind(&vibEntry);
    DrawButtonBehindEntry(&vibbutton,&vibEntry);
	return 0;
}


void * jlink_vibrator_start(void*para){
	/*
	int row = 0;
	if (para!=NULL)
	{
		row = *(int*)para;
	}
	
	memset(&vibEntry,0,sizeof(vibEntry));
    vibEntry.entry.color = YELLOWCOLOR;
    vibEntry.entry.row = row;
    vibEntry.entry.backcolor = BACKCOLOR;
    vibEntry.entry.col = ITEMCOL;
    strcpy(vibEntry.entry.name,uistr_vibrator);
    vibEntry.value.color = GREENCOLOR;
    vibEntry.value.backcolor = BACKCOLOR;
    */
    drawTestItem(&vibEntry);
    //vibrator_start(NULL);
    
    initTestButton(&vibbutton,vibrator_start);
    //DrawButtonBehindEntry(&vibbutton,&vibEntry);

    vibbtnentry.btn = &vibbutton;
    vibbtnentry.next = NULL;
    addButtionCallback(&vibbtnentry);
    vibrator_start(NULL);
    return NULL;
}

