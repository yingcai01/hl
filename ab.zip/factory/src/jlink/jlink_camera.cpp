extern "C"{
#include "jlinkui.h"	
}

#include <acdk/MdkIF.h>

static int iscameraopen = 0;
extern void setCameraID(int id);
extern void setJCameraPara(int x,int y,int width,int height,int orientation);
extern int acdkIFInit();
extern MINT32 camera_preview_test();
extern int camera_preview_stop(void);
extern int camera_reset_layer_buffer(void);
extern int gcamera_autoTest;
extern int jlcd_width;
extern int jlcd_height;
static int cameraID = 2;
static int prevw = CAMERA_PRE_HEIGHT;
static int prevh = CAMERA_PRE_WIDTH;

extern char rotate_lcm[];
static int camera_opennum = 0;

void jlink_camerastop(){
	if (iscameraopen==1)
	{
		camera_preview_stop();
		camera_reset_layer_buffer();
		Mdk_DeInit();
        Mdk_Close();
        iscameraopen = 0;
	}
	
}


extern Button cambutton;
ButtonEntry cambtnentry;
void* camera_start(void *id){
	if (iscameraopen==1)
	{
		camera_preview_stop();
		camera_reset_layer_buffer();
		Mdk_DeInit();
        Mdk_Close();
		sleep(1);
	}
	cambutton.state = BTN_NORMAL;
	cameraID = (cameraID+1)%2;
	int cameraid = cameraID+1;
	LOGD("MYTEST cameraid=%d",cameraid);
	setCameraID(cameraid);
	gcamera_autoTest = 0;
	//最小176x144,320x240,352x288,480x320,480x368,640x480,720x480,800x480,800x600,864x480,
	//960x540,1024x768,1280x720,1280x736,1280x768,1280x960,1920x1080,1920x1088,1920x1280
	//最大大小以实际屏分辨率为准
	//注意屏幕的方向,可能图像方向的宽和高与实际屏不一致需调整宽和高位置同时旋转摄像头方向
	int frontCameraDegree = 90;
	int backCameraDegree = 270;
#if defined(PROJECT_H803) 
	frontCameraDegree = 270;
	backCameraDegree = 90;

#endif
	if (0 == strncmp(rotate_lcm, "90", 2))
	{
		if (cameraid==2)
		{
			setJCameraPara(jlcd_height-prevw,jlcd_width-prevh,prevw,prevh,frontCameraDegree);
		}
		else{
			setJCameraPara(jlcd_height-prevw,jlcd_width-prevh,prevw,prevh,backCameraDegree);
		}
		
	}else if (0 == strncmp(rotate_lcm, "180", 3))
	{
		if (cameraid==2)
		{
			setJCameraPara(0,jlcd_height-prevh,prevw,prevh,frontCameraDegree);
		}
		else{
			setJCameraPara(0,jlcd_height-prevh,prevw,prevh,backCameraDegree);
		}
		
	}else if(0 == strncmp(rotate_lcm, "270", 3)){
		if (cameraid==2)
		{
			setJCameraPara(0,0,prevw,prevh,frontCameraDegree);
		}else{
			setJCameraPara(0,0,prevw,prevh,backCameraDegree);
		}
		
	}else{
		if (cameraid==2)
		{
			setJCameraPara(jlcd_width-prevw,0,prevw,prevh,frontCameraDegree);
		}
		else{
			setJCameraPara(jlcd_width-prevw,0,prevw,prevh,backCameraDegree);
		}
		
	}
	
	if(acdkIFInit()!=0){
		Mdk_DeInit();
        Mdk_Close();
        iscameraopen = 0;
        strcpy(cambutton.text,uistr_info_testexit);
        draw_button(&cambutton);
		if (cameraid==1){
            setProinfoItemResult(JILNK_ITEM_MAIN_CAMERA,TEST_FAIL);
        }else{
            setProinfoItemResult(JILNK_ITEM_SUB_CAMERA,TEST_FAIL);
        }
        return NULL;
	}else{
		camera_preview_test();
		camera_opennum++;
        if (camera_opennum <= 2){
            if (cameraid==1){
                setProinfoItemResult(JILNK_ITEM_MAIN_CAMERA,TEST_PASS);
            }else{
                setProinfoItemResult(JILNK_ITEM_SUB_CAMERA,TEST_PASS);
            }
        }
		iscameraopen = 1;
		if (cameraid==1)
		{
			strcpy(cambutton.text,uistr_info_openfrcam);
		}else{
			strcpy(cambutton.text,uistr_info_openbkcam);
		}
		draw_button(&cambutton);
	}


	return NULL;
}

void* jlink_camera_start(void*para){
	cameraID = 1;
	iscameraopen = 0;
    camera_opennum = 0;
	cambutton.disenable_color = 0x555555FF;
	cambutton.back_color = 0x348646FF;
	cambutton.press_color = 0xff0000ff;
	cambutton.text_color = 0x989234ff;
	cambutton.width=250;
	cambutton.height=60;
	cambutton.isautohidden = 1;

	if (0 == strncmp(rotate_lcm, "90", 2))
	{
		cambutton.x=jlcd_width-(cambutton.width+prevh)/2;
		cambutton.y=prevw+60;
	}else if (0 == strncmp(rotate_lcm, "180", 3))
	{
		cambutton.x=jlcd_width-(cambutton.width+prevw)/2;
		cambutton.y=prevh+60;
	}else if(0 == strncmp(rotate_lcm, "270", 3)){
		cambutton.x=jlcd_width-(cambutton.width+prevh)/2;
		cambutton.y=prevw+60;
	}else{
		cambutton.x=jlcd_width-(cambutton.width+prevw)/2;;
		cambutton.y=prevh+60;
	}

	cambutton.onClickListener=camera_start;
    cambtnentry.btn = &cambutton;
    cambtnentry.next = NULL;
    camera_start(NULL);
    if (iscameraopen==0){
    	cameraID = 2;
    	camera_start(NULL);
    }
    addButtionCallback(&cambtnentry);
	return NULL;
}
