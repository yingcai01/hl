#include "jlinkui.h"
#include <linux/sensors_io.h>
#include "ftm.h"


#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <fcntl.h>
#include <pthread.h>
#include <sys/mount.h>
#include <sys/statfs.h>
#include <dirent.h>
#include <linux/input.h>
#include <math.h>

#include "common.h"
#include "miniui.h"
#include "ftm.h"
#include "cust.h"

#define C_MAX_HWMSEN_EVENT_NUM 4
#define	GSENSOR_NAME "/dev/gsensor"
#define GSENSOR_ATTR_SELFTEST "/sys/bus/platform/drivers/gsensor/selftest"
#define TOLERANCE_0G            (1.00)
#define TOLERANCE_1G            (9.5)
#define C_MAX_MEASURE_NUM (20)
#define GRAVITY_EARTH           (9.80665f)
#define JGENSORMANMAL //xuzhaoyou manual

typedef enum {
    TILT_UNKNOWN = 0,
    TILT_X_POS  = 1,
    TILT_X_NEG  = 2,
    TILT_Y_POS  = 3,
    TILT_Y_NEG  = 4,
    TILT_Z_POS  = 5,
    TILT_Z_NEG  = 6, 

    TILT_MAX,
}TILT_POS;

struct acc_evt {
    float x;
    float y;
    float z;
    //int64_t time;
};

extern struct acc_priv
{
    /*specific data field*/
    char *ctl;
    char *dat;
    int fd;
    struct acc_evt evt;
    int  tilt;
    unsigned int pos_chk;

    /*self test*/
	int support_selftest;
    int selftest;   /*0: testing; 1: test ok; -1: test fail*/
    int avg_prv[C_MAX_HWMSEN_EVENT_NUM];
    int avg_nxt[C_MAX_HWMSEN_EVENT_NUM];

    /*calculate statical information*/
    int statistics;  /*0: calculating; 1: done*/
    int measure_idx; 
    float raw[C_MAX_MEASURE_NUM][C_MAX_HWMSEN_EVENT_NUM];
    float std[C_MAX_HWMSEN_EVENT_NUM];
    float avg[C_MAX_HWMSEN_EVENT_NUM];
    float max[C_MAX_HWMSEN_EVENT_NUM];
    float min[C_MAX_HWMSEN_EVENT_NUM];
};
/*---------------------------------------------------------------------------*/
struct acc_data
{
    struct acc_priv acc;

    /*common for each factory mode*/
    char  info[1024];
    //bool  avail;
    bool  exit_thd;

    text_t    title;
    text_t    text;
    text_t    left_btn;
    text_t    center_btn;
    text_t    right_btn;
    
    pthread_t update_thd;
    struct ftm_module *mod;
    //struct textview tv;
    struct itemview *iv;
};



static char *gsensor_pos[] = {
    uistr_info_g_sensor_unknow,
    "X+",
    "X-",
    "Y+",
    "Y-",
    "Z+",
    "Z-",
};

static int autoflag = 0;
static bool gsensor_thread_exit = false;
extern TestEntry gsensorEntry;

static int gsensor_statistic(struct acc_priv* acc)
{
    int idx;
    float diff;

    if (acc->statistics)
        return 0;

    /*record data*/
	if(acc->measure_idx < C_MAX_MEASURE_NUM)
	{
	   //FTGLOGD("init  acc->measure_idx =%d \n",acc->measure_idx );
       acc->raw[acc->measure_idx][0] = acc->evt.x;
       acc->raw[acc->measure_idx][1] = acc->evt.y;
       acc->raw[acc->measure_idx][2] = acc->evt.z;

       acc->avg[0] += acc->evt.x;
       acc->avg[1] += acc->evt.y;
       acc->avg[2] += acc->evt.z;
	}

    if (acc->measure_idx < C_MAX_MEASURE_NUM) {
        acc->measure_idx++;
        return 0;
    }

        
    for (idx = 0; idx < C_MAX_HWMSEN_EVENT_NUM; idx++) {
        acc->min[idx] = +100*GRAVITY_EARTH;
        acc->max[idx] = -100*GRAVITY_EARTH;
    }        
    acc->avg[0] /= C_MAX_MEASURE_NUM;
    acc->avg[1] /= C_MAX_MEASURE_NUM;
    acc->avg[2] /= C_MAX_MEASURE_NUM;
    
    for (idx = 0; idx < C_MAX_MEASURE_NUM; idx++) {
        diff = acc->raw[idx][0] - acc->avg[0];
        acc->std[0] += diff * diff;
        diff = acc->raw[idx][1] - acc->avg[1];
        acc->std[1] += diff * diff;
        diff = acc->raw[idx][2] - acc->avg[2];
        acc->std[2] += diff * diff;    
        if (acc->max[0] < acc->raw[idx][0])
            acc->max[0] = acc->raw[idx][0];
        if (acc->max[1] < acc->raw[idx][1])
            acc->max[1] = acc->raw[idx][1];
        if (acc->max[2] < acc->raw[idx][2])
            acc->max[2] = acc->raw[idx][2];
        
        if (acc->min[0] > acc->raw[idx][0])
            acc->min[0] = acc->raw[idx][0];
        if (acc->min[1] > acc->raw[idx][1])
            acc->min[1] = acc->raw[idx][1];
        if (acc->min[2] > acc->raw[idx][2])
            acc->min[2] = acc->raw[idx][2];

        LOGD(TAG"[%2d][%+6.3f %+6.3f %+6.3f]\n", idx, acc->raw[idx][0], acc->raw[idx][1], acc->raw[idx][2]);
    }
    acc->std[0] = sqrt(acc->std[0]/C_MAX_MEASURE_NUM);
    acc->std[1] = sqrt(acc->std[1]/C_MAX_MEASURE_NUM);
    acc->std[2] = sqrt(acc->std[2]/C_MAX_MEASURE_NUM);
    acc->statistics = 1;
    return 0;
}


static int gsensor_selftest(struct acc_priv *acc, int period, int count)
{
   
    int res = 0;
    int selftest=0;
    int fd=0;
    char buf[] = {"9"};
    char selftestRes[8];
    memset(selftestRes,0,sizeof(selftestRes));
    fd = open(GSENSOR_ATTR_SELFTEST, O_RDWR);
    if(fd == -1)
    {
        LOGD("open selftest attr err = %s\n", strerror(errno));
        return -errno;
    }

    //enalbe selftest
    res = write(fd, buf, sizeof(buf));
    if(res <= 0)
    {
       LOGD(" write attr failed\n");
    }
    sleep(1);

    lseek(fd, 0, SEEK_SET);
    res = read(fd,selftestRes,8);
    
    LOGD("fwq factory read selftestbuf = %s\n",selftestRes);
    
    
    if(res < 0)
    {
      LOGD(" read attr failed\n");
      LOGD("errno %d , %s",errno,strerror(errno));
      perror("Read");
    }

    if('y' == selftestRes[0])
    {
      LOGD("SELFTEST : PASS\n");
      acc->selftest = 1;
      
    }
    else
    {
      LOGD("SELFTEST : FAIL\n");
      acc->selftest = -1;
    }
    res=0;
    if(close(fd) == -1)
    {
        LOGD("close selftest attr fails = %s\n", strerror(errno));
        /* res = (res) ? (res) : (-errno); */
    }
    sleep(1);   /*make sure g-sensor is back to normal*/
    return res;    
}


static int gsensor_open(struct acc_priv *acc)
{
	int fd = -1;
    if(acc->fd < 0)
	{
		acc->fd = open(GSENSOR_NAME, O_RDONLY);
        unsigned int flags = 1;
        int err = 0;
        int  max_retry = 3, retry_period = 100, retry=0;
        while ((err = ioctl(acc->fd, GSENSOR_IOCTL_INIT, &flags)) && (retry ++ < max_retry))
            usleep(retry_period*1000);
            if (err) {
                LOGD("enable g-sensor fail: %s", strerror(errno));
                return 0;
            }
	}

	fd = open(GSENSOR_ATTR_SELFTEST, O_RDWR);
	if(fd < 0)
	{
		acc->support_selftest = 0;
		LOGE(TAG"gsensor not support self test!\n");
	}
	else
	{
		acc->support_selftest = 1;
		close(fd);
	}
	
	if(acc->fd < 0)
	{
		LOGE(TAG"Couldn't open gsensor device!\n");
		return -EINVAL;
	}

	return 0;	
}

static int gsensor_close(struct acc_priv *acc)
{
    int i=0;
    if(acc->fd != 0)
    {
        close(acc->fd);
        acc->fd = -1;
    }
    acc->pos_chk = 0x00;
    acc->statistics=0;
    acc->support_selftest = 0;
    acc->selftest = 0;
    acc->measure_idx =0;
    for(i=0; i<C_MAX_HWMSEN_EVENT_NUM; i++)
    {
      acc->max[i] = 0;
      acc->min[i] = 0;
      acc->avg[i] = 0;
      acc->std[i] = 0;
      
    }
    
    return 0;
}

static int gsensor_read(struct acc_priv *acc)
{
	static char buf[128];    
	int x, y, z, err;

	if(acc->fd == -1)
	{
		LOGE(TAG"invalid file descriptor\n");
		err = -EINVAL;
	}
	else if((acc->support_selftest == 1) && (!acc->selftest) && (err = gsensor_selftest(acc, 10, 20)))
	{    
		LOGE(TAG"selftest fail: %s(%d)\n", strerror(errno), errno);
	}
	else
	{

		err = ioctl(acc->fd, GSENSOR_IOCTL_READ_SENSORDATA, buf);
		if(err)
		{
			LOGE(TAG"read data fail: %s(%d)\n", strerror(errno), errno);
		}
		else if(3 != sscanf(buf, "%x %x %x", &x, &y, &z))
		{
			LOGE(TAG"read format fail: %s(%d)\n", strerror(errno), errno);
		}
		else
		{

			acc->evt.x = (float)(x)/1000;
			acc->evt.y = (float)(y)/1000;
			acc->evt.z = (float)(z)/1000;
			err = 0;
			gsensor_statistic(acc);

			//add sensor data to struct sp_ata_data for PC side
			//return_data.gsensor.g_sensor_x = acc->evt.x;
			//return_data.gsensor.g_sensor_y = acc->evt.y;
			//return_data.gsensor.g_sensor_z = acc->evt.z;
			//return_data.gsensor.accuracy = 3;
			
		}
	}
	return err;    
}


static int gsensor_check_tilt(struct acc_priv *acc)
{
    if ((acc->evt.x  >  TOLERANCE_1G) && 
        (acc->evt.y  > -TOLERANCE_0G  &&  acc->evt.y  <  TOLERANCE_0G) &&
        (acc->evt.z  > -TOLERANCE_0G  &&  acc->evt.z  <  TOLERANCE_0G)) {
        acc->tilt = TILT_X_POS;
        return 0;
    }
    if ((acc->evt.x  < -TOLERANCE_1G) && 
        (acc->evt.y  > -TOLERANCE_0G  &&  acc->evt.y  <  TOLERANCE_0G) &&
        (acc->evt.z  > -TOLERANCE_0G  &&  acc->evt.z  <  TOLERANCE_0G)) {
        acc->tilt = TILT_X_NEG;
        return 0;
    }
    if ((acc->evt.y  >  TOLERANCE_1G) && 
        (acc->evt.x  > -TOLERANCE_0G  &&  acc->evt.x  <  TOLERANCE_0G) &&
        (acc->evt.z  > -TOLERANCE_0G  &&  acc->evt.z  <  TOLERANCE_0G)) {
        acc->tilt = TILT_Y_POS;
        return 0;
    }
    if ((acc->evt.y  < -TOLERANCE_1G) && 
        (acc->evt.x  > -TOLERANCE_0G  &&  acc->evt.x  <  TOLERANCE_0G) &&
        (acc->evt.z  > -TOLERANCE_0G  &&  acc->evt.z  <  TOLERANCE_0G)) {
        acc->tilt = TILT_Y_NEG;
        return 0;
    }
    if ((acc->evt.z  >  TOLERANCE_1G) && 
        (acc->evt.x  > -TOLERANCE_0G  &&  acc->evt.x  <  TOLERANCE_0G) &&
        (acc->evt.y  > -TOLERANCE_0G  &&  acc->evt.y  <  TOLERANCE_0G)) {
        acc->tilt = TILT_Z_POS;
        return 0;
    }
    if ((acc->evt.z  < -TOLERANCE_1G) && 
        (acc->evt.x  > -TOLERANCE_0G  &&  acc->evt.x  <  TOLERANCE_0G) &&
        (acc->evt.y  > -TOLERANCE_0G  &&  acc->evt.y  <  TOLERANCE_0G)) {
        acc->tilt = TILT_Z_NEG;
        return 0;
    }
    //snprintf(acc->tiltbuf, sizeof(acc->tiltbuf), "Tilt: unknown\n");
    acc->tilt = TILT_UNKNOWN; 
    return 0;
}

static int gsensor_init_priv(struct acc_priv *acc)
{
    memset(acc, 0x00, sizeof(*acc));
    acc->fd = -1;
	acc->support_selftest = 0;
    acc->pos_chk = 0x00;  
    return 0;
}

static int gensorthread_run = 1;
static void *gsensor_update_auto_thread(void *priv)
{
    struct acc_data *dat = (struct acc_data *)priv; 
    struct acc_priv *acc = &dat->acc;
    struct itemview *iv = dat->iv;    
    int err = 0, len = 0;
	//add by wubo 150813
    char *status;
    float gmin=3.26;//0+9.8*20%
    float gmax=13.26;//9.8+9.8*20%
	//
    autoflag=0;
    LOGD(TAG "%s: Start\n", __FUNCTION__);
    if ((err = gsensor_open(acc))) {
    	//memset(gsensorEntry.value.name, 0x00, sizeof(gsensorEntry.value.name));
        sprintf(gsensorEntry.value.name, "INIT FAILED\n");
        //iv->redraw(iv);
        drawItemValueBehind(&gsensorEntry);
        LOGE(TAG"gsensor_open() err = %d(%s)\n", err, dat->info);
        pthread_exit(NULL);
        return NULL;
    }
        
    while (gensorthread_run) {
        
        if (dat->exit_thd){
            LOGE(TAG"dat -> exit_thd\n");
            break;
        }    
        if ((err = gsensor_read(acc))) {
            LOGE(TAG"gsensor_update_info() = (%s), %d\n", strerror(errno), err);
            break;
        } else if ((err = gsensor_check_tilt(acc))) {
            LOGE(TAG"gsensor_check_tilt() = (%s), %d\n", strerror(errno), err);
            break;
        } else if (acc->tilt >= TILT_MAX) {    
            LOGE(TAG"invalid tilt = %d\n", acc->tilt);
            break;        
        } else if (TILT_UNKNOWN != acc->tilt) {
            acc->pos_chk |= (1 << acc->tilt);
        }

		if(acc->support_selftest == 0)
		{
			status = uistr_info_g_sensor_notsupport;
		}
		else if(acc->selftest == 1)
		{
			status = uistr_info_sensor_pass;
		}
		else if(acc->selftest == 0)
		{
			status = uistr_info_g_sensor_testing;
		}
		else
		{
			status = uistr_info_sensor_fail;
		}
        len = 0;
#ifndef FEATURE_FTM_TWO_KEY
        len = snprintf(gsensorEntry.value.name, sizeof(gsensorEntry.value.name)-len, "%+6.3f %+6.3f %+6.3f\n%s (%s)\n%s: %s %s: %s\n%s: %s %s: %s\n%s: %s %s: %s\n", 
                 acc->evt.x, acc->evt.y, acc->evt.z, 
                 (acc->tilt != TILT_UNKNOWN) ? (uistr_info_sensor_pass) : ("NG"), gsensor_pos[acc->tilt],
                 gsensor_pos[TILT_X_POS], (acc->pos_chk & (1 << TILT_X_POS)) ? (uistr_info_sensor_pass) : (uistr_info_g_sensor_testing),
                 gsensor_pos[TILT_X_NEG], (acc->pos_chk & (1 << TILT_X_NEG)) ? (uistr_info_sensor_pass) : (uistr_info_g_sensor_testing),
                 gsensor_pos[TILT_Y_POS], (acc->pos_chk & (1 << TILT_Y_POS)) ? (uistr_info_sensor_pass) : (uistr_info_g_sensor_testing),
                 gsensor_pos[TILT_Y_NEG], (acc->pos_chk & (1 << TILT_Y_NEG)) ? (uistr_info_sensor_pass) : (uistr_info_g_sensor_testing),
                 gsensor_pos[TILT_Z_POS], (acc->pos_chk & (1 << TILT_Z_POS)) ? (uistr_info_sensor_pass) : (uistr_info_g_sensor_testing),
                 gsensor_pos[TILT_Z_NEG], (acc->pos_chk & (1 << TILT_Z_NEG)) ? (uistr_info_sensor_pass) : (uistr_info_g_sensor_testing));

		if(len < 0)
		{
		   LOGE(TAG "%s: snprintf error \n", __FUNCTION__); 
		   len = 0;
		}

        if((acc->support_selftest == 1) && (acc->selftest != 0))
		{
            len += snprintf(dat->info+len, sizeof(dat->info)-len, "%s %s\n", uistr_info_g_sensor_selftest, status);   
        }
		if(len < 0)
		{
		   LOGE(TAG "%s: snprintf error \n", __FUNCTION__); 
		   len = 0;
		}

        len += snprintf(gsensorEntry.value.name+len, sizeof(gsensorEntry.value.name)-len, "%s %s\n%s: %+6.3f %+6.3f %+6.3f\n%s: %+6.3f %+6.3f %+6.3f\n%s-%s: %+6.3f %+6.3f %+6.3f\n%s: %+6.3f %+6.3f %+6.3f\n%s: %+6.3f %+6.3f %+6.3f\n",
                 uistr_info_g_sensor_statistic,
                 (!acc->statistics) ? (uistr_info_g_sensor_doing) : (uistr_info_g_sensor_done),
                 uistr_info_g_sensor_max,
                 acc->max[0], acc->max[1], acc->max[2],
                 uistr_info_g_sensor_min,
                 acc->min[0], acc->min[1], acc->min[2],
                 uistr_info_g_sensor_max, uistr_info_g_sensor_min,
                 acc->max[0]-acc->min[0], acc->max[1]-acc->min[1], acc->max[2]-acc->min[2],
                 uistr_info_g_sensor_avg,
                 acc->avg[0], acc->avg[1], acc->avg[2],
                 uistr_info_g_sensor_std,
                 acc->std[0], acc->std[1], acc->std[2]);
		if(len < 0)
		{
		   LOGE(TAG "%s: snprintf error \n", __FUNCTION__); 
		   len = 0;
		}
#else //shorten the string
		len = snprintf(gsensorEntry.value.name+len, sizeof(gsensorEntry.value.name)-len, "%+6.3f %+6.3f %+6.3f\n%s (%s)\n%s: %s %s: %s\n%s: %s %s: %s\n%s: %s %s: %s\n", 
                 acc->evt.x, acc->evt.y, acc->evt.z, 
                 (acc->tilt != TILT_UNKNOWN) ? (uistr_info_sensor_pass) : ("NG"), gsensor_pos[acc->tilt],
                 gsensor_pos[TILT_X_POS], (acc->pos_chk & (1 << TILT_X_POS)) ? (uistr_info_sensor_pass) : (uistr_info_g_sensor_testing),
                 gsensor_pos[TILT_X_NEG], (acc->pos_chk & (1 << TILT_X_NEG)) ? (uistr_info_sensor_pass) : (uistr_info_g_sensor_testing),
                 gsensor_pos[TILT_Y_POS], (acc->pos_chk & (1 << TILT_Y_POS)) ? (uistr_info_sensor_pass) : (uistr_info_g_sensor_testing),
                 gsensor_pos[TILT_Y_NEG], (acc->pos_chk & (1 << TILT_Y_NEG)) ? (uistr_info_sensor_pass) : (uistr_info_g_sensor_testing),
                 gsensor_pos[TILT_Z_POS], (acc->pos_chk & (1 << TILT_Z_POS)) ? (uistr_info_sensor_pass) : (uistr_info_g_sensor_testing),
                 gsensor_pos[TILT_Z_NEG], (acc->pos_chk & (1 << TILT_Z_NEG)) ? (uistr_info_sensor_pass) : (uistr_info_g_sensor_testing));
        
        len += snprintf(dat->info+len, sizeof(dat->info)-len, "%s%+6.3f %+6.3f %+6.3f\n%s:%+6.3f %+6.3f %+6.3f\n%s:%+6.3f %+6.3f %+6.3f\n%s:%+6.3f %+6.3f %+6.3f\n", 
                 uistr_info_g_sensor_max,acc->max[0], acc->max[1], acc->max[2],
                 uistr_info_g_sensor_min,acc->min[0], acc->min[1], acc->min[2],
                 uistr_info_g_sensor_avg,acc->avg[0], acc->avg[1], acc->avg[2],
                 uistr_info_g_sensor_std,acc->std[0], acc->std[1], acc->std[2]);

		if(len < 0)
		{
		   LOGE(TAG "%s: snprintf error \n", __FUNCTION__); 
		   len = 0;
		}

#endif        
        //len += snprintf(dat->info+len, sizeof(dat->info)-len, uistr_info_g_sensor_range);   
        //iv->set_text(iv, &dat->text);
        //iv->redraw(iv);
        drawItemValueBehind(&gsensorEntry);
		 
		//add for autotest
	 	LOGE(TAG " autoflag=%d\n",autoflag);
		if(acc->statistics==1){
			if((fabs(acc->avg[0])<gmin)&&(fabs(acc->avg[1])<gmin)&&(fabs(acc->avg[2])<gmax)){
				autoflag=1;
				break;
			}else{
				autoflag=2;
				break;
			}
		}else{
			autoflag=0;
		}
        usleep(100000);
	
    }
    gsensor_close(acc);
    LOGD(TAG "%s: Exit\n", __FUNCTION__);    
    pthread_exit(NULL);
    
    return NULL;
}


static void *gsensor_update_manual_thread(void *priv)
{
    struct acc_data *dat = (struct acc_data *)priv; 
    struct acc_priv *acc = &dat->acc;
    struct itemview *iv = dat->iv;    
    int err = 0, len = 0;
	//add by wubo 150813
    char *status;
    float gmin=3.26;//0+9.8*20%
    float gmax=13.26;//9.8+9.8*20%
	//
    autoflag=0;
    LOGD(TAG "%s: Start\n", __FUNCTION__);
    if ((err = gsensor_open(acc))) {
    	//memset(gsensorEntry.value.name, 0x00, sizeof(gsensorEntry.value.name));
        sprintf(gsensorEntry.value.name, "INIT FAILED\n");
        //iv->redraw(iv);
        gsensorEntry.value.color = REDCOLOR;
        drawItemValueBehind(&gsensorEntry);
		gsensorEntry.state = TEST_FAIL;
		setProinfoItemResult(gsensorEntry.id,gsensorEntry.state);
        LOGE(TAG"gsensor_open() err = %d(%s)\n", err, dat->info);
        pthread_exit(NULL);
        return NULL;
    }
    int keepresult = 0;    
    while (gensorthread_run) {
        
        if (dat->exit_thd){
            LOGE(TAG"dat -> exit_thd\n");
            break;
        }    
        if ((err = gsensor_read(acc))) {
            LOGE(TAG"gsensor_update_info() = (%s), %d\n", strerror(errno), err);
            break;
        } else if ((err = gsensor_check_tilt(acc))) {
            LOGE(TAG"gsensor_check_tilt() = (%s), %d\n", strerror(errno), err);
            break;
        } else if (acc->tilt >= TILT_MAX) {    
            LOGE(TAG"invalid tilt = %d\n", acc->tilt);
            break;        
        } else if (TILT_UNKNOWN != acc->tilt) {
            acc->pos_chk |= (1 << acc->tilt);
        }

		
        len = 0;
#ifndef FEATURE_FTM_TWO_KEY
        len = snprintf(gsensorEntry.value.name, sizeof(gsensorEntry.value.name)-len, "%+6.3f %+6.3f %+6.3f", 
                 acc->evt.x, acc->evt.y, acc->evt.z);

		if(len < 0)
		{
		   LOGE(TAG "%s: snprintf error \n", __FUNCTION__); 
		   len = 0;
		}

        
#else //shorten the string
		len = snprintf(gsensorEntry.value.name+len, sizeof(gsensorEntry.value.name)-len, "%+6.3f %+6.3f %+6.3f", 
                 acc->evt.x, acc->evt.y, acc->evt.z);

		if(len < 0)
		{
		   LOGE(TAG "%s: snprintf error \n", __FUNCTION__); 
		   len = 0;
		}

#endif   
	//add     
	if(fabs(acc->evt.x)< 4 && fabs(acc->evt.y) < 4 && (fabs(acc->evt.z)-9.8) < 3.92)
	{
		gsensorEntry.value.color = GREENCOLOR;
	}
	else
	{
		gsensorEntry.value.color = REDCOLOR;
	}
		
        //drawItemValueAuto(&gsensorEntry);		 
        drawItemValueBehind(&gsensorEntry);
        if (keepresult == 0){
            keepresult++;
           gsensorEntry.state = TEST_PASS;
           setProinfoItemResult(gsensorEntry.id,gsensorEntry.state);
        }
        usleep(10000);
    }
    gsensor_close(acc);
    LOGD(TAG "%s: Exit\n", __FUNCTION__);    
    if (err){
        gsensorEntry.state = TEST_FAIL;
        setProinfoItemResult(gsensorEntry.id,gsensorEntry.state);
    }
    pthread_exit(NULL);
    
    return NULL;
}

static pthread_mutex_t gsensor_mutex = PTHREAD_MUTEX_INITIALIZER;
int gsensor_start()
{

    struct acc_data *dat = (struct acc_data *)malloc(sizeof(struct acc_data));
    memset(dat,0,sizeof(struct acc_data));
    int err, len;
    autoflag==0;

    LOGD(TAG "%s\n", __FUNCTION__);

    gsensor_init_priv(&dat->acc);
    len = snprintf(gsensorEntry.value.name, sizeof(gsensorEntry.value.name), "%s\n", uistr_info_sensor_initializing);
    dat->exit_thd = false;  
    


#ifndef JGENSORMANMAL
    drawItemValueAuto(&gsensorEntry);
    pthread_create(&dat->update_thd, NULL, gsensor_update_auto_thread, dat);
    do {
		//add for aoto test by
		if(autoflag==1){
			 //dat->mod->test_result = FTM_TEST_PASS;
			gsensorEntry.state = TEST_PASS;
			gsensor_thread_exit = true;
		}else if(autoflag==2){
			//dat->mod->test_result = FTM_TEST_FAIL;
			gsensorEntry.state = TEST_FAIL;
			gsensor_thread_exit = true;
		}
	    if (gsensor_thread_exit) {
	        dat->exit_thd = true;
		    autoflag=0;
	        break;
	    } 

        pthread_mutex_lock (&gsensor_mutex);
        if (gsensor_thread_exit) {
            dat->exit_thd = true;
            pthread_mutex_unlock (&gsensor_mutex);
            break;
        }else{
            pthread_mutex_unlock (&gsensor_mutex);
            usleep(50000);
        }        
    } while (gensorthread_run);
#else
    drawItemValueBehind(&gsensorEntry);
    pthread_create(&dat->update_thd, NULL, gsensor_update_manual_thread, dat);
#endif
    pthread_join(dat->update_thd, NULL);
    if(dat!=NULL)free(dat);
    return 0;
}



void * jlink_gsensor_start(void*para){

    gensorthread_run = 1;
    drawTestItem(&gsensorEntry);
    gsensor_start();
    pthread_exit(NULL);
    return NULL;
}

void jlink_gsensor_stop(){
    gensorthread_run = 0;
}