#include "jlinkui.h"
#include "graphics.h"
#include <dirent.h>
#include <poll.h>


#define LEFTRODX 200
#define RODY 200
#define RIGHTRODX 800
#define CILCLE_BIG 90
#define CILCLE_SMALL 40
#define BIGCIRCLE_COLOR 0xffffff44
#define BIGCIRCLELINE_CLOR 0xdddddd44
#define SMALLCIRCLE_COLOR 0xbb111166
#define SMALLCIRCLELINE_COLOR 0xcc000055

gr_surface big_surface;
gr_surface sma_surface;
static int big_width;
static int big_height;
static int half_big_width;
static int half_big_height;
static int small_width;
static int small_height;
static int half_small_width;
static int half_small_height;

static int org_lef_x;
static int org_lef_y;
static int dst_lef_x;
static int dst_lef_y;
static int org_rig_x;
static int org_rig_y;
static int dst_rig_x;
static int dst_rig_y;

static int left_clear_X1;
static int left_clear_Y1;
static int left_clear_X2;
static int left_clear_Y2;

static int right_clear_X1;
static int right_clear_Y1;
static int right_clear_X2;
static int right_clear_Y2;

struct Points{
	int x;
	int y;
	int z;
	int rz;
};

static int equeu_start = 0;
static int equeu_num = 0;
struct Points point_equeus[1024];

static pthread_mutex_t pointMutex;
void add_points(x,y,z,rz){
	
	point_equeus[equeu_num].x = x;
	point_equeus[equeu_num].y = y;
	point_equeus[equeu_num].z = z;
	point_equeus[equeu_num].rz = rz;
	//pthread_mutex_lock(&pointMutex);
	equeu_num++;
	if (equeu_num == 1024){
		equeu_num = 0;
	}
	//pthread_mutex_unlock(&pointMutex);
}


int getPoint(){
	
	int num = equeu_start;
	//pthread_mutex_lock(&pointMutex);
	equeu_start++;
	if (equeu_start == 1024){
		equeu_start = 0;
	}
	//pthread_mutex_unlock(&pointMutex);
	return num;
}

void setPoint(int start){
	pthread_mutex_lock(&pointMutex);
	equeu_start = start;
	pthread_mutex_unlock(&pointMutex);
}



extern int res_create_surface(const char* fname, gr_surface* pSurface);
static void* StartRodEvenet(void*param);
static int gamekeyrun = 1;
static int oldx,oldy,oldz,oldrz;
static int leftx,lefty,rightx,righty;//左小圆的坐标
static int x,y,z,rz;
static pthread_mutex_t drawMutex = PTHREAD_MUTEX_INITIALIZER;
static int isdraw = 0;
static volatile int needdraw,needdraw1,needdraw2;
void drawCircleRod(int x,int y,int z,int rz){
	//pthread_mutex_lock(&drawMutex);
	isdraw = 1;
	if (x != oldx || y != oldy){
		oldx = x;
		oldy = y;
		//清除原来的视图
		set_gr_color(BACKCOLOR);
		gr_fill(LEFTRODX-CILCLE_BIG-CILCLE_SMALL,RODY-CILCLE_BIG-CILCLE_SMALL,
			LEFTRODX+CILCLE_BIG+CILCLE_SMALL,RODY+CILCLE_BIG+CILCLE_SMALL);

		leftx = (int)(LEFTRODX + (float)x/255*CILCLE_BIG);
		lefty = (int)(RODY + (float)y/255*CILCLE_BIG);
		set_gr_color(BIGCIRCLE_COLOR);
		jlinkdrawRealCircle(LEFTRODX,RODY,CILCLE_BIG);
		set_gr_color(BIGCIRCLELINE_CLOR);
		gr_circle(LEFTRODX,RODY,CILCLE_BIG);

		set_gr_color(SMALLCIRCLE_COLOR);
		jlinkdrawRealCircle(leftx,lefty,CILCLE_SMALL);
		set_gr_color(SMALLCIRCLELINE_COLOR);
		gr_circle(leftx,lefty,CILCLE_SMALL);
		//LOGD("MYTEST leftx=%d,lefty=%d",leftx,lefty);
	}

	if (z != oldz || rz != oldrz){
		oldz = z;
		oldrz = rz;
		//清除原来的视图
		set_gr_color(BACKCOLOR);
		gr_fill(RIGHTRODX-CILCLE_BIG-CILCLE_SMALL,RODY-CILCLE_BIG-CILCLE_SMALL,
			RIGHTRODX+CILCLE_BIG+CILCLE_SMALL,RODY+CILCLE_BIG+CILCLE_SMALL);

		rightx = (int)(RIGHTRODX + (float)z/255*CILCLE_BIG);
		righty = (int)(RODY + (float)rz/255*CILCLE_BIG);
		set_gr_color(BIGCIRCLE_COLOR);
		jlinkdrawRealCircle(RIGHTRODX,RODY,CILCLE_BIG);
		set_gr_color(BIGCIRCLELINE_CLOR);
		gr_circle(RIGHTRODX,RODY,CILCLE_BIG);

		set_gr_color(SMALLCIRCLE_COLOR);
		jlinkdrawRealCircle(rightx,righty,CILCLE_SMALL);
		set_gr_color(SMALLCIRCLELINE_COLOR);
		gr_circle(rightx,righty,CILCLE_SMALL);
		//LOGD("MYTEST rightx=%d,righty=%d",rightx,righty);
	}
	gr_flip();
	isdraw = 0;
	//pthread_mutex_unlock(&drawMutex);
}

void* doDrawRod1(void*param){
	while(gamekeyrun){
		if (needdraw1){
			oldx = x;
			oldy = y;
			LOGD("MYTEST x=%d,y=%d",x,y);
			//清除原来的视图
			//pthread_mutex_lock(&drawMutex);
			set_gr_color(BACKCOLOR);
			gr_fill(LEFTRODX-CILCLE_BIG-CILCLE_SMALL,RODY-CILCLE_BIG-CILCLE_SMALL,
				LEFTRODX+CILCLE_BIG+CILCLE_SMALL,RODY+CILCLE_BIG+CILCLE_SMALL);

			leftx = (int)(LEFTRODX + (float)x/255*CILCLE_BIG);
			lefty = (int)(RODY + (float)y/255*CILCLE_BIG);
			set_gr_color(BIGCIRCLE_COLOR);
			jlinkdrawRealCircle(LEFTRODX,RODY,CILCLE_BIG);
			set_gr_color(BIGCIRCLELINE_CLOR);
			gr_circle(LEFTRODX,RODY,CILCLE_BIG);

			set_gr_color(SMALLCIRCLE_COLOR);
			jlinkdrawRealCircle(leftx,lefty,CILCLE_SMALL);
			set_gr_color(SMALLCIRCLELINE_COLOR);
			gr_circle(leftx,lefty,CILCLE_SMALL);
			gr_flip();
			needdraw1=0;
			//pthread_mutex_unlock(&drawMutex);
			
		}
	}
	return NULL;
}

void* doDrawRod2(void*param){
	while(gamekeyrun){
		if (needdraw2){
			oldz = z;
			oldrz = rz;
			//清除原来的视图
			//pthread_mutex_lock(&drawMutex);
			set_gr_color(BACKCOLOR);
			gr_fill(RIGHTRODX-CILCLE_BIG-CILCLE_SMALL,RODY-CILCLE_BIG-CILCLE_SMALL,
				RIGHTRODX+CILCLE_BIG+CILCLE_SMALL,RODY+CILCLE_BIG+CILCLE_SMALL);

			rightx = (int)(RIGHTRODX + (float)z/255*CILCLE_BIG);
			righty = (int)(RODY + (float)rz/255*CILCLE_BIG);
			set_gr_color(BIGCIRCLE_COLOR);
			jlinkdrawRealCircle(RIGHTRODX,RODY,CILCLE_BIG);
			set_gr_color(BIGCIRCLELINE_CLOR);
			gr_circle(RIGHTRODX,RODY,CILCLE_BIG);

			set_gr_color(SMALLCIRCLE_COLOR);
			jlinkdrawRealCircle(rightx,righty,CILCLE_SMALL);
			set_gr_color(SMALLCIRCLELINE_COLOR);
			gr_circle(rightx,righty,CILCLE_SMALL);
			gr_flip();
			needdraw2=0;
			//pthread_mutex_unlock(&drawMutex);
			
		}
	}
	return NULL;
}

void* doDrawRod(void*param){
	while(gamekeyrun){
		if (needdraw){
			needdraw = 0;
			drawCircleRod(x,y,z,rz);	
		}	
	}
	return NULL;
}

static void* clip_loop(void*pram){
    while(gamekeyrun){
    	pthread_mutex_lock(&drawMutex);
    	LOGD("MYTEST gr_flip");
    	gr_flip();
	   	pthread_mutex_unlock(&drawMutex);
    	usleep(10000);
    }
    return NULL;
}



static void drawImage(int x, int y,char* path){
	gr_surface surface;
	int ret = res_create_surface(path,&surface);
	if(surface==NULL){
		return;
	}
	draw_image(x,y,(GRSurface*)surface);
}

static void drawSurfaceImage(int x, int y,gr_surface* surface){
	if(surface==NULL){
		return;
	}
	draw_image(x,y,(GRSurface*)surface);
}

static int draw_count = 0;
static void drawImageRod(){

	int num = getPoint();
	if (point_equeus[num].x != oldx && point_equeus[num].y != oldy){
		oldx = point_equeus[num].x;
		oldy = point_equeus[num].y;
		//set_gr_color(BACKCOLOR);
		gr_fill(left_clear_X1,left_clear_Y1,left_clear_X2,left_clear_Y2);
		dst_lef_x = (int)(org_lef_x + (float)point_equeus[num].x/255*half_big_width);
		dst_lef_y = (int)(org_lef_y + (float)point_equeus[num].y/255*half_big_height);
		gr_blit((GRSurface*)big_surface, 0, 0, big_width, big_height, LEFTRODX, RODY);
		gr_blit((GRSurface*)sma_surface, 0, 0, small_width, small_height, dst_lef_x, dst_lef_y);
	}
	
	if (point_equeus[num].z != oldz && point_equeus[num].rz != oldrz){
		oldz = point_equeus[num].z;
		oldrz = point_equeus[num].rz;
		//set_gr_color(BACKCOLOR);
		gr_fill(right_clear_X1,right_clear_Y1,right_clear_X2,right_clear_Y2);
		dst_rig_x = (int)(org_rig_x + (float)point_equeus[num].z/255*half_big_width);
		dst_rig_y = (int)(org_rig_y + (float)point_equeus[num].rz/255*half_big_height);
		gr_blit((GRSurface*)big_surface, 0, 0, big_width, big_height, RIGHTRODX, RODY);
		gr_blit((GRSurface*)sma_surface, 0, 0, small_width, small_height, dst_rig_x, dst_rig_y);
	}
	LOGD("MYTEST startDraw");
	gr_flip();
	
}


void * drawImageRodThead(void*param){
	while(gamekeyrun){
		//LOGD("MYTEST equeu_num=%d,equeu_start=%d",equeu_num,equeu_start);
		if (equeu_num != equeu_start){
			drawImageRod();
		}
	}
	return NULL;
}
	

static pthread_t circle_handle;
static pthread_t circle1_handle;
static pthread_t circle2_handle;
static pthread_t loopflip_handle;
static pthread_t drawimage_handle;
static pthread_t event_handle;
void drawKeyPad(){
	/*
	isdraw = 0;
	draw_count = 0;
	set_gr_color(BACKCOLOR);
	oldx = -256,oldy=-256,oldz=-256,oldrz=-256;
	//drawCircleRod(0,0,0,0);
	//pthread_create(&circle_handle,NULL,doDrawRod,NULL);
	//pthread_create(&circle1_handle,NULL,doDrawRod1,NULL);
	//pthread_create(&circle2_handle,NULL,doDrawRod2,NULL);
	//pthread_create(&loopflip_handle,NULL,clip_loop,NULL);
	
	int ret = res_create_surface("/vendor/res/images/big.png",&big_surface);
	if (ret != 0){
		LOGD("MYTEST drawImageRod error0 ret=%d,errno=%d",ret,errno);
		return;
	}
	big_width = gr_get_width(big_surface);
	big_height = gr_get_height(big_surface);
	ret = res_create_surface("/vendor/res/images/small.png",&sma_surface);
	if (ret != 0){
		LOGD("MYTEST drawImageRod error1");
		return;
	}
	small_width = gr_get_width(sma_surface);
	small_height = gr_get_height(sma_surface);

	left_clear_X1 = LEFTRODX-small_width/2;
	left_clear_Y1 = RODY - small_height/2;
	left_clear_X2 = LEFTRODX+small_width/2+big_width;
	left_clear_Y2 = RODY + small_height/2 + big_height;

	right_clear_X1 = RIGHTRODX-small_width/2;
	right_clear_Y1 = left_clear_Y1;
	right_clear_X2 = RIGHTRODX+small_width/2+big_width;
	right_clear_Y2 = left_clear_Y2;
	LOGD("MYTEST left x1:%d,y1:%d x2:%d,y2:%d",left_clear_X1,left_clear_Y1,left_clear_X2,left_clear_Y2);
	LOGD("MYTEST right x1:%d,y1:%d x2:%d,y2:%d",right_clear_X1,right_clear_Y1,right_clear_X2,right_clear_Y2);
	org_lef_x = LEFTRODX+(big_width-small_width)/2;
	org_lef_y = RODY+(big_height-small_height)/2;
	org_rig_x = RIGHTRODX+(big_width-small_width)/2;
	org_rig_y = org_lef_y;

	half_big_width = big_width/2;
	half_big_height = big_height/2;

	drawImageRod();
	equeu_num = 0;
	equeu_start = 0;
	*/
	//pthread_create(&drawimage_handle,NULL,drawImageRodThead,NULL);
	//pthread_create(&event_handle,NULL,StartRodEvenet,NULL);
	//StartRodEvenet();
	//pthread_join(drawimage_handle,NULL);
	//pthread_join(event_handle,NULL);
	//pthread_join(circle_handle,NULL);
	//pthread_join(circle1_handle,NULL);
	//pthread_join(circle2_handle,NULL);
	//pthread_join(loopflip_handle,NULL);
/*
	set_gr_color(0xaaaaaaff);
	jlinkdrawRectangle3(220,30,60,60,3*jpi/4);
	gr_fill( 240, 33, 320, 87);

	gr_fill( 1580, 33, 1660, 87);
	jlinkdrawRectangle3(1680,30,60,60,jpi/4);

	jlinkdrawRectangle(200,200,100,80,jpi/3,0);
	jlinkdrawRectangle(350,200,100,80,jpi/3,0);
	jlinkdrawRectangle(500,200,100,80,jpi/3,0);
	jlinkdrawRectangle(650,200,100,80,jpi/3,0);

	jlinkdrawRectangle(830,200,200,80,jpi/3,1);

	jlinkdrawRectangle(1110,200,100,80,2*jpi/3,0);
	jlinkdrawRectangle(1260,200,100,80,2*jpi/3,0);
	jlinkdrawRectangle(1410,200,100,80,2*jpi/3,0);
	jlinkdrawRectangle(1560,200,100,80,2*jpi/3,0);

	gr_fill( 460, 350, 560, 420);
	jlinkdrawRectangle2(1300,350,70,70,jpi*3/8);

	gr_fill( 360, 700, 430, 770);//left
	gr_fill( 430, 700, 500, 780);//center
	gr_fill( 500, 700, 570, 770);//right
	gr_fill( 430, 630, 500, 700);//up
	gr_fill( 430, 770, 500, 840);//down

	//X
	jlinkdrawRealCircle(1200,730,40);
	//Y
	jlinkdrawRealCircle(1280,650,40);
	//A0
	jlinkdrawRealCircle(1280,810,40);
	//B
	jlinkdrawRealCircle(1360,730,40);
*/
}

static struct pollfd pfd;
static void* StartRodEvenet(void*param){
	DIR *dir;
	struct dirent *de;
	char name[100];
	dir = opendir("/dev/input");
	int fd;
	if (dir != NULL)
	{
		while(de = readdir(dir)){
			if(strncmp(de->d_name,"event",5)) continue;
			fd = openat(dirfd(dir), de->d_name, O_RDONLY);
            if(fd < 0) continue;

            ioctl(fd, EVIOCGNAME(sizeof(name) - 1), name);
            LOGD("MYTEST1,StartRodEvenet name=%s",name);
            if (strlen(name) == 38 && !strncmp(name, "Austria Microsystem jlink_joy joystick", 7)) {
            	pfd.fd = fd;
            	pfd.events = POLLIN;
            	break;
            }else{
            	close(fd);
            	fd = -1;
            }
		}
		closedir(dir);
	}

	if (fd == -1){
		LOGE("MYTEST StartRodEvenet open event error");
		return NULL;
	}
	int ret;
	struct input_event ev;
	x=0,y=0,z=0,rz=0;
	int times = 0;
	do{
		ret = poll(&pfd,1,0);
		if (ret >0){
			if(pfd.revents & POLLIN){
				ret = read(pfd.fd, &ev, sizeof(ev));
				if(ret == sizeof(ev)) {
					LOGD("MYTEST ev.type=%d,ev.code=%d,ev->value=%d",ev.type,ev.code,ev.value);
					
					if (ev.type == EV_ABS){
						if (ev.code == ABS_X){
							x = ev.value;
						}else if (ev.code == ABS_Y){
							y = ev.value;
						}else if (ev.code == ABS_Z){
							z = ev.value;
						}else if (ev.code == ABS_RZ){
							rz = ev.value;
						}
					}else if (ev.type==EV_SYN){
						//add_points(x,y,z,rz);
						drawImageRod();
						//LOGD("MYTEST x:%d,y:%d oldx:%d,oldy:%d z:%d,rz:%d",
						//	x,y,oldx,oldy,z,rz);
					}	
				}
			}
		}
	}while(gamekeyrun);
	close(fd);
	return NULL;
}