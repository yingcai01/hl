#include "jlinkui.h"
#define TOUCH_W 40
#define LINE_SOLD 2
#define TP_DATA_COUNT 60

#define Y_high 10
struct jlink_detect_data {
	int count_up[TP_DATA_COUNT];
	int count_left[TP_DATA_COUNT];
	int count_down[TP_DATA_COUNT];
	int count_right[TP_DATA_COUNT];
	int count_oblique1[TP_DATA_COUNT];//对角线
	int count_oblique2[TP_DATA_COUNT];//对角线
};
static struct jlink_detect_data detect_data;
extern int jlcd_width;
extern int jlcd_height;
pthread_mutex_t jlink_tp_mutext;
static void clear_detect_data(void)
{
	int i = 0;
	while(i < TP_DATA_COUNT)
	{
		detect_data.count_up[i] = 0;
		detect_data.count_left[i] = 0;
		detect_data.count_down[i] = 0;
		detect_data.count_right[i] = 0;
		detect_data.count_oblique1[i] = 0;
		detect_data.count_oblique2[i] = 0;
		i++;
	}
}

static int check_tpresult(){
	int i = 0;
	while(i < jlcd_width/TOUCH_W){
		if (detect_data.count_up[i] != 1 || detect_data.count_down[i] != 1){
			return 0;
		}else{
			i++;
		}
	}
	i = 0;
	while(i < jlcd_height/TOUCH_W){
		if (detect_data.count_left[i] != 1 || detect_data.count_right[i] != 1){
			return 0;
		}else{
			i++;
		}
	}

	i = 0;
	while(i < jlcd_height/TOUCH_W){
		if (detect_data.count_oblique1[i] != 1 || detect_data.count_oblique2[i] != 1){
			return 0;
		}else{
			i++;
		}
	}
	return 1;
}

static int isTestOver = 0;
extern void ui_clear_key_queue();
static void* wait_quit(void*param){
	struct timespec ntime;
	ntime.tv_sec= time(NULL)+20;
	ntime.tv_nsec=0;
	ui_clear_key_queue();
	int key;
	while(1){
		key = jlink_wait_key(&ntime);
		if (isTestOver) break;
		if(key==114 || key == 115 || key == 116){
			setJlinkTptest(0);
			setProinfoItemResult(JILNK_ITEM_TOUCH, TEST_FAIL);
			pthread_mutex_unlock(&jlink_tp_mutext);
			break;
		}
	}
	pthread_exit(NULL);
	return NULL;
}
static void drawSideRectangle(){
	clearScreen();
	//设置颜色红色
	ui_color(255, 0, 0, 255);
	//绘制外方框
	ui_line(0,0+Y_high,jlcd_width,0,LINE_SOLD);
	ui_line(jlcd_width,0+Y_high,jlcd_width,jlcd_height,LINE_SOLD);
	ui_line(jlcd_width,jlcd_height+Y_high,0,jlcd_height,LINE_SOLD);
	ui_line(0,jlcd_height+Y_high,0,0,LINE_SOLD);
	//绘制间隔
	int src_x,src_y,dst_x,dst_y;
	src_x = TOUCH_W;
	src_y = 0;
	dst_x = src_x;
	dst_y = TOUCH_W;
	while(src_x<jlcd_width){
		ui_line(src_x,src_y,dst_x,dst_y,LINE_SOLD);
		src_x += TOUCH_W;
		dst_x = src_x;
	}

	src_x = jlcd_width-TOUCH_W;
	src_y = TOUCH_W;
	dst_x = jlcd_width;
	dst_y = src_y;
	while(src_y<jlcd_height){
		ui_line(src_x,src_y,dst_x,dst_y,LINE_SOLD);
		src_y += TOUCH_W;
		dst_y = src_y;
	}

	src_x = jlcd_width-TOUCH_W;
	src_y = jlcd_height - TOUCH_W;
	dst_x = src_x;
	dst_y = jlcd_height;
	while(src_x>0){
		ui_line(src_x,src_y,dst_x,dst_y,LINE_SOLD);
		src_x -= TOUCH_W;
		dst_x = src_x;
	}

	src_x = 0;
	src_y = jlcd_height - TOUCH_W;;
	dst_x = TOUCH_W;
	dst_y = src_y;
	while(src_y>0){
		ui_line(src_x,src_y,dst_x,dst_y,LINE_SOLD);
		src_y -= TOUCH_W;
		dst_y = src_y;
	}

	//绘制内框
	ui_line(TOUCH_W,TOUCH_W,jlcd_width-TOUCH_W,TOUCH_W,LINE_SOLD);
	ui_line(jlcd_width-TOUCH_W,TOUCH_W,jlcd_width-TOUCH_W,jlcd_height-TOUCH_W,LINE_SOLD);
	ui_line(jlcd_width-TOUCH_W,jlcd_height-TOUCH_W,TOUCH_W,jlcd_height-TOUCH_W,LINE_SOLD);
	ui_line(TOUCH_W,jlcd_height-TOUCH_W,TOUCH_W,TOUCH_W,LINE_SOLD);

	//绘制交错线框
	ui_line(TOUCH_W,0,jlcd_width,(jlcd_width-TOUCH_W)*jlcd_height/jlcd_width,LINE_SOLD);
	ui_line(0,TOUCH_W,(jlcd_height-TOUCH_W)*jlcd_width/jlcd_height,jlcd_height,LINE_SOLD);
	ui_line(jlcd_width-TOUCH_W,0,0,(jlcd_width-TOUCH_W)*jlcd_height/jlcd_width,LINE_SOLD);
	ui_line(jlcd_width,TOUCH_W,jlcd_width-(jlcd_height-TOUCH_W)*jlcd_width/jlcd_height,jlcd_height,LINE_SOLD);
	
	//绘制交错线框间隔
	int length = TOUCH_W+ TOUCH_W*jlcd_width/jlcd_height;//线条长度
	int x_mar = TOUCH_W*jlcd_width/jlcd_height;//x的间隔
	src_x = 0;
	src_y = TOUCH_W;;
	dst_x = src_x + length;
	dst_y = src_y;
	while(src_y<jlcd_height){
		ui_line(src_x,src_y,dst_x,dst_y,LINE_SOLD);
		src_y += TOUCH_W;
		dst_y = src_y;
		src_x += x_mar;
		dst_x = src_x + length;
	}
	src_x = jlcd_width;
	src_y = TOUCH_W;;
	dst_x = src_x - length;
	dst_y = src_y;
	while(src_y<jlcd_height){
		ui_line(src_x,src_y,dst_x,dst_y,LINE_SOLD);
		src_y += TOUCH_W;
		dst_y = src_y;
		src_x -= x_mar;
		dst_x = src_x - length;
	}
	//gr_flip();
	//wait_quit();
}


void jlink_detect_point(int x,int y){
	int src_x,src_y;
	//up
	
	if (TOUCH_W > y){
		src_x = x/TOUCH_W*TOUCH_W;
		src_y = 0;
		ui_color(0, 128, 0, 255);
		ui_line(src_x,src_y,src_x+TOUCH_W,src_y,4);
		ui_line(src_x+TOUCH_W,src_y,src_x+TOUCH_W,src_y+TOUCH_W,4);
		ui_line(src_x+TOUCH_W,src_y+TOUCH_W,src_x,src_y+TOUCH_W,4);
		ui_line(src_x,src_y+TOUCH_W,src_x,src_y,4);
		
		if (x > jlcd_width -TOUCH_W){
			ui_line(jlcd_width,0,jlcd_width,TOUCH_W,4);//可能最后的框未正好分配完
		}
		ui_color(255, 255, 255, 255);
		detect_data.count_up[x/TOUCH_W] = 1;
	}
	//right
	if (TOUCH_W > (jlcd_width-x)){
		src_x = x/TOUCH_W*TOUCH_W;
		src_y = y/TOUCH_W*TOUCH_W;
		ui_color(0, 128, 0, 255);
		ui_line(src_x,src_y,src_x+TOUCH_W,src_y,4);
		ui_line(src_x+TOUCH_W,src_y,src_x+TOUCH_W,src_y+TOUCH_W,4);
		ui_line(src_x+TOUCH_W,src_y+TOUCH_W,src_x,src_y+TOUCH_W,4);
		ui_line(src_x,src_y+TOUCH_W,src_x,src_y,4);
		
		if (y >jlcd_height - TOUCH_W){
			ui_line(jlcd_width,jlcd_height,jlcd_width-TOUCH_W,jlcd_height,4);
		}
		ui_color(255, 255, 255, 255);
		detect_data.count_right[y/TOUCH_W] = 1;
	}
	//down
	if (y > (jlcd_height - TOUCH_W)){
		src_x = x/TOUCH_W*TOUCH_W;
		src_y = y/TOUCH_W*TOUCH_W;
		ui_color(0, 128, 0, 255);
		ui_line(src_x,src_y,src_x+TOUCH_W,src_y,4);
		ui_line(src_x+TOUCH_W,src_y,src_x+TOUCH_W,src_y+TOUCH_W,4);
		ui_line(src_x+TOUCH_W,src_y+TOUCH_W,src_x,src_y+TOUCH_W,4);
		ui_line(src_x,src_y+TOUCH_W,src_x,src_y,4);
		
		if (x < TOUCH_W)//线条是从右往左,左边可能分配不完整
		{
			ui_line(0,jlcd_height-TOUCH_W,0,jlcd_height,4);
		}
		ui_color(255, 255, 255, 255);	
		detect_data.count_down[x/TOUCH_W] = 1;
	}
	//left
	if (x < TOUCH_W){
		src_x = 0;
		src_y = y/TOUCH_W*TOUCH_W;
		ui_color(0, 128, 0, 255);
		ui_line(src_x,src_y,src_x+TOUCH_W,src_y,4);
		ui_line(src_x+TOUCH_W,src_y,src_x+TOUCH_W,src_y+TOUCH_W,4);
		ui_line(src_x+TOUCH_W,src_y+TOUCH_W,src_x,src_y+TOUCH_W,4);
		ui_line(src_x,src_y+TOUCH_W,src_x,src_y,4);
		
		if (x < TOUCH_W)//线条是从右往左,左边可能分配不完整
		{
			ui_line(0,jlcd_height-TOUCH_W,0,jlcd_height,4);
		}
		ui_color(255, 255, 255, 255);
		detect_data.count_left[y/TOUCH_W] = 1;
	}
	
	

	//对角线
	//直线方程 y = H/W*x + L; y = H/W*x-H/W*L;
	//	H/W*x-H/W*L < y < H/W*x + L
	if (jlcd_width*y <= (jlcd_height*x + TOUCH_W*jlcd_width) &&
		(jlcd_height*x -jlcd_height*TOUCH_W) <= jlcd_width*y){
		ui_color(0, 128, 0, 255);
		int length = TOUCH_W+ TOUCH_W*jlcd_width/jlcd_height;//线条长度
		int x_mar = TOUCH_W*jlcd_width/jlcd_height;//x的间隔
		if (y < TOUCH_W){
			ui_line(TOUCH_W,0,length,TOUCH_W,4);
			ui_line(0,TOUCH_W,length,TOUCH_W,4);
		}else{
			src_y = y/TOUCH_W*TOUCH_W;
			src_x = (y/TOUCH_W - 1)*x_mar;
			ui_line(src_x,src_y,src_x+length,src_y,4);
			ui_line(src_x+length,src_y,src_x+length+x_mar,src_y+TOUCH_W,4);
			ui_line(src_x+length+x_mar,src_y+TOUCH_W,src_x+x_mar,src_y+TOUCH_W,4);
			ui_line(src_x+x_mar,src_y+TOUCH_W,src_x,src_y,4);
		}
		ui_color(255, 255, 255, 255);
		detect_data.count_oblique1[y/TOUCH_L1] = 1;
	}
	
	//直线方程 y = -H/W*x -H/W*L + H；y = -H/W*x + H + L
	if (jlcd_height*jlcd_width <= (jlcd_width*y + jlcd_height*x + jlcd_height*TOUCH_W) &&
		y*jlcd_width + jlcd_height*x <= (jlcd_width*jlcd_height + jlcd_width*TOUCH_W)){
		int length = TOUCH_W+ TOUCH_W*jlcd_width/jlcd_height;//线条长度
		int x_mar = TOUCH_W*jlcd_width/jlcd_height;//x的间隔
		ui_color(0, 128, 0, 255);
		if (y < TOUCH_W){
			ui_line(jlcd_width-TOUCH_W,0,jlcd_width-length,TOUCH_W,4);
			ui_line(jlcd_width,TOUCH_W,jlcd_width-length,TOUCH_W,4);
		}else{
			src_y = y/TOUCH_W*TOUCH_W;
			src_x = jlcd_width - (y/TOUCH_W - 1)*x_mar;
			ui_line(src_x,src_y,src_x-length,src_y,4);
			ui_line(src_x-length,src_y,src_x-length-x_mar,src_y+TOUCH_W,4);
			ui_line(src_x-length-x_mar,src_y+TOUCH_W,src_x-x_mar,src_y+TOUCH_W,4);
			ui_line(src_x-x_mar,src_y+TOUCH_W,src_x,src_y,4);
		}
		ui_color(255, 255, 255, 255);
		detect_data.count_oblique2[y/TOUCH_L1] = 1;
	}

	//gr_flip();
	//LOGD("MYTEST jlink_detect_point x=%d,y=%d",x,y);
	if (check_tpresult()){
		isTestOver = 1;
		setJlinkTptest(0);
		setProinfoItemResult(JILNK_ITEM_TOUCH, TEST_PASS);
		pthread_mutex_unlock(&jlink_tp_mutext);
	}
}

static pthread_t jlink_tphandle;
void jlink_tp_touch(){
	isTestOver = 0;
	setJlinkTptest(1);
	pthread_mutex_lock(&jlink_tp_mutext);
	clear_detect_data();
	drawSideRectangle();
	pthread_create(&jlink_tphandle,NULL,wait_quit,NULL);
}

