#include "jlinkui.h"


extern void update_Text_Info(void *pApInfo, char *output_buf, int buf_len);
extern int FM_WIFI_init(char *output_buf, int buf_len, int *p_result);
extern int FM_WIFI_deinit(void);
extern int wifi_disconnect(void);
extern int wifi_fm_test(void);
extern int wifi_update_status(void);


extern TestEntry wifiEntry;
extern Button wifibutton;
ButtonEntry wifibtnentry;
static void *wifi_update_info(void *pram)
{
	int result = 0;;

    char *wifi_test_error_str[] = {uistr_info_wifi_iface_err, uistr_info_wifi_fail_scan, uistr_info_wifi_no_scan_res,
                                   uistr_info_wifi_connect_err, uistr_info_wifi_no_ap};
    int error_index = 0;

    LOGD(TAG "%s: Start\n", __FUNCTION__);

    //update_Text_Info(NULL, wififm->info, sizeof(wififm->info));
    memset(wifiEntry.value.name,0, sizeof(wifiEntry.value.name));
    sprintf(wifiEntry.value.name, "%s : %s\n", uistr_info_wifi_status, uistr_info_wifi_start);
    //iv->redraw(iv);
    drawItemValueBehindLine(&wifiEntry);

    if( FM_WIFI_init(wifiEntry.value.name, sizeof(wifiEntry.value.name), &result) < 0) {
        LOGE("[WIFI] FM_WIFI_init failed!\n");
        sprintf(wifiEntry.value.name, "%s : %s\n", uistr_info_wifi_status, uistr_info_wifi_init_fail);
        //iv->redraw(iv);
        drawItemValueBehindLine(&wifiEntry);
        wifiEntry.state = TEST_FAIL;
        goto init_fail;
    }

    memset(wifiEntry.value.name,0, sizeof(wifiEntry.value.name));
    wifiEntry.value.color=YELLOWCOLOR;/////////////
    sprintf(wifiEntry.value.name, "%s : %s\n", uistr_info_wifi_status, uistr_info_wifi_scanning);
    //iv->redraw(iv);
    drawItemValueBehindLine(&wifiEntry);
    int num = 0;
	int search_times = 0;
	while(num++ < 50) 
	{
		  //1. disconnect the connection.
        wifi_disconnect();
		if(search_times%500 == 0)
		{
			LOGD("wifi_search_times : 000and%d\n",search_times);
		}
		error_index = wifi_fm_test();
		if(error_index > 0){
		    LOGD("[wifi_update_thread] %s!\n", wifi_test_error_str[error_index-1]);
			sprintf(wifiEntry.value.name, "%s : %s\n", uistr_info_wifi_error, wifi_test_error_str[error_index-1]);
		    //iv->redraw(iv);
			drawItemValueBehindLine(&wifiEntry);
			wifiEntry.state = TEST_FAIL;
		}else{
			int count =100;
		    //iv->redraw(iv);
		   // wifientry->value.color=GREENCOLOR;
		   // wifientry->state = TEST_PASS;
			drawItemValueBehindLine(&wifiEntry);
		    while(count-- >0){
				search_times++;
				if(wifi_update_status() < 0){
					if(count){
				        LOGD("MYTEST count=%d",count);
						wifiEntry.value.color=YELLOWCOLOR;
				        usleep(1000);
				    }
					else if(num == 50)
					{
		                //memset(wifientry->value.name,0, sizeof(wifientry->value.name));
						wifiEntry.value.color=REDCOLOR;
						wifiEntry.state = TEST_FAIL;
						sprintf(wifiEntry.value.name, "%s : %s", uistr_info_wifi_status, uistr_info_wifi_timeout);
						 //wifientry->value.color=REDCOLOR;
						 //wifientry->state = TEST_FAIL;
						drawItemValueBehindLine(&wifiEntry);
						break;
					}
				}
				else/* if(count == 0)*/ //在函数wifi_update_status返回值不小于0的时候，第一次成功就退出循环检测连接
				{
					wifiEntry.value.color=GREENCOLOR;
					wifiEntry.state = TEST_PASS;
					//goto init_fail;
					setProinfoItemResult(wifiEntry.id,wifiEntry.state);
					drawItemValueBehindLine(&wifiEntry);
					DrawButtonBehindEntry(&wifibutton,&wifiEntry);
					LOGD("wifi_search_times : 111and%d\n",search_times);
					return NULL;
		        }
		        //iv->redraw(iv);
				drawItemValueBehindLine(&wifiEntry);
		    }
		}
	}


init_fail:
	wifiEntry.value.color=REDCOLOR;
	drawItemValueBehindLine(&wifiEntry);
    LOGD(TAG "%s: MYTEST Exit\n", __FUNCTION__);
    FM_WIFI_deinit();
    setProinfoItemResult(wifiEntry.id,wifiEntry.state);
	LOGD("wifi_search_times : 222and%d\n",search_times);
	DrawButtonBehindEntry(&wifibutton,&wifiEntry);
	return NULL;

}



void * jlink_wifi_start(void*para){
    /*
    TestEntry wifiEntry;
    int row = 0;
    if (para!=NULL)
    {
        row = *(int*)para;
    }

    memset(&wifiEntry,0,sizeof(wifiEntry));
    wifiEntry.entry.color = YELLOWCOLOR;
    wifiEntry.entry.row = row;
    wifiEntry.entry.backcolor = BACKCOLOR;
    wifiEntry.entry.col = ITEMCOL;
    strcpy(wifiEntry.entry.name,uistr_wifi);
    wifiEntry.value.color = REDCOLOR;
    wifiEntry.value.backcolor = BACKCOLOR;
    */
    drawTestItem(&wifiEntry);
    strcpy(wifiEntry.value.name,uistr_info_waiting);
    drawItemValueBehindLine(&wifiEntry);
   
	initTestButton(&wifibutton,wifi_update_info);
    wifibtnentry.btn = &wifibutton;
    wifibtnentry.next = NULL;
    addButtionCallback(&wifibtnentry);
    wifi_update_info(NULL);
    return NULL;
}
