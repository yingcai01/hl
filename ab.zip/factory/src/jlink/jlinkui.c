#include <ctype.h>
#include <dirent.h>
#include <poll.h>
#include "graphics.h"
#include "miniui.h"
#include "jlinkui.h"
#define color_r(c)    (((c) >> 24) & 0xFF)
#define color_g(c)    (((c) >> 16) & 0xFF)
#define color_b(c)    (((c) >>  8) & 0xFF)
#define color_a(c)    (((c) >>  0) & 0xFF)



//static int BACKCOLOR = 0x157458ff;
/*static int BACKCOLOR = 0x000000ff;    
static int NOTESTCOLOR = 0x0000ffff;
static int PASSCOLOR = 0x00ff00ff;
static int FAILCOLOR = 0xff0000ff;*/

pthread_mutex_t rowMutex = PTHREAD_MUTEX_INITIALIZER;
int currentrow  = 0;
int PROJECT_TP = -1;
static void readJlinkTp();
int jlcd_width = 0;
int jlcd_height = 0;
int testarea_width = 0;//去掉边框的相机预览剩余的宽度

static pthread_mutex_t flipMutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t drawMutex = PTHREAD_MUTEX_INITIALIZER;
static isdoflip = 0;
void do_grflip(){
	if(isdoflip==1)return;
	isdoflip = 1;
	pthread_mutex_lock(&drawMutex);
	gr_flip();
    pthread_mutex_unlock(&drawMutex);
    isdoflip = 0;
}

void do_grfill(int x,int y,int x2, int y2,int color){
	pthread_mutex_lock(&drawMutex);
	set_gr_color(color);
    gr_fill(x,y,x2,y2);
    pthread_mutex_unlock(&drawMutex);
}

void do_grblit(gr_surface source, int sx, int sy, int w, int h, int dx, int dy,int color){
	pthread_mutex_lock(&drawMutex);
	set_gr_color(color);
    gr_blit(source, sx, sy, w, h, dx,dy);
    pthread_mutex_unlock(&drawMutex);
}

int do_grtext(GRFont *gr_font, int x, int y, const char *s,int color){
	int value = 0;
	pthread_mutex_lock(&drawMutex);
	set_gr_color(color);
    value = gr_text(gr_font, x, y, s);
    pthread_mutex_unlock(&drawMutex);
    return value;
}

void do_grline(int x1, int y1, int x2, int y2, int width,int color){
	pthread_mutex_lock(&drawMutex);
	set_gr_color(color);
    gr_line(x1,y1,x2,y2,width);
    pthread_mutex_unlock(&drawMutex);
}

void do_setcolor(int r, int g, int b, int a) {
    pthread_mutex_lock(&drawMutex);
    gr_color(r,g,b,a);
    pthread_mutex_unlock(&drawMutex);
}

void do_fill(int x, int y, int w, int h,int color) {
    pthread_mutex_lock(&drawMutex);
    set_gr_color(color);
    gr_fill(x,y,w,h);
    pthread_mutex_unlock(&drawMutex);
}


int getTextLength(const char *s)
{
    int length = 0;
    while(*s != 0)
    {
    	//LOGD(TAG":s=%d",*s);
		if((*s & 0x80) != 0)
        {
        	s += 2;
        	if (*s==0x80)
        	{
        		length +=1; 
        	}else{
        		length +=2;
        	}
        	         
        }
        else
        {
        	s += 1;
        	if(*s>127){
        		length += 2;
        	}else{
        		length += 1;
        	}
        }
    }
    return length;
}

void AnimaThread(void* para){
	int i = 0;
	//gr_color(0, 0, 0, 255);
	TestEntry *testentry = (TestEntry *)para;
	set_gr_color(testentry->entry.color);
	gr_text(gr_font_small, testentry->entry.col*CHAR_WIDTH_ITEM,(testentry->entry.row+1)*CHAR_HEIGHT_ITEM, "[");
	//gr_text(gr_font_small, (testentry->entry.col+0.5)*CHAR_WIDTH_ITEM,(testentry->entry.row+1)*CHAR_HEIGHT_ITEM, "-");
	gr_text(gr_font_small, (testentry->entry.col+1)*CHAR_WIDTH_ITEM,(testentry->entry.row+1)*CHAR_HEIGHT_ITEM, "]");
	while(!testentry->exit){		
		
    	set_gr_color(testentry->entry.color);
		if(i%4==0){
			gr_text(gr_font_small, (testentry->entry.col+0.5)*CHAR_WIDTH_ITEM,(testentry->entry.row+1)*CHAR_HEIGHT_ITEM, "\\");
		}else if(i%4==1){
			gr_text(gr_font_small, (testentry->entry.col+0.5)*CHAR_WIDTH_ITEM,(testentry->entry.row+1)*CHAR_HEIGHT_ITEM, "|");
		}else if(i%4==2){
			gr_text(gr_font_small, (testentry->entry.col+0.5)*CHAR_WIDTH_ITEM,(testentry->entry.row+1)*CHAR_HEIGHT_ITEM, "/");
		}else if(i%4==3){
			gr_text(gr_font_small, (testentry->entry.col+0.5)*CHAR_WIDTH_ITEM,(testentry->entry.row+1)*CHAR_HEIGHT_ITEM, "-");
		}
		//gr_flip();
#ifdef JLINK_ITEM_DEBUG
		do_grflip();
#endif
		usleep(1000000);
		set_gr_color(BACKCOLOR);
    	//gr_fill( (testentry->entry.col+0.5)*CHAR_WIDTH_ITEM, testentry->entry.row*CHAR_HEIGHT_ITEM, CHAR_WIDTH_ITEM, CHAR_HEIGHT_ITEM*2);
    	gr_fill((testentry->entry.col+0.5)*CHAR_WIDTH_ITEM, testentry->entry.row*CHAR_HEIGHT_ITEM,(testentry->entry.col+1)*CHAR_WIDTH_ITEM , (testentry->entry.row+1)*CHAR_HEIGHT_ITEM);
    	//LOGD(TAG":CHAR_WIDTH_ITEM=%d,CHAR_HEIGHT_ITEM=%d,testentry->entry.row*CHAR_HEIGHT_ITEM=%d",CHAR_WIDTH_ITEM,CHAR_HEIGHT_ITEM,testentry->entry.row*CHAR_HEIGHT_ITEM);
    	//gr_flip();
#ifdef JLINK_ITEM_DEBUG
    	do_grflip();
#endif
		
		i++;
	}
	set_gr_color(BACKCOLOR);
    gr_fill((testentry->entry.col+0.5)*CHAR_WIDTH_ITEM, testentry->entry.row*CHAR_HEIGHT_ITEM,(testentry->entry.col+1)*CHAR_WIDTH_ITEM , (testentry->entry.row+1)*CHAR_HEIGHT_ITEM);
    //gr_flip();
	if(testentry->state==NO_TEST){
		set_gr_color(NOTESTCOLOR);
		gr_text(gr_font_small, (testentry->entry.col+0.5)*CHAR_WIDTH_ITEM,(testentry->entry.row+1)*CHAR_HEIGHT_ITEM, "N");
	}else if(testentry->state==TEST_PASS){
		set_gr_color(PASSCOLOR);
		gr_text(gr_font_small, (testentry->entry.col+0.5)*CHAR_WIDTH_ITEM,(testentry->entry.row+1)*CHAR_HEIGHT_ITEM, "O");
	}else if(testentry->state==TEST_FAIL){
		set_gr_color(FAILCOLOR);
		gr_text(gr_font_small, (testentry->entry.col+0.5)*CHAR_WIDTH_ITEM,(testentry->entry.row+1)*CHAR_HEIGHT_ITEM, "X");
	}
	//gr_flip();
#ifdef JLINK_ITEM_DEBUG
	do_grflip();
#endif
}


void runAnima(TestEntry *testentry){
	pthread_create(&(testentry->pthread_handle), NULL, AnimaThread, (void*)testentry);	
}

void clearScreen(){
	pthread_mutex_lock(&drawMutex);
	set_gr_color(BACKCOLOR);
    //gr_color(50, 170, 84, 255);//透明度需一致,不然会出现无法清屏现象
    gr_fill(0, 0, jlcd_width, jlcd_height);
    //LOGD(TAG "jlcd_width = %d,jlcd_height=%d",jlcd_width,jlcd_height);
    //gr_flip();
#ifdef JLINK_ITEM_DEBUG
    gr_flip();
#endif
    pthread_mutex_unlock(&drawMutex);
}

void clearRow(int row){
	pthread_mutex_lock(&drawMutex);
	set_gr_color(BACKCOLOR);
    gr_fill(0, row*CHAR_HEIGHT_ITEM, jlcd_width,(row+1)*CHAR_HEIGHT_ITEM);
#ifdef JLINK_ITEM_DEBUG
    gr_flip();
#endif
    pthread_mutex_unlock(&drawMutex);
}

void drawTestItem(TestEntry *testentry){
	
    
	if (testentry==NULL){
		LOGD(TAG "drawTestItem testentry=NULL");
		return;
	}
	pthread_mutex_lock(&drawMutex);
	set_gr_color(testentry->entry.color);
	if (testentry->hasani){
		gr_text(gr_font_small, (testentry->entry.col+1.5)*CHAR_WIDTH_ITEM, (testentry->entry.row+1)*CHAR_HEIGHT_ITEM, testentry->entry.name);
		runAnima(testentry);
	}else{
		gr_text(gr_font_small, testentry->entry.col*CHAR_WIDTH_ITEM, (testentry->entry.row+1)*CHAR_HEIGHT_ITEM, testentry->entry.name);
	}
#ifdef JLINK_ITEM_DEBUG
	gr_flip();
#endif
	pthread_mutex_unlock(&drawMutex);

}

void drawAllItem(TestEntry *testentry,int num){
	int i=0;
	TestEntry *tementry = testentry;
	for(;i<num;i++){
		if (testentry->hasani){
			do_grtext(gr_font_small, (testentry->entry.col+1.5)*CHAR_WIDTH_ITEM, (testentry->entry.row+1)*CHAR_HEIGHT_ITEM, testentry->entry.name,tementry->entry.color);
			runAnima(testentry);
		}else{
			do_grtext(gr_font_small, testentry->entry.col*CHAR_WIDTH_ITEM, (testentry->entry.row+1)*CHAR_HEIGHT_ITEM, testentry->entry.name,tementry->entry.color);
		}
		tementry++;
	}
	//gr_flip();
#ifdef JLINK_ITEM_DEBUG
	do_grflip();
#endif
}

void drawUpdateTestItem(TestEntry *testentry){
	int length = getTextLength(testentry->entry.name);
	int x;
	if (testentry->hasani){
	 	x = (testentry->entry.col+1.5)*CHAR_WIDTH_ITEM;
	}else{
		x = testentry->entry.col*CHAR_WIDTH_ITEM;
	}
	int y = (testentry->entry.row+1)*CHAR_HEIGHT_ITEM;
	//set_gr_color(BACKCOLOR);
	//gr_color(0, 0, 0, 255);
    //gr_fill( x, y-CHAR_HEIGHT_ITEM, x+length*CHAR_WIDTH_ITEM/2, y);
    do_fill( x, y-CHAR_HEIGHT_ITEM, x+length*CHAR_WIDTH_ITEM/2, y,BACKCOLOR);
    //LOGD("MYTEST x=%d,y=%d,length=%d,CHAR_WIDTH_ITEM=%d,CHAR_HEIGHT_ITEM=%d",x,y,length,CHAR_WIDTH_ITEM,CHAR_HEIGHT_ITEM);
	//set_gr_color(testentry->entry.color);
	//gr_text(gr_font_small, x, y, testentry->entry.name);
	do_grtext(gr_font_small, x, y, testentry->entry.name,testentry->entry.color);
	if(testentry->hasani){
		runAnima(testentry);
	}
	//gr_flip();
#ifdef JLINK_ITEM_DEBUG
	do_grflip();
#endif
	
}

void drawItemValueBehind(TestEntry *testentry){

	int length = 0;
	int x=0,y=0;
	
	length = getTextLength(testentry->entry.name);
	if (testentry->hasani){
 		x = (testentry->entry.col+2.5)*CHAR_WIDTH_ITEM+length*CHAR_WIDTH_ITEM/2;
	}else{
		x = (testentry->entry.col+1)*CHAR_WIDTH_ITEM+length*CHAR_WIDTH_ITEM/2;
	}
	y = (testentry->entry.row+1)*CHAR_HEIGHT_ITEM;

	length = getTextLength(testentry->value.name);
	
	pthread_mutex_lock(&drawMutex);
	//set_gr_color(GREENCOLOR);
    //gr_fill( x, y-CHAR_HEIGHT_ITEM, x+length*CHAR_WIDTH_ITEM/2, y);//当前字符少于原来字符就无法清除
    set_gr_color(BACKCOLOR);

    //gr_fill( x, y-CHAR_HEIGHT_ITEM+1, testarea_width, y);
    gr_fill( x, y-CHAR_HEIGHT_ITEM+1, testarea_width, y);
    if (strlen(testentry->value.name) > 0 ){
    	set_gr_color(testentry->value.color);
		testentry->lastXpos = gr_text(gr_font_small, x, y-2, testentry->value.name);
    }else{
    	testentry->lastXpos = 0;
    }
	
#ifdef JLINK_ITEM_DEBUG
	gr_flip();
#endif
	pthread_mutex_unlock(&drawMutex);
}


void drawItemValueBehindLine(TestEntry *testentry){

	int length = 0;
	int x=0,y=0;
	
	length = getTextLength(testentry->entry.name);
	if (testentry->hasani){
 		x = (testentry->entry.col+2.5)*CHAR_WIDTH_ITEM+length*CHAR_WIDTH_ITEM/2;
	}else{
		x = (testentry->entry.col+1)*CHAR_WIDTH_ITEM+length*CHAR_WIDTH_ITEM/2;
	}
	y = (testentry->entry.row+1)*CHAR_HEIGHT_ITEM;

	length = getTextLength(testentry->value.name);
	
	pthread_mutex_lock(&drawMutex);
    set_gr_color(BACKCOLOR);

    gr_fill( x, y-CHAR_HEIGHT_ITEM+1, jlcd_width, y);
    if (strlen(testentry->value.name) > 0 ){
    	set_gr_color(testentry->value.color);
		testentry->lastXpos = gr_text(gr_font_small, x, y-2, testentry->value.name);
    }else{
    	testentry->lastXpos = 0;
    }
	
#ifdef JLINK_ITEM_DEBUG
	gr_flip();
#endif
	pthread_mutex_unlock(&drawMutex);
}


void drawItemValueAuto(TestEntry *testentry){
	int length = 0;
	int x=0,y=0;

	x = (testentry->entry.col)*CHAR_WIDTH_ITEM;
	y = (testentry->entry.row+2)*CHAR_HEIGHT_ITEM;
	pthread_mutex_lock(&drawMutex);
	set_gr_color(BACKCOLOR);
	if(testentry->valuelinenum!=0){
		gr_fill( x, y-CHAR_HEIGHT_ITEM, testarea_width+CHAR_WIDTH_ITEM, y+(testentry->valuelinenum-1)*CHAR_HEIGHT_ITEM);
	}
    
    if (strlen(testentry->value.name) > 0 ){
    	set_gr_color(testentry->value.color);
		testentry->valuelinenum = jlink_gr_text(gr_font_small, x, y-2, testentry->value.name,testarea_width);
    }
#ifdef JLINK_ITEM_DEBUG
	gr_flip();
#endif
	pthread_mutex_unlock(&drawMutex);
}


//static pthread_mutex_t imgMutex = PTHREAD_MUTEX_INITIALIZER;
void draw_image(int x,int y,GRSurface* frame) {
		//pthread_mutex_lock(&imgMutex);
		pthread_mutex_lock(&drawMutex);
        int frame_width = gr_get_width(frame);
        int frame_height = gr_get_height(frame);
        //int frame_x = (gr_fb_width() - frame_width) / 2;
        //int frame_y = (gr_fb_height() - frame_height) / 2;
        pthread_mutex_lock(&drawMutex);
        gr_blit(frame, 0, 0, frame_width, frame_height, x, y);
        //LOGD(TAG":x=%d,y=%d,frame_width=%d,frame_height=%d,frame_x=%d,frame_y=%d",x,y,frame_width,frame_height,frame_x,frame_y);
#ifdef JLINK_ITEM_DEBUG
        gr_flip();
#endif
        pthread_mutex_unlock(&drawMutex);
}


static pthread_mutex_t barMutex = PTHREAD_MUTEX_INITIALIZER;
void draw_progressbar(ProgressBar bar) {

        int frame_width = gr_get_width(bar.pro_empty_surface);
        int frame_height = gr_get_height(bar.pro_empty_surface);
        int fill_width = frame_width*bar.percent;
		pthread_mutex_lock(&drawMutex);
        gr_blit(bar.pro_fill_surface, 0, 0, fill_width, frame_height, bar.x, bar.y);
        gr_blit(bar.pro_empty_surface, 0, 0, frame_width-fill_width, frame_height, bar.x+fill_width, bar.y);
#ifdef JLINK_ITEM_DEBUG
		gr_flip();
#endif
		pthread_mutex_unlock(&drawMutex);
}

void updateProgressBar(ProgressBar bar,float percent){
	bar.percent = percent;
	draw_progressbar(bar);
}


void draw_button(Button* button){
	pthread_mutex_lock(&drawMutex);
	int color = 0;
	
	if (button->state==BTN_NORMAL)
	{
		color = button->back_color;
	}
	else if(button->state==BTN_PRESSD){
		color = button->press_color;
	}else if (button->state==BTN_DISABLE)
	{
		color = button->disenable_color;
	}else if(button->state==BTN_HIDDEN){
		color = BACKCOLOR;
	}
	//LOGD("MYTEST button name=%s,x=%d,y=%d,width=%d,height=%d",button->text,button->x,button->y,button->width,button->height);
    set_gr_color(color);
    gr_fill( button->x, button->y, button->x+button->width, button->y+button->height);
    if(button->state != BTN_HIDDEN){
    	int textlen = getTextLength(button->text)*CHAR_WIDTH_ITEM/2;
	    int tx = button->x,ty=0;

	    if (textlen < button->width)
	    {
	    	tx = button->x+(button->width-textlen)/2;
	    }
	    if ( CHAR_HEIGHT_ITEM < button->height)
	    {
	    	ty = button->y+(button->height-CHAR_HEIGHT_ITEM)/2+CHAR_HEIGHT_ITEM-1;
	    }
	    //LOGD("MYTEST text =%s,tx=%d,ty=%d",button->text,tx,ty);
	    set_gr_color(button->text_color);
	    gr_text(gr_font_small, tx, ty, button->text);
    }
    
    //
#ifdef    JLINK_ITEM_DEBUG
    gr_flip();
#endif
    pthread_mutex_unlock(&drawMutex);
}

void initTestButton(Button* button,JCallBack callback){
	button->disenable_color = 0x555555FF;
    button->back_color = 0x348646FF;
    button->press_color = 0xff0000ff;
    button->text_color = 0x989234ff;
    button->width = 100;
    button->height = CHAR_HEIGHT_ITEM+2;
    button->state = BTN_HIDDEN;//先隐藏防止tp触摸不正确时绘制
   	button->isautohidden = 1;
   	strcpy(button->text,uistr_info_retest);
    button->onClickListener = callback;
}


//需要注意在tp触摸不正确的时候会再0,0坐标绘制出按钮,故需调整好tp
void DrawButtonBehindEntry(Button* button,TestEntry *testentry){
	button->state = BTN_NORMAL;
	int x = testentry->lastXpos;
	if (x==0)
	{
		button->x = (testentry->entry.col+2)*CHAR_WIDTH_ITEM+getTextLength(testentry->entry.name)*CHAR_WIDTH_ITEM/2;
	}else{
		button->x = x+CHAR_WIDTH_ITEM*2;
	}
	button->y = (testentry->entry.row)*CHAR_HEIGHT_ITEM+1;
	//LOGD("MYTEST button button->x=%d,button->y=%d",button->x,button->y);
	draw_button(button);
}



int input_thread = 1;
int btncallnum = 0;
static ButtonEntry* buttonlist = NULL;
static pthread_mutex_t btnMutex = PTHREAD_MUTEX_INITIALIZER;//多个线程同时添加会出问题
void addButtionCallback(ButtonEntry* entry){
	pthread_mutex_lock(&btnMutex);
	if (buttonlist==NULL)
	{
		buttonlist=entry;
		btncallnum++;
	}else{
		ButtonEntry *btnentry = buttonlist;
		while(btnentry) {
			if (btnentry->next==NULL)
			{	
				break;
			}
	    	btnentry = btnentry->next;
		}
		btnentry->next = entry;
		btncallnum++;
	}
	pthread_mutex_unlock(&btnMutex);

}

void initButtonCallbcak(){
	buttonlist = NULL;
}


void rmButtonCallbak(ButtonEntry* entry){
	if(buttonlist==NULL) return;

	if (entry == buttonlist)
	{
		buttonlist = buttonlist->next;
		btncallnum--;
	}
	else{
		ButtonEntry *btnentry = buttonlist;
		while(btnentry) {
		    if (btnentry->next==entry)
		    {
		    	break; 
		    }
		    btnentry = btnentry->next;
		}
		btnentry->next = entry->next;
		btncallnum--;
	}
	
}

void rmAllCallbak(){
	
	if (buttonlist!=NULL)
	{
		btncallnum--;
		ButtonEntry *btnentry = buttonlist;
		ButtonEntry *tembtnentry;
		while(btnentry->next!=NULL) {
			tembtnentry=btnentry->next;
		    btnentry->next=NULL;
		    btnentry = tembtnentry;
		    btncallnum--;
		}
	}
}


int temx=0,temy=0;
int hasButtonEvent(Button *btn)
{
	int x,y;
	if (btn->state == BTN_DISABLE || btn->state==BTN_HIDDEN)
	{
		return 0;
	}
	if (temx == -1 || temx == -1)
	{
		return 0;
	}

	if (PROJECT_TP == 0)
	{
		x = jlcd_width - temy;
		y = temx;
	}else if (PROJECT_TP == 1)
	{
		x = temx;
		y = temy; 
	}else if(PROJECT_TP == 2){
		x = temy;
		y = jlcd_height - temx;
	}else if(PROJECT_TP == 3){
		x = jlcd_width - temx;
		y = jlcd_height - temy;
	}else if(PROJECT_TP == 4){
		x = temx*jlcd_width/jlcd_height;
		y = temy*jlcd_height/jlcd_width;
	}else if(PROJECT_TP == 5){
		x = temy*jlcd_width/jlcd_height;
		y = (jlcd_width - temx)*jlcd_height/jlcd_width;
	}else if(PROJECT_TP == 6){
		x = (jlcd_height - temx)*jlcd_width/jlcd_height;
		y = (jlcd_width - temy)*jlcd_height/jlcd_width;
	}else if(PROJECT_TP == 7){
		x = (jlcd_height - temy)*jlcd_width/jlcd_height;
		y = temx*jlcd_height/jlcd_width;
	}

	//LOGD("MYTEST temx=%d,temy=%d,x=%d,y=%d,width=%d,height=%d,rotate_lcm=%s",temx,temy,x,y,jlcd_width,jlcd_height,rotate_lcm);
	if (x>=btn->x && x<=(btn->x+btn->width) && y>=btn->y && y<=(btn->y+btn->height))
	{
		return 1;
	}

	return 0;
}

static enum ButtonDrawState needredrawbtn = BTN_NO_DRAW;
void handevent(struct input_event *event){
	
	
	
	//LOGD("MYTEST event->type=%d,event>code=%d,event->value=%d",event->type,event->code,event->value);
	if(event->type == EV_ABS){
		if (event->code == ABS_MT_TRACKING_ID)
		{
			if(event->value != 1) return;//只有一个触摸点才响应点击事件
		}
		switch(event->code){
			case ABS_MT_POSITION_X:
				temx = event->value;
				break;
			case ABS_MT_POSITION_Y:
				temy = event->value;
				break;
			default:
				break;
		}
	}
	
	//LOGD("MYTEST1: x=%d,y=%d",temx,temy);
	
	if (event->type == EV_KEY){
		//LOGD("MYTEST HERE0 event->type=%d,event->code=%d,event->value=%d",event->type,event->code,event->value);
		if(event->code != BTN_TOUCH){
			return;
		}
		if (event->value == 1)
		{
			needredrawbtn = BTN_PRESSD_DRAW;
			return;
		}else if(event->value == 0){
			needredrawbtn = BTN_NORMAL_DRAW;
		}
		
	}

	//LOGD("MYTEST HERE1 needredrawbtn=%d,BTN_NO_DRAW=%d,BTN_NORMAL_DRAW=%d,BTN_PRESSD_DRAW=%dBTN_DISABLE_DRAW=%d",
	//	needredrawbtn,BTN_NO_DRAW,BTN_NORMAL_DRAW,BTN_PRESSD_DRAW,BTN_DISABLE_DRAW);
	if(needredrawbtn != BTN_NO_DRAW){
		ButtonEntry *btnentry = buttonlist;
		while(btnentry){
			if (needredrawbtn==BTN_NORMAL_DRAW){
				if(btnentry->btn->state==BTN_PRESSD){
					btnentry->btn->state = BTN_NORMAL;
					draw_button(btnentry->btn);
					needredrawbtn = BTN_NO_DRAW;
					if(hasButtonEvent(btnentry->btn)){
						//LOGD("MYTEST button come in");
						if (btnentry->btn->isautohidden)
						{
							setButtonHidden(btnentry->btn);
						}
						
						JCallBack onClickListenerThread = btnentry->btn->onClickListener;
						if (onClickListenerThread!=NULL)
						{
							pthread_create(&(btnentry->btn->pthread_handle), NULL, onClickListenerThread, btnentry->btn->para);
						}
					}
					temx = -1,temy = -1;
					return;
				}
			}else if(needredrawbtn==BTN_PRESSD_DRAW){
				if(hasButtonEvent(btnentry->btn)){
					btnentry->btn->state = BTN_PRESSD;
					draw_button(btnentry->btn);
					needredrawbtn = BTN_NO_DRAW;
					return;	
				}
			}
			
			btnentry=btnentry->next;
		}


	}
	
			
}

void setButtonHidden(Button *btn){
	btn->state = BTN_HIDDEN;
	draw_button(btn);
}

void setButtonNormal(Button *btn){
	btn->state = BTN_NORMAL;
	draw_button(btn);
}

struct pollfd pfd;
void InitInputPfd(){
	DIR *dir;
	struct dirent *de;
	char name[100];
	dir = opendir("/dev/input");
	int fd;
	if (dir != NULL)
	{
		while(de = readdir(dir)){
			if(strncmp(de->d_name,"event",5)) continue;
			fd = openat(dirfd(dir), de->d_name, O_RDONLY);
            if(fd < 0) continue;

            ioctl(fd, EVIOCGNAME(sizeof(name) - 1), name);
            if (strlen(name) ==7 && !strncmp(name, "mtk-tpd", 7)) {
            	LOGD("MYTEST,find mtk-tpd fd=%d",fd);
            	pfd.fd = fd;
            	pfd.events = POLLIN;
            	break;
            }else{
            	close(fd);
            }
		}
		closedir(dir);
	}

}

extern void jlink_detect_point(int x,int y);
static int isTptest = 0;
void setJlinkTptest(int istest){
	isTptest = istest;
}

void startHandleInputEvent(){
	struct input_event ev;
	int x=0,y=0,p=0,px=0,py=0,pp=0,d=0,count=0;
    int x2=0,y2=0,p2=0,pc=0, point_count=0;
    int status = 0,i=0,distance=0, p_distance=0;
    bool enter = true, release = true;
	int ret;
	do{
		ret = poll(&pfd,1,0);
		if (ret > 0 )
		{
			LOGD("ret > 0");
			if(pfd.revents & POLLIN) {
				ret = read(pfd.fd, &ev, sizeof(ev));
                if(ret == sizeof(ev)) {
                	handevent(&ev);

              		if(ev.type==EV_ABS && ev.code==ABS_X) {
		        		if (PROJECT_TP==0)
						{
							y = temx;
						}else if (PROJECT_TP==1)
						{
							x = temx;
						}else if(PROJECT_TP==2){
							y = jlcd_height - temx;
						}else if(PROJECT_TP==3){
							x = jlcd_width - temx;
						}else if(PROJECT_TP==4){
							x = temx*jlcd_width/jlcd_height;
						}else if(PROJECT_TP==5){
							y = (jlcd_width - temx)*jlcd_height/jlcd_width;
						}else if (PROJECT_TP==6){
							x = (jlcd_height - temx)*jlcd_width/jlcd_height;
						}else if(PROJECT_TP == 7){
							y = temx*jlcd_height/jlcd_width;
						}
			        }
			        else if(ev.type==EV_ABS && ev.code==ABS_MT_POSITION_X) {
			            if (PROJECT_TP==0)
						{
							y = temx;
						}else if (PROJECT_TP==1){
							x = temx;
						}else if(PROJECT_TP==2){
							y = jlcd_height - temx;
						}else if(PROJECT_TP==3){
							x = jlcd_width - temx;
						}else if(PROJECT_TP==4){
							x = temx*jlcd_width/jlcd_height;
						}else if(PROJECT_TP==5){
							y = (jlcd_width - temx)*jlcd_height/jlcd_width;
						}else if (PROJECT_TP==6){
							x = (jlcd_height - temx)*jlcd_width/jlcd_height;
						}else if(PROJECT_TP == 7){
							y = temx*jlcd_height/jlcd_width;
						}
			        }
			        else if(ev.type==EV_ABS && ev.code==ABS_Y) {
			          	if (PROJECT_TP==0)
						{
							x = jlcd_width - temy;
						}else if (PROJECT_TP==1)
						{
							y = temy; 
						}else if(PROJECT_TP==2){
							x = temy;
						}else if(PROJECT_TP==3){
							y = jlcd_height - temy;
						}else if(PROJECT_TP==4){
							y = temy*jlcd_height/jlcd_width;
						}else if(PROJECT_TP==5){
							x = temy*jlcd_width/jlcd_height;
						}else if (PROJECT_TP==6){
							y = (jlcd_width - temy)*jlcd_height/jlcd_width;
						}else if(PROJECT_TP == 7){
							x = (jlcd_height - temy)*jlcd_width/jlcd_height;
						}
			        }
			        else if(ev.type==EV_ABS && ev.code==ABS_MT_POSITION_Y) {
			          	if (PROJECT_TP==0)
						{
							x = jlcd_width - temy;
						}else if (PROJECT_TP==1)
						{
							y = temy; 
						}else if(PROJECT_TP==2){
							x = temy;
						}else if (PROJECT_TP==3){
							y = jlcd_height - temy;
						}else if(PROJECT_TP==4){
							y = temy*jlcd_height/jlcd_width;
						}else if(PROJECT_TP==5){
							x = temy*jlcd_width/jlcd_height;
						}else if (PROJECT_TP==6){
							y = (jlcd_width - temy)*jlcd_height/jlcd_width;
						}else if(PROJECT_TP == 7){
							x = (jlcd_height - temy)*jlcd_width/jlcd_height;
						}
			        }
			        else if(ev.type==EV_ABS && ev.code==ABS_PRESSURE) { p=ev.value; }
			        else if(ev.type==EV_ABS && ev.code==ABS_MT_TOUCH_MAJOR) { p=ev.value; }
			        else if(ev.type==EV_KEY && ev.code==BTN_TOUCH) { d=ev.value; }
			        else if(ev.type==EV_SYN && ev.code==SYN_MT_REPORT) {
			            //LOGD("[touch] x:%d y:%d p:%d\n", x,y,p);
			            if(pc==0) { x2 = x; y2 =y; p2 = p; }
			            pc++;
			            if(p==0) distance = 0;
			        } else if(ev.type==EV_SYN) {
			            point_count++; 
			            if(enter==true || release==true) { px=x;py=y;enter=false; release=false; }    
			            //ui_color(255,255,255,255);
			            //gr_line(px,py,x,y,2);
			            if (isTptest){
			            	ui_color(255,255,255,255);
			            	gr_line(px,py,x,y,2);
			            	jlink_detect_point(x,y);//触摸测试响应更快

			            }else{
			            	do_grline(px,py,x,y,2,WRITECOLOR);//多项测试不同步会花屏
			            }
			            //LOGD(TAG "freemode: x = %d, y = %d ; px = %d, py = %d\n", x, y, px, py);
#ifdef JLINK_ITEM_DEBUG
			            //不刷新,让重力感应刷新
			            if (!(point_count%TOUCH_UPDATE_FR_DIV))
			                do_grflip();
			            point_count=point_count%TOUCH_UPDATE_FR_DIV;
#endif
			            px=x,py=y;pc=0;
			            if(d==0) release=true;
			                
			        }
                }
			}
		}
		

	}while(input_thread);
}


//extern int ev_get(struct input_event *ev, unsigned dont_wait);
void* startListener(void*param){
	struct input_event ev;
	InitInputPfd();
	input_thread = 1;
	startHandleInputEvent();
	if (pfd.fd>0)
	{
		close(pfd.fd);
		pfd.fd=-1;
	}
	return NULL;
}

void exitListener(){
	input_thread = 0;
	rmAllCallbak();
}



void drawColorBand(){
	pthread_mutex_lock(&drawMutex);
	set_gr_color(0xFF0000FF);
    gr_fill( jlcd_width*3/4, jlcd_height*3/4, jlcd_width*3/4+jlcd_width/12, jlcd_height);
    set_gr_color(0x00FF00FF);
    gr_fill( jlcd_width*3/4+jlcd_width/12, jlcd_height*3/4, jlcd_width*3/4+jlcd_width/6, jlcd_height);
    set_gr_color(0x0000FFFF);
    gr_fill( jlcd_width*3/4+jlcd_width/6, jlcd_height*3/4, jlcd_width*3/4+jlcd_width/4, jlcd_height);
#ifdef    JLINK_ITEM_DEBUG
    gr_flip();
#endif
    pthread_mutex_unlock(&drawMutex);
}

/*
**需要在读取转屏角度之后初始化read_rotation();
**所有函数须在初始化后使用
*/
void jlink_ui_init(){
	//ui_init();//合并时注释
	readJlinkTp();
	jlcd_width = ui_fb_width();
	jlcd_height = ui_fb_height();
	int colorbandw = jlcd_width*1/4;
	int maxCamerWidth = 0;
	int minCamerWidth = 0;
	if (CAMERA_PRE_WIDTH > CAMERA_PRE_HEIGHT)
	{
		maxCamerWidth = CAMERA_PRE_WIDTH;
		minCamerWidth = CAMERA_PRE_HEIGHT;
	}else{
		maxCamerWidth = CAMERA_PRE_HEIGHT;
		minCamerWidth = CAMERA_PRE_WIDTH;
	}
	maxCamerWidth = (maxCamerWidth > colorbandw) ? maxCamerWidth:colorbandw;
	minCamerWidth = (minCamerWidth > colorbandw) ? minCamerWidth:colorbandw;
	testarea_width = (jlcd_width>jlcd_height)? (jlcd_width - maxCamerWidth):(jlcd_width - minCamerWidth);
	testarea_width -= 3*CHAR_WIDTH_ITEM;//空3个字符宽度
}

void* do_clip_loop(void*pram){
	input_thread = 1;
    while(input_thread){
    	pthread_mutex_lock(&drawMutex);
    	gr_flip();
	   	pthread_mutex_unlock(&drawMutex);
    	usleep(10000);
    }
    return NULL;
}
//可以从factory.ini中读取tp配置
//tp: jlink.factory.tp=1
static void readJlinkTp()
{
    char  buf[100]={0};
	FILE *fp;
	char *tem;
	PROJECT_TP = -1;
	fp = fopen("/storage/sdcard1/factory.ini", "r");
	if (fp==NULL){
		fp = fopen("/system/vendor/etc/factory.ini", "r");
	}    
	if (fp != NULL) {
		while (fgets(buf, 100, fp)) {
			if (strstr(buf,"jlink.factory.tp=")!=NULL){
				tem = &buf;
				int length = strlen(buf);
				while(length--){
					if (*tem == ' '){
						tem++;
						continue;
					}else{
						break;
					}
				}
				
				if (strstr(tem,"jlink.factory.tp=0")==tem){
					PROJECT_TP = 0;
				}else if (strstr(tem,"jlink.factory.tp=1")==tem){
					PROJECT_TP = 1;
				}else if (strstr(tem,"jlink.factory.tp=2")==tem){
					PROJECT_TP = 2;
				}else if (strstr(tem,"jlink.factory.tp=3")==tem){
					PROJECT_TP = 3;
				}else if (strstr(tem,"jlink.factory.tp=4")==tem){
					PROJECT_TP = 4;
				}else if (strstr(tem,"jlink.factory.tp=5")==tem){
					PROJECT_TP = 5;
				}else if (strstr(tem,"jlink.factory.tp=6")==tem){
					PROJECT_TP = 6;
				}else if (strstr(tem,"jlink.factory.tp=7")==tem){
					PROJECT_TP = 7;
				}
				break;
			}
		}
		fclose(fp);
	}

	if (PROJECT_TP == -1){
		PROJECT_TP = PROJECT_TP_CON;
	}
	LOGD("MYTEST PROJECT_TP=%d",PROJECT_TP);
}
