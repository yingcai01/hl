#include "me_connection.h"
#include "ftm.h"
#include "utils.h"
#include "at_command.h"
extern "C"{
#include "jlinkui.h"
}

#ifdef Factory_C2K_SUPPORT
#ifndef MTK_ECCCI_C2K
#include <c2kutils.h>
#endif
#endif



#define MAX_MODEM_INDEX 4
pthread_mutex_t modemMutex = PTHREAD_MUTEX_INITIALIZER;
static Connection modem[5];

extern struct sigtest {
    char info[1024];
    bool exit_thd;
    int fd_atmd;
    int fd_atmd2;
    int fd_atmd_dt;
    int fd_atmd5;
    int test_type;
    text_t title;
    text_t text;
    pthread_t update_thd;
    struct ftm_module *mod;
    struct itemview *iv;
};

extern void init_COND();
extern void jlink_deinit_COND();
extern void exit_flight_mode_internal(Connection& conn, int md_num);
extern void query_modem_status(Connection& modem);

int sigtest_entry(TestEntry* signalentry)
{
    static int signalFlag = 0 ;
    bool exit = (bool)FALSE;
    int chosen = 0 ;
    struct sigtest *st = (struct sigtest *)malloc(sizeof(struct sigtest)) ;
    memset(st,0,sizeof(struct sigtest));
    struct itemview *iv = NULL;
    int pret = 0 ;
    char ccci_path[MAX_MODEM_INDEX][32] = {0};
    char temp_ccci_path[MAX_MODEM_INDEX][32] = {0};
    int test_result_temp = TRUE;
    int modem_number = 0;
    int ccci_status = 0;
    int i = 0;
    int j = 0;
    int modem_count = 0;
    int temp_result[MODEM_MAX_NUM] = {0} ;
    char *asciDevice = NULL ;
    //item_t *sigtest_items= NULL;

    LOGD(TAG "%s\n", __FUNCTION__);
    init_COND();
    modem_number = get_md_count();
    LOGD(TAG "modem_number is %d\n",modem_number);
    /*
    if(modem_number == 1)
    {
        sigtest_items = sigtest_items_single_modem;
    }
    if((modem_number == 2)||(isC2kSupport() == 1))
    {
        sigtest_items = sigtest_items_multi_modem;
    }*/
    for(i = 0; i < MAX_MODEM_INDEX; i++)
    {
        if(1 == get_ccci_path(i,temp_ccci_path[i]))
        {
            strcpy(ccci_path[j],temp_ccci_path[i]);
            j++ ;
        }
    }
    LOGD(TAG "The second time signal test\n");
    for(i=0;i<modem_number; i++)
    {
        if(0 == modem[i].Conn_Init(ccci_path[i],i+1,g_SIGNAL_Callback[i]))
        {
            LOGD(TAG "modem %d open fail",(i+1));
        }
        else
        {
            LOGD(TAG "modem %d open OK",(i+1));
        }
    }

    #ifndef EVDO_FTM_DT_VIA_SUPPORT
    #ifdef Factory_C2K_SUPPORT
    g_Flag_CREG = 0 ;
    g_Flag_VPUP = 0 ;
    #ifdef MTK_ECCCI_C2K
        asciDevice = (char*)malloc(sizeof(char)*32);
        strcpy(asciDevice,ccci_path[modem_number]);
        LOGD(TAG "ECCI support C2K modem path is  = %s\n",asciDevice);
    #else
        asciDevice = viatelAdjustDevicePathFromProperty(VIATEL_CHANNEL_AT);
        LOGD(TAG "Not ECCI support C2K modem path is  = %s\n",asciDevice);
    #endif

    if(0 == modem[modem_number].Conn_Init(asciDevice,modem_number+1,g_SIGNAL_Callback[modem_number]))
    {
        LOGD("modem c2k open failed");
    }
    else{
        LOGD("modem c2k open successfully");
    }
    #ifdef MTK_ECCCI_C2K
    free(asciDevice);
    #endif
    #endif
    #endif

    //init_text(&st->title, param->name, COLOR_YELLOW);
    //init_text(&st->text, &st->info[0], COLOR_YELLOW);
    //memset(&st->info[0], 0, sizeof(st->info));
    signalentry->state = TEST_FAIL;
    sprintf(signalentry->value.name, "%s\n", uistr_info_emergency_call_testing);
    drawItemValueBehind(signalentry);
    //st->exit_thd = FALSE ;


    modem_count = 0 ;
    i = 0 ;
    /*
    iv = st->iv;
    iv->set_title(iv, &st->title);
    iv->set_items(iv, sigtest_item_auto, 0);
    iv->set_text(iv, &st->text);
    iv->start_menu(iv,0);
    iv->redraw(iv);
*/
    if(isMDENSupport(1)>0){
        g_Flag_CREG = 0 ;
        g_Flag_EIND = 0 ;
        g_Flag_ESPEECH_ECPI = 0 ;
        pret = 0 ;
        modem_count++;
        exit_flight_mode_internal(modem[modem_count-1], modem_count);
        pret = dial112(modem[modem_count-1]);
        if(1 == pret) {
            LOGD(TAG "Dial 112 Success in modem 1\n");
            sprintf(signalentry->value.name, "%s\n", uistr_info_emergency_call_success_in_modem1);
            temp_result[i] = TRUE ;
            signalentry->value.color=GREENCOLOR;
        }
        else
        {
            LOGD(TAG "Dial 112 Fail in modem 1\n");
            sprintf(signalentry->value.name, "%s\n", uistr_info_emergency_call_fail_in_modem1);
            temp_result[i] = FALSE ;
            signalentry->value.color=REDCOLOR;
        }
        i++ ;
        drawItemValueBehind(signalentry);
        if(ER_OK!= modem[modem_count-1].SetNormalRFMode(4))
            goto disconnect;//未关闭时在测试其他项时会出现无法打开modem设备,出现busy.
            //return -1 ;
        //iv->redraw(iv);
        
    }

    if(isMDENSupport(2)>0){
        g_Flag_CREG = 0 ;
        g_Flag_EIND = 0 ;
        g_Flag_ESPEECH_ECPI = 0 ;
        pret = 0 ;
        modem_count++;
        exit_flight_mode_internal(modem[modem_count-1], modem_count);
        pret = dial112(modem[modem_count-1]);
        if(1 == pret)
        {
            LOGD(TAG "Dial 112 Success in modem 2\n");
            sprintf(signalentry->value.name, "%s\n", uistr_info_emergency_call_success_in_modem2);
            temp_result[i] = TRUE ;
            signalentry->value.color=GREENCOLOR;
        }
        else
        {
             LOGD(TAG "Dial 112 Fail in modem 2\n");
             sprintf(signalentry->value.name, "%s\n", uistr_info_emergency_call_fail_in_modem2);
             temp_result[i] = FALSE ;
             signalentry->value.color=REDCOLOR;
        }
        drawItemValueBehind(signalentry);
        if(ER_OK!= modem[modem_count-1].SetNormalRFMode(4)){
            goto disconnect;
        }
            
            //return -1 ;
        i++ ;
        //iv->redraw(iv);
        
    }

    if(isMDENSupport(5)>0){
        g_Flag_CREG = 0 ;
        g_Flag_EIND = 0 ;
        g_Flag_ESPEECH_ECPI = 0 ;
        pret = 0 ;
        modem_count++ ;
        exit_flight_mode_internal(modem[modem_count-1], modem_count);
        pret = dial112(modem[modem_count-1]);
        if(1 == pret)
        {
            LOGD(TAG "Dial 112 Success in  modem 5 \n");
            sprintf(signalentry->value.name, "%s\n", uistr_info_emergency_call_success_in_modem2);
            temp_result[i] = TRUE ;
            signalentry->value.color=GREENCOLOR;
        }
        else
        {
            LOGD(TAG "Dial 112 Fail in modem 5 \n");
            sprintf(signalentry->value.name, "%s\n", uistr_info_emergency_call_fail_in_modem2);
            temp_result[i] = FALSE ;
            signalentry->value.color=REDCOLOR;
        }
        i++ ;
        drawItemValueBehind(signalentry);
        if(ER_OK!= modem[modem_count-1].SetNormalRFMode(4))
            goto disconnect;
            //return -1 ;
        //iv->redraw(iv);
        
    }

    if(1==isC2kSupport())
    {
        g_Flag_CONN = 0 ;
        g_Flag_CREG = 0 ;
        g_Flag_VPUP  = 0;
        g_Flag_EUSIM  = 0;
        g_Flag_UIMST  = 0;
        pret = 0 ;
        for(i=0 ;i<modem_number; i++)
        {
            query_modem_status(modem[i]);
            if(isRLTE_VLTESupport()!=0){
                if(ER_OK!= modem[i].SetMTKRFMode(0))
                    return -1 ;
                wait_URC(ID_EUSIM);
                LOGD(TAG "[AT]For iRat");
                if(ER_OK!= modem[i].EMDSTATUS())
                    return -1;
            }
        }
        C2Kmodemsignaltest(modem[modem_number]);
        pret = dial112C2K(modem[modem_number]);
        if(1 == pret)
        {
            LOGD(TAG "Dial 112 Success in c2k modem \n");
            sprintf(signalentry->value.name, "%s\n", uistr_info_emergency_call_success_in_modem2);
            temp_result[i] = TRUE ;
            signalentry->value.color=GREENCOLOR;
        }
        else
        {
            LOGD(TAG "Dial 112 Fail in c2k modem \n");
            sprintf(signalentry->value.name, "%s\n", uistr_info_emergency_call_fail_in_modem2);
            temp_result[i] = FALSE ;
            signalentry->value.color=REDCOLOR;
        }
        i++ ;
        modem[modem_number].TurnOffPhone();
        //iv->redraw(iv);
        drawItemValueBehind(signalentry);
    }

    for(j=0 ;j<i ;j++ )
    {
        test_result_temp = test_result_temp&&temp_result[j] ;
    }


    if(1 == test_result_temp)
    {
        //st->mod->test_result = FTM_TEST_PASS;
        //sprintf(signalentry->value.name, "%s\n", uistr_info_emergency_call_fail_in_modem2);
    	signalentry->state = TEST_PASS;
    }
    else
    {
    	signalentry->state = TEST_FAIL;
        //st->mod->test_result = FTM_TEST_FAIL;
        //sprintf(signalentry->value.name, "%s\n", uistr_info_emergency_call_fail_in_modem2);
    }

    //iv->redraw(iv);
    //drawItemValueBehind(signalentry);
 
 disconnect:
    
    LOGD("MYTEST close port");
    LOGD(TAG "[AT]CCCI port close\n");
    for(i=0;i<modem_number;i++)
    {
        LOGD(TAG "modem %d deinit start \n",i);
        if(1 == modem[i].Conn_DeInit())
        {
        	 LOGD(TAG "Deinit the port successfully\n");
        }
        else
        {
           LOGD(TAG "Deinit the port failed \n");
        }
        LOGD(TAG "modem %d deinit end \n",i);
    }
    #ifdef Factory_C2K_SUPPORT
    if(isMDENSupport(3)>0){
        LOGD(TAG "[AT]modem_number = %d,SDIO port close\n",modem_number);
        modem[modem_number].Conn_DeInit();
        LOGD(TAG "[AT]SDIO port close done \n");
    }
    #endif
    if(st!=NULL){
    	free(st);
    }
    deinit_COND();
    setProinfoItemResult(signalentry->id,signalentry->state);
    return 0;
}


static int signalthreadrun = 1;
extern TestEntry signalEntry;
extern Button sigbutton;
ButtonEntry sigbtnentry;
extern int ismodemboot;
void * signal_start(void*para){
    if (ismodemboot==0)
    {
        strcpy(signalEntry.value.name,"Waiting modem boot");
        drawItemValueBehind(&signalEntry);
    }
    while(ismodemboot==0){
        usleep(300000);
    }
    signalEntry.value.color = REDCOLOR;
    strcpy(signalEntry.value.name,uistr_info_waiting);
    drawItemValueBehind(&signalEntry);

    pthread_mutex_lock(&modemMutex);
    sigtest_entry(&signalEntry);
    pthread_mutex_unlock(&modemMutex);
    DrawButtonBehindEntry(&sigbutton,&signalEntry);
    return NULL;
}


void * jlink_signal_start(void*para){

    signalthreadrun = 1;
    drawTestItem(&signalEntry);
    initTestButton(&sigbutton,signal_start);
    sigbtnentry.btn = &sigbutton;
    sigbtnentry.next = NULL;
    addButtionCallback(&sigbtnentry);
    signal_start(NULL);
    return NULL;
}

void jlink_signal_stop(){
    signalthreadrun = 0;
}