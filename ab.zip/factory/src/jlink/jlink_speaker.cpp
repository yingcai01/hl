
#include "../test/ftm_audio_Common.h"
#include <media/AudioParameter.h>
#include <AudioFtmBase.h>
#include <hardware_legacy/AudioMTKHardwareInterface.h>
extern "C"{
	#include "jlinkui.h"
}

#define LEFTRIGHTMUSIC "/vendor/res/sound/leftrightmusic.wav"

using android::status_t;

static bool speakerExit = false;
static pthread_t leftright_handle;

extern Button speakerbutton;
extern android::AudioFtmBaseVirtual *gAudioFtmBase;
extern android_audio_legacy::AudioMTKHardwareInterface *gAudioHardware;
extern "C" int PCM_decode_data(WaveHdr *wavHdr,  char *in_buf, int block_size, char *out_buf, int *out_size);

static void* speakerTest(void*param){

    char *inBuffer = NULL;
    char *outBuffer = NULL;
    int read_size = 0;
    FILE* file = NULL;
    uint32_t channels;
    uint32_t sampleRate;
    status_t status;
    int format;
    uint32_t ReadBlockLen;
    uint32_t hwBufferSize;
    int out_size;
    int readdata = 0, writedata = 0;


    WavePlayData WavePlayInstance;
    memset((void *)&WavePlayInstance, 0 , sizeof(WavePlayData));
    file = fopen(LEFTRIGHTMUSIC, "rb");
    if (file!=NULL){   
        read_size = fread((void *)&WavePlayInstance.mWaveHeader,WAVE_HEADER_SIZE, 1, file);
        ALOGD("Playback file name = %s", LEFTRIGHTMUSIC);
        ALOGD("BitsPerSample = %d", WavePlayInstance.mWaveHeader.BitsPerSample);
        ALOGD("NumChannels = %d", WavePlayInstance.mWaveHeader.NumChannels);
        ALOGD("SampleRate = %d", WavePlayInstance.mWaveHeader.SampleRate);
        gAudioFtmBase->FTM_AnaLpk_on();
        sampleRate = WavePlayInstance.mWaveHeader.SampleRate;
        channels = AUDIO_CHANNEL_OUT_STEREO;

        switch (WavePlayInstance.mWaveHeader.BitsPerSample)
        {
            case 8:
                format = AUDIO_FORMAT_PCM_8_BIT;
                break;
            case 16:
                format = AUDIO_FORMAT_PCM_16_BIT;
                break;
            default:
                ALOGD("Only Support 8/16 bit! \n");
                format = 0;
                break;
        }

        android_audio_legacy::AudioMTKStreamOutInterface *streamOutput = (android_audio_legacy::AudioMTKStreamOutInterface *)gAudioHardware->openOutputStream(0, &format, &channels, &sampleRate, &status);
        hwBufferSize = streamOutput->bufferSize();
        ALOGD("MYTEST error 0\n");
        if (WavePlayInstance.mWaveHeader.NumChannels == 1)
        {
            switch (WavePlayInstance.mWaveHeader.BitsPerSample)
            {
                case 8:
                    ReadBlockLen = hwBufferSize >> 2;
                    break;
                default: /* mWaveHeader.BitsPerSample = 16 */
                    ReadBlockLen = hwBufferSize >> 1;
                    break;
            }
        }
        else
        {
            switch (WavePlayInstance.mWaveHeader.BitsPerSample)
            {
                case 8:
                    ReadBlockLen = hwBufferSize >> 1;
                    break;
                default: /* mWaveHeader.BitsPerSample = 16 */
                    ReadBlockLen = hwBufferSize;
                    break;
            }
        }
        inBuffer = new char[ReadBlockLen];
        outBuffer = new char[hwBufferSize];

        android::AudioParameter paramRouting = android::AudioParameter();
        paramRouting.addInt(android::String8(android::AudioParameter::keyRouting), AUDIO_DEVICE_OUT_SPEAKER);
        streamOutput->setParameters(paramRouting.toString());
        
        
        gAudioHardware->setMasterVolume(1.0);
        ALOGD("MYTEST error 1\n");
        while (!feof(file) && !speakerExit)
        {
            readdata = fread(inBuffer, ReadBlockLen, 1, file);
            PCM_decode_data(&WavePlayInstance.mWaveHeader, inBuffer, ReadBlockLen, outBuffer, &out_size);

            writedata = streamOutput->write(outBuffer, out_size);
            ALOGV("Audio_Wave_Playabck_routine write to hardware... read = %d writedata = %d", readdata, out_size);
        }
        ALOGD("MYTEST error 2\n");
        gAudioFtmBase->FTM_AnaLpk_off();
        streamOutput->standby();
        gAudioHardware->closeOutputStream(streamOutput);

        if (inBuffer)
        {
            delete[] inBuffer;
            inBuffer = NULL;
        }
        if (outBuffer)
        {
            delete[] outBuffer;
            outBuffer = NULL;
        }

       if (file)
        {
            fclose(file);
            file = NULL;
        }
    }
    ALOGD("MYTEST error 4\n");
    pthread_exit(NULL);
    return NULL;
}

extern pthread_mutex_t audioMutex;
static void jlink_speaker_test(){
    sprintf(speakerbutton.text,"%s",uistr_info_speakertesting);
    draw_button(&speakerbutton);
    Common_Audio_init();
    pthread_create(&leftright_handle,NULL,speakerTest,NULL);
    pthread_join(leftright_handle, NULL);
    Common_Audio_deinit();
    speakerbutton.state = BTN_NORMAL;
    sprintf(speakerbutton.text,"%s",uistr_info_speakerbtntxt);
    draw_button(&speakerbutton);
}





void * jlink_speaker_start(void*para){
    speakerExit=false;
    speakerbutton.state = BTN_DISABLE;
    sprintf(speakerbutton.text,"%s",uistr_info_waiting);
    draw_button(&speakerbutton);
    pthread_mutex_lock(&audioMutex);
    jlink_speaker_test();
    pthread_mutex_unlock(&audioMutex);
    return NULL;
}

void stopSpeaker(){
    speakerExit = true;
}
