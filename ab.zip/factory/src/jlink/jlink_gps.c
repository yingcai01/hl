#include "jlinkui.h"
#include <sys/socket.h>
#include <arpa/inet.h>
#include <strings.h>
#include <sys/types.h>
#include <sys/wait.h>


#define NUM_CH  (20)
#define PSEUDO_CH (32)
#define Knot2Kmhr (1.8532)

#define GPS_PROPERTY "/data/misc/GPS_CHIP_FTM.cfg"

#define C_INVALID_PID  (-1)   /*invalid process id*/
#define C_INVALID_SOCKET (-1) /*invalid socket id*/



#define MND_ERR(fmt, arg ...) LOGD(TAG"%s: " fmt, __FUNCTION__ ,##arg)
#define MND_MSG(fmt, arg ...) LOGD(TAG"%s: " fmt, __FUNCTION__ ,##arg)

static int timeout = 60;
static int init_flag = 0;
static int use_aosp_gps = -1;
static int mnld_terminated = 0;

#define NMEA_SIZE       10240
static int ttff = 0;
static int fixed = 0;
static int httff = 0;
static int cttff = 0;
static int ttff_check_res = 0;
unsigned char nmea_buf[NMEA_SIZE];

typedef struct SVInfo
{
    int SVid;            // PRN
    int SNR;
    int elv;             // elevation angle : 0~90
    int azimuth;         // azimuth : 0~360
    unsigned char Fix;   // 0:None , 1:FixSV
} SVInfo;

typedef struct ChInfo
{
    int SVid;            // PRN
    int SNR;             // SNR
    unsigned char Status;// Status(0:Idle, 1:Search, 2:Tracking)
} ChInfo;

typedef struct GPSInfo
{
    int year;
    int mon;
    int day;
    int hour;
    int min;
    float sec;

    float Lat; // Position, +:E,N -:W,S
    float Lon;
    float Alt;
    unsigned char FixService;  // NoFix:0, SPS:1, DGPS:2, Estimate:6
    unsigned char FixType;     // None:0, 2D:1, 3D:2
    float Speed;  // km/hr
    float Track;  // 0~360
    float PDOP;   //DOP
    float HDOP;
    float VDOP;

    int SV_cnt;
    int fixSV[NUM_CH];
}GPSInfo;

extern GPSInfo g_gpsInfo;
extern SVInfo  g_svInfo[NUM_CH];
extern ChInfo  g_chInfo[PSEUDO_CH];

static pid_t mnl_pid = C_INVALID_PID;
static int sockfd = C_INVALID_SOCKET;
static int gpsthreadrun = 1;
extern void chip_detector();

static int mnl_write_attr(const char *name, unsigned char attr) {
    int err, fd = open(name, O_RDWR);
    char buf[] = {attr + '0'};

    if (fd < 0) {
        LOGD(TAG"open %s err = %s\n", name, strerror(errno));
        return -errno;
    }
    do { err = write(fd, buf, sizeof(buf) );}
    while (err < 0 && errno == EINTR && gpsthreadrun==1);

    if (err != sizeof(buf)) {
        LOGD(TAG"write fails = %s\n", strerror(errno));
        err = -errno;
    } else {
        err = 0;    /*no error*/
    }
    if (close(fd) == -1) {
        LOGD(TAG"close fails = %s\n", strerror(errno));
        err = (err) ? (err) : (-errno);
    }
    LOGD(TAG"write '%d' to %s okay\n", attr, name);
    return err;
}

extern int setup_signal_handler(void);
static int GPS_Open()
{
    short err;
    pid_t pid;
    int portno;
    struct sockaddr_in serv_addr;
    struct hostent *server;
    int mt3326_fd;
    struct termios termOptions;
    char *argv[] = {"/vendor/bin/libmnla", "libmnlp"};
    unsigned char query[11]     = {0x04, 0x24, 0x0b, 0x00, 0x08, 0xff, 0x19, 0x00, 0xe5, 0x0d, 0x0a};
    unsigned char response[11]  = {0x04, 0x24, 0x0b, 0x00, 0x1d, 0xff, 0x01, 0xaa, 0x42, 0x0d, 0x0a};
    unsigned char buf[20] = {0};
    int nRead = 0, nWrite = 0;
    chip_detector();

    char chip_id[100] = {0};
    int fd = -1;
    if ((fd = open(GPS_PROPERTY, O_RDONLY)) < 0)
        MND_ERR("open %s error, %s\n", GPS_PROPERTY, strerror(errno));
    if (fd >= 0) {
        if (read(fd, chip_id, sizeof(chip_id)) == -1)
            MND_ERR("open %s error, %s\n", GPS_PROPERTY, strerror(errno));
        close(fd);
    }

    if ((strcmp(chip_id, "0x6620") != 0) || (strcmp(chip_id, "0x6628")!= 0)) {
        use_aosp_gps = 1;
        if (setup_signal_handler()) {
            LOGD("setup_signal_handler: %d (%s)\n", errno, strerror(errno));
            exit(1);
        }
    } else {
        LOGD("Not AOSP architecture");
        use_aosp_gps = 0;
    }

    LOGD(TAG"GPS_Open() 1\n");
    // power on GPS chip
#if defined(MTK_GPS_MT3332)
    err = mnl_write_attr("/sys/class/gpsdrv/gps/pwrctl", 4);
    if (err != 0) {
        LOGD(TAG"GPS_Open: GPS power-on error: %d\n", err);
        return (-1);
    }
#endif


    // run gps driver (libmnlp)
    if ((pid = fork()) < 0) {
        LOGD(TAG"GPS_Open: fork fails: %d (%s)\n", errno, strerror(errno));
        return (-2);
    }
    else if (pid == 0) {   /*child process*/
        int err;

        char chip_id[100] = {0};
        int fd = -1;
        if ((fd = open(GPS_PROPERTY, O_RDONLY)) < 0)
            MND_ERR("open %s error, %s\n", GPS_PROPERTY, strerror(errno));
        if (fd >= 0) {
            if (read(fd, chip_id, sizeof(chip_id)) == -1)
                MND_ERR("open %s error, %s\n", GPS_PROPERTY, strerror(errno));
            close(fd);
        }

        MND_MSG("chip_id is %s\n", chip_id);
        if (strcmp(chip_id, "0x6620") == 0) {
            MND_MSG("we get MT6620\n");
            char *mnl6620 = "/vendor/bin/libmnlp_mt6620";
            argv[0] = mnl6620;
            MND_MSG("execute: %s \n", argv[0]);
            err = execl(argv[0], "libmnlp", "1Hz=y", NULL);
        } else if (strcmp(chip_id, "0x6628") == 0) {
            MND_MSG("we get MT6628\n");
            char *mnl6628 = "/vendor/bin/libmnlp_mt6628";
            argv[0] = mnl6628;
            MND_MSG("execute: %s \n", argv[0]);
            err = execl(argv[0], "libmnlp", "1Hz=y", NULL);
        } else {
            MND_MSG("execl vendor/bin/mnld");
            err = execl("vendor/bin/mnld", "mnld", "1Hz=y", "factory", NULL);
        }
        if (err == -1) {
            MND_MSG("execl error: %s\n", strerror(errno));
            return -1;
        }
        return 0;
    } else {  /*parent process*/
        mnl_pid = pid;
        LOGD(TAG"GPS_Open: mnl_pid = %d\n", pid);
    }

    // create socket connection to gps driver
    portno = 7000;
    /* Create a socket point */
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        LOGD(TAG"GPS_Open: ERROR opening socket");
        return (-4);
    }
    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    /* bcopy((char *)server->h_addr, (char *)&serv_addr.sin_addr.s_addr, server->h_length);*/
    serv_addr.sin_addr.s_addr = htons(INADDR_ANY);
    serv_addr.sin_port = htons(portno);

    int try_time = 10;
    do {
        LOGD(TAG"GPS_Open: try connecting,try_time = %d", try_time);
        sleep(1);  // sleep 5sec for libmnlp to finish initialization
    } while (connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0 && --try_time);
    if (try_time == 0) {
         LOGD(TAG"GPS_Open: ERROR connecting");
         return (-6);
    }
    init_flag = 1;
    LOGD(TAG"GPS_Open() 2, set init_flag = 1\n");

    return 0;
}


static void GPS_Close()
{
    int err;
    int cnt = 0, max = 10;

    LOGD(TAG"GPS_Close() 1\n");

    // disconnect to gps driver
    if (sockfd != C_INVALID_SOCKET) {
        LOGD(TAG"GPS_Close() 2\n");
        close(sockfd);
        LOGD(TAG"GPS_Close() 3\n");
        sockfd = C_INVALID_SOCKET;
    }
    LOGD(TAG"GPS_Close() 4\n");

    // kill gps driver (libmnlp)
    if (mnl_pid != C_INVALID_PID) {
        LOGD(TAG"GPS_Close() 5\n");
        if (use_aosp_gps == 0) {
            kill(mnl_pid, SIGKILL);
            usleep(500000);  // 500ms
        } else if (use_aosp_gps == 1) {
            kill(mnl_pid, SIGTERM);
			/*
            while (!mnld_terminated && gpsthreadrun==1) {
                if (cnt++ < max) {

                    usleep(100000);
                    continue;
                } else {
                    kill(mnl_pid, SIGKILL);
                    usleep(100000);
                }
            }
            LOGD("waiting counts: %d\n", cnt);
			*/
            mnl_pid = wait(&err);

            if (mnl_pid == -1)
                LOGD("wait error: %s\n",strerror(errno));
            LOGD("mnld process : %d is killed\n", mnl_pid);
            mnld_terminated = 1;
        }
    }
    use_aosp_gps = -1;

    LOGD(TAG"GPS_Close() 6\n");

    // power off GPS chip
#if defined(MTK_GPS_MT3332)
    err = mnl_write_attr("/sys/class/gpsdrv/gps/pwrctl", 0);
    if (err != 0) {
        LOGD(TAG"GPS power-off error: %d\n", err);
    }
    LOGD(TAG"GPS_Close() 7\n");
#endif
    unlink(GPS_PROPERTY);
    return;
}



extern void NMEA_Parse(char *TempBuf);
static void gps_update_info(char* info,int bufsize) {
    char *ptr;
    short i = 0;
    short read_leng = 0;
    short total_leng = 0;

    memset(info, '\n', bufsize);
    info[bufsize-1] = 0x0;

    if (sockfd != C_INVALID_SOCKET) {
        memset(nmea_buf, 0, NMEA_SIZE);

        LOGD(TAG"read from sockfd 1\n");
        read_leng = read(sockfd, &nmea_buf[total_leng], (NMEA_SIZE - total_leng));
        total_leng += read_leng;
        LOGD(TAG"read_leng=%d, total_leng=%d\n", read_leng, total_leng);

        if (read_leng <= 0) {
            LOGD(TAG"ERROR reading from socket\n");
            sprintf(info, "%s\n", uistr_info_gps_error);
            gpsthreadrun= 1;
        }
        else if (total_leng > 0) {
            NMEA_Parse((char*)&nmea_buf[0]);

            ptr  = info;
            if (((g_gpsInfo.FixType != 0) && (ttff != 0)/*avoid prev second's NMEA*/)
             || (fixed == 1)) {  // 2D or 3D fixed
                ptr += sprintf(ptr, "%s: %d\n", uistr_info_gps_fixed, ttff);
                fixed = 1;
                // for auto test
                LOGD(TAG"Fix success");
                // ttff_check_res = 1;
            } else if ((g_gpsInfo.FixType != 0) && (ttff == 0)) {  // skip prev second's NMEA, clear data
                ptr += sprintf(ptr, "%s: %d\n", uistr_info_gps_ttff, ttff++);
                memset(&g_gpsInfo, 0, sizeof(g_gpsInfo));
                memset(g_svInfo, 0, (sizeof(SVInfo)*NUM_CH));
                memset(g_chInfo, 0, (sizeof(ChInfo)*PSEUDO_CH));
            }
            else {   // no fix
                ptr += sprintf(ptr, "%s: %d\n", uistr_info_gps_ttff, ttff++);
            }

            for (i = 0; i < g_gpsInfo.SV_cnt; i++) {
                ptr += sprintf(ptr, "%s[%d] : %d\n", uistr_info_gps_svid, g_svInfo[i].SVid, g_svInfo[i].SNR);
                ttff_check_res = 1;
            }
        }
    }

    return;
}


static void *gps_update_start(TestEntry* gpsentry)
{

    short count = 1, chkcnt = 300;
    int init_status;

    LOGD(TAG "%s: Start\n", __FUNCTION__);
    
    // init GPS driver
    int bufsize = sizeof(gpsentry->value.name);
    gps_update_info(gpsentry->value.name,bufsize);
    memset(gpsentry->value.name, '\n', bufsize);
    sprintf(gpsentry->value.name, "%s\n", uistr_info_gps_init);

    //if (GPS_param.test_type != 3)  /* 3 means test on background */
    //    iv->redraw(iv);
    drawItemValueBehind(gpsentry);

    sleep(1);
    
    init_status = GPS_Open();
    if (init_status != 0) {   // GPS init fail
        gpsentry->state = TEST_FAIL;
        memset(gpsentry->value.name, '\n', bufsize);
        sprintf(gpsentry->value.name, "%s (%d)\n", uistr_info_gps_error, init_status);
        //if (GPS_param.test_type != 3)
        //iv->redraw(iv);
        drawItemValueBehind(gpsentry);
    } else {
        // init GPS driver done
        ttff = 0;
        fixed = 0;
        memset(gpsentry->value.name, '\n', bufsize);
        //if (GPS_param.test_type != 3)
        //    iv->redraw(iv);
        drawItemValueBehind(gpsentry);
        while (gpsthreadrun) {
            usleep(100000);  // wake up every 0.1sec
            chkcnt--;

            if (httff == 1) {
                httff = 0;
                write(sockfd, "$PMTK101*32\r\n", sizeof("$PMTK101*32\r\n"));
                ttff = 0;
                fixed = 0;
                memset(gpsentry->value.name, '\n', bufsize);
                gpsentry->value.name[bufsize-1] = 0x0;
                //if (GPS_param.test_type != 3)
                //iv->redraw(iv);
                drawItemValueBehind(gpsentry);
            }

            if (cttff == 1) {
                cttff = 0;
                write(sockfd, "$PMTK103*30\r\n", sizeof("$PMTK103*30\r\n"));
                ttff = 0;
                fixed = 0;
                memset(gpsentry->value.name, '\n', bufsize);
                gpsentry->value.name[bufsize-1] = 0x0;
                //if (GPS_param.test_type != 3)
                //    iv->redraw(iv);
                drawItemValueBehind(gpsentry);
            }

            if (chkcnt%10 != 0)
                continue;
           
            gps_update_info(gpsentry->value.name,bufsize);
            //if (GPS_param.test_type != 3)
            //    iv->redraw(iv);
            drawItemValueBehind(gpsentry);
            if (g_gpsInfo.SV_cnt >= 2){
            	gpsentry->state = TEST_PASS;
                break;
            }
            if(chkcnt<0 ){
                if (ttff_check_res!=1){
                	gpsentry->state = TEST_FAIL;
                    gpsentry->value.color = REDCOLOR;
                    strcpy(gpsentry->value.name,uistr_info_gpstimeout);
                    drawItemValueBehind(gpsentry);
                }
                break;
            }
            
        }
    }
    //close GPS driver
    GPS_Close();
    setProinfoItemResult(gpsentry->id,gpsentry->state);
    LOGD(TAG "%s: Exit\n", __FUNCTION__);
    return NULL;
}

extern pthread_mutex_t audioMutex;//GPS影响音频测试,特别是听筒
extern TestEntry gpsEntry;
void * jlink_gps_start(void*para){

	gpsthreadrun= 1;
    drawTestItem(&gpsEntry);
    strcpy(gpsEntry.value.name,uistr_info_waiting);
    drawItemValueBehind(&gpsEntry);
    pthread_mutex_lock(&audioMutex);
    gps_update_start(&gpsEntry);
    pthread_mutex_unlock(&audioMutex);
    //drawItemValueBehind(&gpsEntry);
    pthread_exit(NULL);
    return NULL;
}

void jlink_stop_gpstest(){
	gpsthreadrun = 0;
}
