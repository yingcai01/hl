#include "jlinkui.h"
#include "hardware/ccci_intf.h"

#define DEVICE_NAME ccci_get_node_name(USR_FACTORY_RF, MD_SYS1)

extern int send_at (const int fd, const char *pCMD);
extern int wait4_ack (const int fd, char *pACK, int timeout);
extern int read_ack (const int fd, char *rbuff, int length);

int jlinkgetBarcode(int fd,char *result)
{
	const int BUF_SIZE = 128;
	char buf[BUF_SIZE];
	const int HALT_TIME = 100 * 1000;
	int count = 0;
	char *p = NULL;

	strcpy(buf, "AT+EGMR=0,5\r\n");
	strcpy(result, "unknown");

retry:
	send_at(fd, buf);
	memset(buf,'\0',BUF_SIZE);
	read_ack(fd,buf,BUF_SIZE);
	LOGD("buf %s",buf);

	p = strchr(buf, '\"'); // find the first double quotation mark.
	if(p) {
		strcpy(result, ++p);
		count = 3;
	} else {
		strcpy(buf, "AT\r\n");
		count++;
	}

	if(count < 3)
	{
        LOGD(TAG "COUNT IN BARCODE IS %d\n", count);
		goto retry;
	}
	LOGE("getBarcode result = %s\n", result);
	return 0;
}


static void *lte_cft_update_info(TestEntry* cftentry)
{

    int rssi0_dbm = 0;
    int rssi1_dbm = 0;
    int ret = 0;
    int len = 0;
    int retryCount = 0;

    char barcode[128] = "unknown";
    char *tem;

    const int BUF_SIZE = 256;
    char cmd_buf[BUF_SIZE];
    char rsp_buf[BUF_SIZE];
    const int HALT_TIME = 200000;//0.2s (200000ms)

    LOGD(TAG "%s: Start\n", __FUNCTION__);

    int fd = -1;
    fd = open(DEVICE_NAME, O_RDWR);
    if(fd < 0) {
        LOGD(TAG "Fail to open %s: %s\n",DEVICE_NAME, strerror(errno));
        goto err;
    }
    LOGD(TAG "%s has been opened...\n",DEVICE_NAME);



    LOGD(TAG "[AT]AT polling first:\n");
    do
    {
        send_at (fd, "AT\r\n");
    } while (wait4_ack (fd, NULL, 300));


    LOGD(TAG "[AT]Disable Sleep Mode:\n");
    send_at (fd, "AT+ESLP=0\r\n");
    if (wait4_ack (fd, NULL, 3000))goto err;

	//add by wubo 150807  begin
	/* check barcode last char 10P ,has been calibcation*/
	ret = jlinkgetBarcode(fd, barcode);
	tem = strchr(barcode, '\"');
	if (tem != NULL) {
	    *tem = 0;
	}
	if(strlen(barcode) <= 0)
		strcpy(barcode, "unknown");

	
	len = 0;
	len += sprintf(cftentry->value.name,"barcode:%s\n", barcode);
	char *temstr = strrchr(cftentry->value.name,' ');
	if (temstr!=NULL)
	{
		*temstr = '\n';
	}
	
	if(NULL != strstr(barcode,"10P"))
	{
		LOGD(TAG "CFT Test result pass\n");
		//cft->mod->test_result = FTM_TEST_PASS;
	    cftentry->state = TEST_PASS;    
        len += sprintf(cftentry->value.name + len,"%s: %s. \n", uistr_cft_test, uistr_info_pass);
		 	
	}else{
		cftentry->state = TEST_FAIL;
		LOGD(TAG "CFT Test result failed\n");
		//cft->mod->test_result = FTM_TEST_FAIL;	      
		len += sprintf(cftentry->value.name + len,"%s: %s. \n", uistr_cft_test, uistr_info_fail);
	}
	//add by wubo 150807  end.

   close(fd);
   fd = -1;
    setProinfoItemResult(cftentry->id,cftentry->state);
	LOGD(TAG "%s: Exit\n", __FUNCTION__);
	usleep(HALT_TIME * 30);	
	return NULL;
err:
	LOGD(TAG "%s: FAIL\n",__FUNCTION__);

	len = 0;
	len += sprintf(cftentry->value.name + len,"%s: %s. \n", uistr_cft_test, uistr_info_fail);
	len += sprintf(cftentry->value.name + len,"barcode: %s\n", barcode);
	close(fd);
	fd = -1;
	cftentry->state = TEST_FAIL;
	setProinfoItemResult(cftentry->id,cftentry->state);
	LOGD(TAG "redraw\n");
	usleep(HALT_TIME * 30);
	LOGD(TAG "%s: Exit\n", __FUNCTION__);

	return NULL;
}


static void *cft_update_info(TestEntry* cftentry)
{

    int rssi0_dbm = 0;
    int rssi1_dbm = 0;
    int ret = 0;
    int len = 0;
    int retryCount = 0;

    char barcode[128] = "unknown";
    char *tem;

    const int BUF_SIZE = 256;
    char cmd_buf[BUF_SIZE];
    char rsp_buf[BUF_SIZE];
    const int HALT_TIME = 200000;//0.2s (200000ms)

    LOGD(TAG "%s: Start\n", __FUNCTION__);

    int fd = -1;
    fd = open(DEVICE_NAME, O_RDWR);
    if(fd < 0) {
        LOGD(TAG "Fail to open %s: %s\n",DEVICE_NAME, strerror(errno));
        goto err;
    }
    LOGD(TAG "%s has been opened...\n",DEVICE_NAME);



    LOGD(TAG "[AT]AT polling first:\n");
    do
    {
        send_at (fd, "AT\r\n");
    } while (wait4_ack (fd, NULL, 300));


    LOGD(TAG "[AT]Disable Sleep Mode:\n");
    send_at (fd, "AT+ESLP=0\r\n");
    if (wait4_ack (fd, NULL, 3000))goto err;

	//add by wubo 150807  begin
	/* check barcode last char 10P ,has been calibcation*/
	ret = jlinkgetBarcode(fd, barcode);
	tem = strchr(barcode, '\"');
	if (tem != NULL) {
	    *tem = 0;
	}
	if(strlen(barcode) <= 0)
		strcpy(barcode, "unknown");

	
	len = 0;
	len += sprintf(cftentry->value.name,"barcode:%s\n", barcode);	
	char *temstr = strrchr(cftentry->value.name,' ');
	if (temstr!=NULL)
	{
		*temstr = '\n';
	}
	
	if(NULL != strstr(barcode,"10P"))
	{
		cftentry->state = TEST_PASS;
		LOGD(TAG "CFT Test result pass\n");
		//cft->mod->test_result = FTM_TEST_PASS;
	    cftentry->value.color = GREENCOLOR;    
        len += sprintf(cftentry->value.name + len,"%s: %s. \n", uistr_cft_test, uistr_info_pass);
		 	
	}else{
		cftentry->state = TEST_FAIL;
		LOGD(TAG "CFT Test result failed\n");
		//cft->mod->test_result = FTM_TEST_FAIL;	      
		len += sprintf(cftentry->value.name + len,"%s: %s. \n", uistr_cft_test, uistr_info_fail);
	}
	//add by wubo 150807  end.

    close(fd);
    fd = -1;
    setProinfoItemResult(cftentry->id,cftentry->state);	
	LOGD(TAG "%s: Exit normal\n", __FUNCTION__);
	usleep(HALT_TIME * 30);	
	return NULL;

err:
	LOGD(TAG "%s: FAIL\n",__FUNCTION__);

	len = 0;
	len += sprintf(cftentry->value.name + len,"%s: %s. \n", uistr_cft_test, uistr_info_fail);
	len += sprintf(cftentry->value.name + len,"barcode: %s\n", barcode);
	close(fd);
	fd = -1;
	cftentry->state = TEST_FAIL;
	setProinfoItemResult(cftentry->id,cftentry->state);	
	LOGD(TAG "redraw\n");
	usleep(HALT_TIME * 30);
	LOGD(TAG "%s: Exit err\n", __FUNCTION__);

	return NULL;
}



extern int ismodemboot;
extern pthread_mutex_t modemMutex;
extern TestEntry cftEntry;
void * jlink_cft_start(void*para){

    drawTestItem(&cftEntry);
    if (ismodemboot==0)
    {
    	strcpy(cftEntry.value.name,"Waiting modem boot");
    	drawItemValueAuto(&cftEntry);
    }
    while(ismodemboot==0){
    	usleep(300000);
    }
    strcpy(cftEntry.value.name,uistr_info_waiting);
    drawItemValueAuto(&cftEntry);
    pthread_mutex_lock(&modemMutex);
    sleep(1);
    sprintf(cftEntry.value.name, "%s\n", uistr_info_testing);
    drawItemValueAuto(&cftEntry);
#ifdef MTK_LTE_SUPPORT
	lte_cft_update_info(&cftEntry);
#else
	cft_update_info(&cftEntry);
#endif
	pthread_mutex_unlock(&modemMutex);
    drawItemValueAuto(&cftEntry);
    return NULL;
}