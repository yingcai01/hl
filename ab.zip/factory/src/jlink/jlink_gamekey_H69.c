#include "jlinkui.h"
#include "graphics.h"
#include <dirent.h>
#include <poll.h>

#define LEFTRODX 400
#define RODY 160

static gr_surface big_surface;
static gr_surface sma_surface;
static int big_width;
static int big_height;
static int half_big_width;
static int half_big_height;
static int small_width;
static int small_height;
static int half_small_width;
static int half_small_height;

extern TestEntry keyentry;
static int org_lef_x;
static int org_lef_y;
static int dst_lef_x;
static int dst_lef_y;
static int org_rig_x;
static int org_rig_y;
static int dst_rig_x;
static int dst_rig_y;

static int left_clear_X1;
static int left_clear_Y1;
static int left_clear_X2;
static int left_clear_Y2;

static int right_clear_X1;
static int right_clear_Y1;
static int right_clear_X2;
static int right_clear_Y2;

static pthread_mutex_t flipMutex;
static pthread_mutex_t drawMutex;
static pthread_mutex_t draw1Mutex;
static pthread_mutex_t draw2Mutex;
static pthread_cond_t cond1;
static int isneeddraw1,isneeddraw2;
static int oldx,oldy,oldz,oldrz;
static int x_,y_;
static int x,y,z,rz;
extern void ui_clear_key_queue();
extern int res_create_surface(const char* fname, gr_surface* pSurface);;
static void* StartRodEvenet(void*param);
static void* startKeyEvent(void*param);
static void* StartRodEvenet(void*param);
static void* drawImageRod1(void* param);
static void drawImageRod(int x,int y, int z, int rz);
static int gamekeyrun;
static int dirkeynum = 4;
typedef void (*Callbak)();
static int flag = 0;
static int resultFlag=0;
static int rodresult = 0;

extern int jlcd_width;
extern int jlcd_height;
struct GameMap{
	Callbak call;
	int keycode;
	int isdraw;
};

//L1
static void drawKeyL1(){
	gr_fill( 10, 10, 110, 70);
	flag |= 0x1;
}

//L2
static void drawKeyL2(){
	gr_fill( 130, 30, 210, 70);
	flag |= 0x2;
}

//R1
static void drawKeyR1(){
	gr_fill( jlcd_width-110, 10, jlcd_width-10, 70);
	flag |= 0x4;
}

//R2
static void drawKeyR2(){
	gr_fill( jlcd_width-210, 30, jlcd_width - 130, 70);
	flag |= 0x8;
}

//UP
static void drawUpkey(){
	jlinkdrawRealCircle(140,200,40);
	flag |= 0x10;
}

//DOWN
static void drawDownkey(){
	jlinkdrawRealCircle(140,330,40);
	flag |= 0x20;
}

//LEFT
static void drawLeftkey(){
	jlinkdrawRealCircle(60,265,40);
	flag |= 0x40;
}

//RIGHT
static void drawRightkey(){
	jlinkdrawRealCircle(220,265,40);
	flag |= 0x80;
}

//VOL+
static void drawVolUpkey(){
	jlinkdrawRealCircle(220,420,30);
	flag |= 0x100;
}

//VOL-
static void drawVolDownkey(){
	jlinkdrawRealCircle(230,490,30);
	flag |= 0x200;
}

//X
static void drawXkey(){
	jlinkdrawRealCircle(jlcd_width-220,250,40);
	flag |= 0x400;
}

//Y
static void drawYkey(){
	jlinkdrawRealCircle(jlcd_width-140,185,40);
	flag |= 0x800;
}

//A
static void drawAkey(){
	jlinkdrawRealCircle(jlcd_width-140,315,40);
	flag |= 0x1000;
}

//B
static void drawBkey(){
	jlinkdrawRealCircle(jlcd_width-60,250,40);
	flag |= 0x2000;
}

//START
static void drawStartkey(){
	gr_fill( jlcd_width-220, 380, jlcd_width-50, 410);
	flag |= 0x4000;
}

//SELECT
static void drawSelectkey(){
	gr_fill( jlcd_width-220, 430, jlcd_width-65, 460);
	flag |= 0x8000;
}

//G
static void drawGkey(){
	gr_fill( jlcd_width-220, 480, jlcd_width-80, 510);
	flag |= 0x10000;
}

//POWER
static void drawPowerkey(){
	gr_fill( jlcd_width-220, 530, jlcd_width-95, 560);
	flag |= 0x20000;
}



static struct GameMap gameMap[] = {
	{drawKeyL1,310},
	{drawKeyL2,312},
	{drawKeyR1,311},
	{drawKeyR2,313},
	{drawUpkey,103},
	{drawDownkey,108},
	{drawLeftkey,105},
	{drawRightkey,106},
	{drawVolUpkey,115},
	{drawVolDownkey,114},
	{drawXkey,307},
	{drawYkey,308},
	{drawAkey,304},
	{drawBkey,305},
	{drawStartkey,315},
	{drawSelectkey,314},
	{drawGkey,88},
	{drawPowerkey,116},
};


static pthread_t key_handle;
static pthread_t image_handle;
static pthread_t drawleft_handle;
static pthread_t drawright_handle;
void jlink_start_gamekey_H69(){
	int i;
	oldx = -256,oldy=-256,oldz=-256,oldrz=-256;
	
	int ret = res_create_surface("/vendor/res/images/big.png",&big_surface);
	if (ret != 0){
		LOGD("MYTEST drawImageRod error0 ret=%d,errno=%d",ret,errno);
		return;
	}
	big_width = gr_get_width(big_surface);
	big_height = gr_get_height(big_surface);
	LOGE("MYTEST big_width=%d,big_height=%d",big_width,big_height);
	ret = res_create_surface("/vendor/res/images/small.png",&sma_surface);
	if (ret != 0){
		LOGD("MYTEST drawImageRod error1");
		return;
	}
	small_width = gr_get_width(sma_surface);
	small_height = gr_get_height(sma_surface);
	

	left_clear_X1 = LEFTRODX-small_width/2;
	left_clear_Y1 = RODY - small_height/2;
	left_clear_X2 = LEFTRODX+small_width/2+big_width;
	left_clear_Y2 = RODY + small_height/2 + big_height;
	org_lef_x = LEFTRODX+(big_width-small_width)/2;
	org_lef_y = RODY+(big_height-small_height)/2;

	half_big_width = big_width/2;
	half_big_height = big_height/2;
	
    //remove rod
	drawImageRod(0,0,0,0);

	
	gamekeyrun = 1;
	set_gr_color(0xcccccc55);
    resultFlag=0;
	int keymapnum = sizeof(gameMap)/sizeof(gameMap[0]);
	for (i=0;i<keymapnum;i++){
		(gameMap[i].call)();
	}

	#ifdef JLINK_ITEM_DEBUG
	gr_flip();
	#endif
	resultFlag=flag;
	flag = 0;
	rodresult = 0;
	isneeddraw1 = 0;
	isneeddraw2 = 0;
	#ifdef JLINK_ITEM_DEBUG
	pthread_mutex_init(&flipMutex,NULL);
	#endif
	pthread_mutex_init(&drawMutex,NULL);
	pthread_mutex_init(&draw1Mutex,NULL);
	pthread_mutex_init(&draw2Mutex,NULL);
	pthread_cond_init(&cond1,NULL);
	pthread_create(&key_handle,NULL,startKeyEvent,NULL);
	//remove Rod Test
	pthread_create(&image_handle,NULL,StartRodEvenet,NULL);
	pthread_create(&drawleft_handle,NULL,drawImageRod1,NULL);
	//pthread_create(&drawright_handle,NULL,drawImageRod2,NULL);
	pthread_join(key_handle,NULL);
	pthread_join(image_handle,NULL);
	pthread_join(drawleft_handle,NULL);
	//pthread_join(drawright_handle,NULL);
	pthread_cond_destroy(&cond1);
	if (flag == resultFlag && rodresult==0xF){
		keyentry.state = TEST_PASS;
		keyentry.value.color = GREENCOLOR;
		strcpy(keyentry.value.name,uistr_info_jpass);
	}
	setProinfoItemResult(keyentry.id,keyentry.state);
	
}



static void* startKeyEvent(void*param){
	int key;
	int keymapnum = sizeof(gameMap)/sizeof(gameMap[0]);
	int i;
	int times = 0;
	int oldkey = -1;
	struct timespec ntime;
	ntime.tv_sec= time(NULL)+5;
	ntime.tv_nsec=0;
	ui_clear_key_queue();
	while(gamekeyrun){
		key=jlink_wait_key(&ntime);
		if (key!=110){
			LOGD("MYTEST keycode=%d",key);
			if (oldkey == key){
				times++;
			}else{
				oldkey = key;
				times = 1;
			}
			if (times == 5){
				keyentry.state = TEST_FAIL;
				keyentry.value.color = REDCOLOR;
				strcpy(keyentry.value.name,uistr_info_jfail);
				gamekeyrun = 0;
				break;
			}
			switch (key){
				default:
					for (i=0;i<keymapnum;i++){
						if (key == gameMap[i].keycode){
							#ifdef JLINK_ITEM_DEBUG
							pthread_mutex_lock(&flipMutex);
							#endif
							set_gr_color(0x11cc1177);
							(gameMap[i].call)();
							#ifdef JLINK_ITEM_DEBUG
							gr_flip();
							pthread_mutex_unlock(&flipMutex);
							#endif
							
							break;
						}
					}
			}
			if (flag == resultFlag && rodresult==0xF){
				gamekeyrun = 0;
				break;
			}
				
		}
		

	}
	return NULL;
}

static void* drawImageRod1(void* param){
	while(gamekeyrun){
		pthread_cond_wait(&cond1,&draw1Mutex);
		#ifdef JLINK_ITEM_DEBUG
        pthread_mutex_lock(&flipMutex);
        #endif
		
/*
		do_fill(left_clear_X1,left_clear_Y1,left_clear_X2,left_clear_Y2,BACKCOLOR);
		draw_image(LEFTRODX,RODY,(GRSurface*)big_surface);
		draw_image(x_,y_,(GRSurface*)big_surface);
*/
		
		set_gr_color(BACKCOLOR);
		gr_fill(left_clear_X1,left_clear_Y1,left_clear_X2,left_clear_Y2);
		gr_blit((GRSurface*)big_surface, 0, 0, big_width, big_height, LEFTRODX, RODY);
		gr_blit((GRSurface*)sma_surface, 0, 0, small_width, small_height, x_, y_);
		
		#ifdef JLINK_ITEM_DEBUG
		gr_flip();
		pthread_mutex_unlock(&flipMutex);
		#endif
		pthread_cond_signal(&cond1);
	}
	return NULL;
}

static void drawImageRod(int x,int y, int z, int rz){
	if (x != oldx && y != oldy){
		oldx = x;
		oldy = y;
		//set_gr_color(BACKCOLOR);
		gr_fill(left_clear_X1,left_clear_Y1,left_clear_X2,left_clear_Y2);
		dst_lef_x = (int)(org_lef_x + (float)x/255*half_big_width);
		dst_lef_y = (int)(org_lef_y + (float)y/255*half_big_height);
		gr_blit((GRSurface*)big_surface, 0, 0, big_width, big_height, LEFTRODX, RODY);
		gr_blit((GRSurface*)sma_surface, 0, 0, small_width, small_height, dst_lef_x, dst_lef_y);
	}
	LOGD("MYTEST startDraw");
	#ifdef JLINK_ITEM_DEBUG
	gr_flip();
	#endif
	
}

static struct pollfd pfd;
static void* StartRodEvenet(void*param){
	DIR *dir;
	struct dirent *de;
	char name[100];
	dir = opendir("/dev/input");
	int fd;
	if (dir != NULL)
	{
		while(de = readdir(dir)){
			if(strncmp(de->d_name,"event",5)) continue;
			fd = openat(dirfd(dir), de->d_name, O_RDONLY);
            if(fd < 0) continue;

            ioctl(fd, EVIOCGNAME(sizeof(name) - 1), name);
            LOGD("MYTEST0,StartRodEvenet name=%s",name);
            if (!strcmp(name, "jlink_joy playgame")) {
            	pfd.fd = fd;
            	pfd.events = POLLIN;
            	break;
            }else{
            	close(fd);
            	fd = -1;
            }
		}
		closedir(dir);
	}

	if (fd == -1){
		LOGE("MYTEST StartRodEvenet open event error");
		return NULL;
	}
	int ret;
	struct input_event ev;
	x=0,y=0,z=0,rz=0;
	int temx = 0;
	int temy = 0;
	int temz = 0;
	int temrz = 0;
	do{
		ret = poll(&pfd,1,0);
		if (ret >0){
			if(pfd.revents & POLLIN){
				ret = read(pfd.fd, &ev, sizeof(ev));
				if(ret == sizeof(ev)) {
					//LOGD("MYTEST ev.type=%d,ev.code=%d,ev->value=%d",ev.type,ev.code,ev.value);
					
					if (ev.type == EV_ABS){
						if (ev.code == ABS_X){
							temx = ev.value;
						}else if (ev.code == ABS_Y){
							temy = ev.value;
						}else if (ev.code == ABS_Z){
							temz = ev.value;
						}else if (ev.code == ABS_RZ){
							temrz = ev.value;
						}
				}else if (ev.type==EV_SYN){
						if (temx!=oldx || temy != oldy){
							//pthread_mutex_lock(&draw1Mutex);
							oldx = temx;
							oldy = temy;
							x_ = (int)(org_lef_x + (float)temx/255*half_big_width);
							y_ = (int)(org_lef_y + (float)temy/255*half_big_height);
							pthread_cond_signal(&cond1);
        					//pthread_mutex_unlock(&draw1Mutex);
        					
        					if (rodresult!=0xF){
        						LOGD("MYTEST x:%d,y:%d",temx,temy);
        						if (temx > 200 && abs(temy) < 50){
        							rodresult |= 0x1;
        						}else if (temx < -200 && abs(temy) < 50){
        							rodresult |= 0x2;
        						}else if (abs(temx) < 50 && temy > 200){
        							rodresult |= 0x4;
        						}else if (abs(temx) < 50 && temy < -200){
        							rodresult |= 0x8;
        						}
        						
        					}
        					if (flag == resultFlag && rodresult==0xF){
								gamekeyrun = 0;
							}
        					
						}/*else if(z!=oldz || rz != oldrz ){
							pthread_mutex_lock(&draw2Mutex);
							oldz = z;
							oldrz = rz;
							x_ = (int)(org_rig_x + (float)z/255*half_big_width);
							y_ = (int)(org_rig_y + (float)rz/255*half_big_height);
							pthread_cond_signal(&cond2);
	        				pthread_mutex_unlock(&draw2Mutex);
	        				pthread_cond_wait(&cond,&drawMutex);
	        				
						}*/
						
						//drawImageRod(x,y,z,rz);
						//LOGD("MYTEST x:%d,y:%d oldx:%d,oldy:%d z:%d,rz:%d",
						//	x,y,oldx,oldy,z,rz);
					}	
				}
				
			}
		}
	}while(gamekeyrun);
	pthread_cond_signal(&cond1);
	close(fd);
	return NULL;
}