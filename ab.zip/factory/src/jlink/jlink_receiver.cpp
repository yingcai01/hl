#include "../test/ftm_audio_Common.h"


#include "ftm.h"
extern "C" {
#include "jlinkui.h"
#include "DIF_FFT.h"
#include "Audio_FFT_Types.h"
#include "Audio_FFT.h"
}

#define WAVE_PLAY_SLEEP_TIME (100)
#define TEXT_LENGTH (1024)
#define MAX_FILE_NAME_SIZE (100)

static char FileListNamesdcard[] = "/sdcard/factory.ini";
static char FileListName[]           = "/system/vendor/etc/factory.ini";
static char FileStartString_LoudspkPlayback[]      = "//AudioRingtonePlayFile";
static const char ouput_dev_name[3][16] = {"Receiver", "Headset", "Speaker"};
extern TestEntry recEntry;
extern Button recbutton;
ButtonEntry recbtnentry;

struct mAudio
{
    struct ftm_module *mod;
    struct textview tv;
    struct itemview *iv;
    pthread_t hHeadsetThread;
    pthread_t hRecordThread;
    pthread_mutex_t mHeadsetMutex;
    int avail;
    int Headset_change;
    int Headset_mic;
    bool exit_thd;
    char  info[TEXT_LENGTH];
    char  file_name[MAX_FILE_NAME_SIZE];
    int   i4OutputType;
    int   i4Playtime;
    int  recordDevice;
    text_t    title;
    text_t    text;
    text_t    left_btn;
    text_t    center_btn;
    text_t    right_btn;
};


static int read_preferred_ringtone_time(void)
{
    int time = 0;
    char *pTime = NULL;
    char uName[64];

    memset(uName, 0, sizeof(uName));
    sprintf(uName, "Audio.Ringtone");
    pTime = ftm_get_prop(uName);
    if (pTime != NULL)
    {
        time = (int)atoi(pTime);
        ALOGD("preferred_ringtone_time: %d sec\n", time);
    }
    else
    {

        ALOGD("preferred_ringtone_time can't get\n");
    }
    return time;
}

static int getFileNAmeSize(char buffer[])
{
    int length = 0;
    while (buffer[length] != '\0' &&  buffer[length] != '\n' &&  buffer[length] != '\r' && buffer[length] != ';')
    {
        //printf("buffer[%d] = %x \n",length,buffer[length]);
        length++;
    }
    return length;
}


static void Audio_Wave_clear_WavePlayInstance(WavePlayData *pWaveInstance)
{
    if (pWaveInstance->FileName != NULL)
    {
        delete[] pWaveInstance->FileName;
        pWaveInstance->FileName = NULL;
    }
    printf("delete[] WavePlayInstance.FileName; \n");
    if (pWaveInstance->pFile != NULL)
    {
        fclose(pWaveInstance->pFile);
        pWaveInstance->pFile = NULL;
    }
    printf(" fclose(WavePlayInstance.pFile; \n");
    memset((void *)pWaveInstance, 0 , sizeof(WavePlayData) - sizeof(pthread_t));
    printf("memset((void*)&WavePlayInstance, 0 ,sizeof(WavePlayData) - sizeof(pthread_t)) \n");
}

static void *Audio_Wave_Playabck_thread(void *mPtr)
{
    struct mAudio *hds  = (struct mAudio *)mPtr;
    int wave_play_time  = hds->i4Playtime;

    ALOGD(TAG "%s: Start\n", __FUNCTION__);

    // for filelist and now read file
    FILE *pFileList = NULL;
    FILE *PReadFile = NULL;
    // buffer fir read filelist and file
    char FileNamebuffer[MAX_FILE_NAME_SIZE];
    int readlength = 0;
    bool FileListEnd = false;
    bool openfielerror = false;
    WavePlayData WavePlayInstance;
    memset((void *)&WavePlayInstance, 0 , sizeof(WavePlayData));
    recEntry.state = TEST_FAIL;
    //open input file  list
    pFileList = fopen(FileListNamesdcard, "rb");
    if (pFileList == NULL)
    {
        printf("error reopen file %s\n", FileListNamesdcard);
        pFileList = fopen(FileListName, "rb");
        if (pFileList == NULL)
        {
            FileListEnd = true;
            openfielerror = true;
            printf("error opening file %s\n", FileListName);
        }
    }
    while (pFileList && !feof(pFileList))
    {
        char *CompareNamebuffer = NULL;
        int filelength = 0;
        int CompareResult = -1;
        memset((void *)FileNamebuffer, 0, MAX_FILE_NAME_SIZE);
        fgets(FileNamebuffer, 100, pFileList);

        // crop file name to waveplay data structure
        filelength = getFileNAmeSize(FileNamebuffer);
        printf("getFileNAmeSize = %d\n", filelength);
        if (filelength > 0)
        {
            CompareNamebuffer = new char[filelength + 1];
            memset((void *)CompareNamebuffer, '\0', filelength + 1);
            memcpy((void *)CompareNamebuffer, (void *)FileNamebuffer, filelength);
            printf("get file list filename %s\n", FileNamebuffer);
            printf("get file list CompareNamebuffer %s\n", CompareNamebuffer);
            CompareResult = strcmp(CompareNamebuffer, hds->file_name);
            printf("CompareResult = %d \n", CompareResult);
        }

        if (CompareNamebuffer)
        {
            delete[] CompareNamebuffer;
            CompareNamebuffer = NULL;
        }

        if (CompareResult == 0)
        {
            printf("CompareResult ==0 \n");
            break;
        }
    }

    WavePlayInstance.i4Output = hds->i4OutputType;

    while (1)
    {
        if (openfielerror == true)
        {
            /* preare text view info */
            char *ptr;
            ptr = hds->info;
            ptr += sprintf(ptr, "error open ini file\n");
        }
        // read file list is not null
        while (((pFileList && !feof(pFileList) && FileListEnd == false) || (WavePlayInstance.ThreadStart == true)) && hds->exit_thd == false)
        {
            if (wave_play_time < 0)
            {
                WavePlayInstance.ThreadExit = true;
                goto WAVE_SLEEP;
            }
            if (WavePlayInstance.ThreadStart == false)
            {
                // clear all wave data.
                if (WavePlayInstance.ThreadExit == true && WavePlayInstance.ThreadStart == false)
                {
                    printf("WavePlayInstance.ThreadExit = true clean all data\n");
                    Audio_Wave_clear_WavePlayInstance(&WavePlayInstance);
                    WavePlayInstance.WavePlayThread = (pthread_t) NULL;
                }

                // get Filelist FileNamebuffer
                int filelength = 0;
                memset((void *)FileNamebuffer, 0, MAX_FILE_NAME_SIZE);
                if (pFileList != NULL)
                {
                    fgets(FileNamebuffer, 100, pFileList);
                }
                printf("get file list filename %s\n", FileNamebuffer);
                // crop file name to waveplay data structure
                filelength = getFileNAmeSize(FileNamebuffer);
                printf("getFileNAmeSize = %d\n", filelength);
                if (filelength > 0)
                {
                    WavePlayInstance.FileName = new char[filelength + 7 + 1];
                    memset(WavePlayInstance.FileName, '\0', filelength + 7 + 1);
                    memcpy(WavePlayInstance.FileName, "/vendor", 7);  // add prefix "/system"
                    memcpy((WavePlayInstance.FileName) + 7, (void *)FileNamebuffer, filelength);
                }
                printf("get filename %s\n", WavePlayInstance.FileName);
                // create audio playback rounte
                if (WavePlayInstance.WavePlayThread == (pthread_t) NULL)
                {
                    WavePlayInstance.ThreadStart = true ;
                    WavePlayInstance.ThreadExit = false ;
                    printf("Audio_Wave_playback\n");
                    Audio_Wave_playback((void *)&WavePlayInstance);
                    recEntry.state = TEST_PASS;
                    printf("Audio_Wave_playback thread create\n");
                }
            }

WAVE_SLEEP:
            usleep(WAVE_PLAY_SLEEP_TIME * 1000); // sleep 100 ms
            wave_play_time -= WAVE_PLAY_SLEEP_TIME ;
        }

        if (hds->exit_thd)
        {
            WavePlayInstance.ThreadExit = true;

            printf("+WavePlayInstance.ThreadStart = %d\n", WavePlayInstance.ThreadStart);
            pthread_join(WavePlayInstance.WavePlayThread, NULL);
            printf("-WavePlayInstance.ThreadStart = %d\n", WavePlayInstance.ThreadStart);
            
            // clear all wave data.
            if (WavePlayInstance.ThreadExit == true)
            {
                printf("WavePlayInstance.ThreadExit = true clean all data\n");
                Audio_Wave_clear_WavePlayInstance(&WavePlayInstance);
            }
            break;
        }
        usleep(WAVE_PLAY_SLEEP_TIME * 1000); // sleep 100 ms
    }

    ALOGD(TAG "%s: Audio_Wave_Playabck_thread Exit \n", __FUNCTION__);
    setProinfoItemResult(recEntry.id,recEntry.state);
    pthread_exit(NULL); // thread exit
    return NULL;
}

extern pthread_mutex_t audioMutex;
int mAudio_receiver_auto_entry(void *priv)
{
    char *ptr;
    int chosen;
    bool exit = false;
    struct mAudio *mc = (struct mAudio *)priv;

    ALOGD(TAG "--------mAudio_receiver_entry-----------------------\n");
    ALOGD(TAG "%s\n", __FUNCTION__);

    // init Audio
    strcpy(recEntry.value.name, uistr_info_waiting);
    drawItemValueBehind(&recEntry);
    pthread_mutex_lock(&audioMutex);
    strcpy(recEntry.value.name, uistr_info_rec_tips);
    drawItemValueBehind(&recEntry);
    Common_Audio_init();
    mc->exit_thd = false;

    memset(mc->info, 0, sizeof(mc->info) / sizeof(*(mc->info)));
    memset(mc->file_name, 0, MAX_FILE_NAME_SIZE);
    strcpy(mc->file_name, FileStartString_LoudspkPlayback);
    mc->i4OutputType = Output_HS;
    int ringtime = read_preferred_ringtone_time();
    if (ringtime <=0) ringtime=5;
    mc->i4Playtime =  ringtime* 1000; //ms
    LOGD("MYTEST mc->i4Playtime=%d",mc->i4Playtime);
    pthread_create(&mc->hHeadsetThread, NULL, Audio_Wave_Playabck_thread, mc);
    sleep(ringtime);
    mc->exit_thd = true;
    pthread_join(mc->hHeadsetThread, NULL);
    Common_Audio_deinit();
    pthread_mutex_unlock(&audioMutex);

    LOGD(TAG "%s: End\n", __FUNCTION__);
    return 0;
}

void* mAudio_receiver_entry(void *para)
{
    struct mAudio *mc = (struct mAudio *)calloc(sizeof(struct mAudio),1);
    mAudio_receiver_auto_entry(mc);
    strcpy(recEntry.value.name, uistr_info_testover);
    drawItemValueBehind(&recEntry);
    DrawButtonBehindEntry(&recbutton,&recEntry);
    if (mc!=NULL){
        free(mc);
    }
	return NULL;
}


void * jlink_receiver_start(void*para){
    initTestButton(&recbutton,mAudio_receiver_entry);
    recbtnentry.btn = &recbutton;
    recbtnentry.next = NULL;
    addButtionCallback(&recbtnentry);
    drawTestItem(&recEntry);
    mAudio_receiver_entry(NULL);
    pthread_exit(NULL);
    return NULL;
}
