
enum JLINK_TESTITEM_ID{
	JILNK_ITEM_KEYS=1,						//1
    JLINK_ITEM_JOGBALL,						//2
    JILNK_ITEM_OFN,							//3
    JILNK_ITEM_TOUCH,						//4
    JILNK_ITEM_TOUCH_AUTO,					//5
    JILNK_ITEM_LCD,							//6
    JILNK_ITEM_LCM,							//7
    JILNK_ITEM_FLASH,						//8
    JILNK_ITEM_EMMC,						//9
    JILNK_ITEM_MEMCARD,						//10
    JILNK_ITEM_SIMCARD,						//11
	JILNK_ITEM_SIM,							//12
    JILNK_ITEM_SIGNALTEST,					//13
    JILNK_ITEM_VIBRATOR,					//14
    JILNK_ITEM_VIBRATOR_PHONE,				//15
    JILNK_ITEM_LED,							//16
    JILNK_ITEM_RTC,							//17
    JILNK_ITEM_LOOPBACK_PHONEMICSPK,		//18
    JILNK_ITEM_RECEIVER,					//19
    JILNK_ITEM_LOOPBACK,					//20
    JILNK_ITEM_ACOUSTICLOOPBACK,			//21
    JILNK_ITEM_LOOPBACK1,					//22
    JILNK_ITEM_LOOPBACK2,					//23
    JILNK_ITEM_LOOPBACK3,					//24
    JILNK_ITEM_WAVEPLAYBACK,				//25
    JILNK_ITEM_MICBIAS,						//26
    JILNK_ITEM_RECEIVER_PHONE,				//27
    JILNK_ITEM_HEADSET_PHONE,				//28
    JILNK_ITEM_LOOPBACK_PHONEMICSPK_PHONE,	//29
    JILNK_ITEM_HEADSET,						//30
    JILNK_ITEM_SPK_OC,						//31
    JILNK_ITEM_OTG,							//32
    JILNK_ITEM_USB,							//33
    JILNK_ITEM_GSENSOR,						//34
    JILNK_ITEM_GS_CALI,						//35
    JILNK_ITEM_MSENSOR,						//36
    JILNK_ITEM_ALSPS,						//37
    JILNK_ITEM_BAROMETER,					//38
    JILNK_ITEM_GYROSCOPE,					//39
    JILNK_ITEM_GYROSCOPE_CALI,				//40
    JILNK_ITEM_MAIN_CAMERA,					//41
    JILNK_ITEM_MAIN2_CAMERA,				//42
    JILNK_ITEM_SUB_CAMERA,					//43
    JILNK_ITEM_STROBE,						//44
    JILNK_ITEM_GPS,							//45
    JILNK_ITEM_NFC,							//46
    JILNK_ITEM_FM,							//47
    JILNK_ITEM_FMTX,						//48
    JILNK_ITEM_BT,							//49
    JILNK_ITEM_WIFI,						//50
    JILNK_ITEM_MATV_AUTOSCAN,				//51
    JILNK_ITEM_MATV_NORMAL,					//52
    JILNK_ITEM_CHARGER,						//53
    JILNK_ITEM_IDLE,						//54
    JILNK_ITEM_CFT,							//55
    JILNK_ITEM_MEMORY,						//56
    JILNK_ITEM_CMMB,						//57
    JILNK_ITEM_EMI,							//58
    JILNK_ITEM_HDMI,						//59
    JILNK_ITEM_RF_TEST,						//60
    JILNK_ITEM_HALL,                        //61
    JILNK_ITEM_DC,                        	//62
    JLINK_ITEM_MAX	
};




int getItemResult(int id);
char* getItemName(int id);
int initProinfoData();
void setProinfoItemResult(int id,int state);