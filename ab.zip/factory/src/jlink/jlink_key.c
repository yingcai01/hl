
#include "jlinkui.h"
#include <stdlib.h>
#include <linux/input.h>
#include "ftm.h"
#define	KEYPAD_NAME "/dev/mtk-kpd"
unsigned char mask[KEY_CNT/8 + 1];
static int kpd_fd = 0;
static int kpd_open()
{
	kpd_fd = -1;
    if(kpd_fd < 0)
	{
		LOGD(TAG "ftm open kpd device!\n");
		kpd_fd = open(KEYPAD_NAME, O_RDONLY);
	}
	
	if(kpd_fd < 0)
	{
		LOGD(TAG "Couldn't open kpd device!\n");
		return -EINVAL;
	}

	return 0;	
}


static int key[KEY_CNT]={0};
static int keynum = 0;
static int untestnum = 0;
extern TestEntry keyentry;

void setKeyvalue(int keycode){
	switch(keycode){
		case KEY_VOLUMEDOWN:
			strcat(keyentry.value.name, "VoDown");
			break;
		case KEY_VOLUMEUP:
			strcat(keyentry.value.name, "VoUp");
			break;
		case KEY_POWER:
			strcat(keyentry.value.name, "Power");
			break;
		case KEY_HOME:
			strcat(keyentry.value.name, "Home");
			break;
		case KEY_END:
			strcat(keyentry.value.name, "EndCal");
			break;
		case KEY_SEND:
			strcat(keyentry.value.name, "Call");
			break;
		case KEY_BACK:
			strcat(keyentry.value.name, "Back");
			break;
		case KEY_RESTART:
			strcat(keyentry.value.name, "Mrdump");
			break;
		default:
			//LOGD(TAG " kpd = %d", keycode);
			break;
	}
	strcat(keyentry.value.name, " ");
}

#define test_bit(bit) ((mask[(bit)/8])&(1<<((bit)%8)))
void jlink_get_testkeys(void)
{
	char buffer[80];
	char name[64];
	int version;
	int fd, key_code = 0, m;
	char hhome[50];
	char *homekeytest = ftm_get_prop("FTM.HomeKeyTest");
	char buf[256] = {0,};
	memset(key,0,sizeof(key));
	keynum = 0;
	untestnum = 0;
	for(m = 0; m <32; m++){
		sprintf(name, "/dev/input/event%d", m);
		if((fd = open(name, O_RDONLY, 0))>=0){
			//LOGD(TAG " kpd kpd_fd = %d", fd);
			ioctl(fd,EVIOCGNAME(sizeof(buf)), buf);
			if(memcmp(buf, "mtk-kpd", 7)==0){
				//LOGD(TAG " kpd name = %s", buf);
				ioctl(fd,EVIOCGBIT(EV_KEY,sizeof(mask)), mask);
				for(key_code=0; key_code<KEY_CNT; key_code++){
					if(test_bit(key_code)){
						if(key_code==KEY_HOME && NULL == homekeytest)
						{
							continue;
						}
						//屏蔽重启键
						if (key_code== KEY_RESTART){
							continue;
						}
						key[keynum++] = key_code;
						setKeyvalue(key_code);
						untestnum++;
					}
				}
				close(fd);
				break;
			}else{
				close(fd);
			}
		}else{
			LOGD(TAG "open device failed");
		}
	}
}


static int key_thread_run = 1;
void drawKeyValue(int keycode){
	int i = 0;
	strcpy(keyentry.value.name,"");
	for(;i<keynum;i++){
		//LOGD(TAG":keycode=%d,key[i]=%d",keycode,key[i]);
		if (keycode==key[i])
		{
			key[i]=-1;
			untestnum--;
		}
		if(key[i]!=-1) {
			setKeyvalue(key[i]);
		}

	}
	if(untestnum==0){
		key_thread_run = 0;
		keyentry.value.color = GREENCOLOR;
		strcpy(keyentry.value.name,"OK!");
		keyentry.state = TEST_PASS;
		setProinfoItemResult(keyentry.id,keyentry.state);

	}
	//LOGD(TAG":value=%s,length=%d,keynum=%d",keyentry.value.name,sizeof(keyentry.value.name),keynum);
	drawItemValueBehind(&keyentry);

}

extern void ui_clear_key_queue();
void do_key_test(){
	int key;
	struct timespec ntime;
	ntime.tv_sec= time(NULL)+20;
	ntime.tv_nsec=0;
	ui_clear_key_queue();
	while(key_thread_run){
		//key = ui_wait_phisical_key();// ui_wait_key
		key=jlink_wait_key(&ntime);
		if(key==114 || key == 115 || key == 116){
			drawKeyValue(key);
		}
		
	}

}



void* jlink_key_start(void*para)
{
	int i, err, num = 0;
	int x = 0, y = CHAR_HEIGHT;
	int fd;
	char *mrdump_rst_cmd = "1 0 0";
	char *mrdump_irq_cmd = "1 1 0";
	bool exit;
	static char buf[128];

	err = 0;
	err = kpd_open();
	if(err != 0){
		LOGD(TAG "Couldn't open kpd device!\n");
	}

	/* Disable function in /proc/mrdump_rst */
	fd = open("/proc/mrdump_rst", O_WRONLY);
	if (fd < 0)
		LOGD(TAG "Couldn't open mrdump_rst. error=%d", errno);
	else {
		err = write(fd, mrdump_rst_cmd, strlen(mrdump_rst_cmd));
		if (err < 0)
			LOGD(TAG "Couldn't write mrdump_rst. error=%d", errno);

		err = write(fd, mrdump_irq_cmd, strlen(mrdump_irq_cmd));
		if (err < 0)
			LOGD(TAG "Couldn't write mrdump_rst. error=%d", errno);
	}
	int row = 0;
	if (para!=NULL)
	{
		row = *(int*)para;
	}
	//do_build_uistruct(row);
	key_thread_run = 1;
	drawTestItem(&keyentry);
	jlink_get_testkeys();
	drawItemValueBehind(&keyentry);
	do_key_test();
	/*
	if(keyentry!=NULL){
		free(keyentry);
		keyentry = NULL;
	}*/
	if (fd >= 0)
		close(fd);
	pthread_exit(NULL);
	return NULL;
}

void jlink_key_stop(){
	key_thread_run = 0;
}