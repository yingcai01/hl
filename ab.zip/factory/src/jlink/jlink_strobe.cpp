extern "C"{
#include "jlinkui.h"
}
#include "../test/flash_drv.h"

struct camera
{
    char  info[1024];
    int isExit;
    int cmd;
    int isTestDone;
    text_t    title;
    text_t    text;
    struct ftm_module *mod;
    struct textview tv;
    struct itemview *iv;
};

extern TestEntry srobeEntry;
extern Button strobebutton;
ButtonEntry strobetnentry;

static void *strobe_test_thread(void *priv)
{
    int ret = 0;
    LOGD("strobe_test_thread %d\n",__LINE__);
    struct camera *stb = (struct camera *)priv;
    //FTM_CAMERA_DBG("strobe_test_thread %d\n",__LINE__);
    FlashSimpleDrv*  pStrobe;
    pStrobe = FlashSimpleDrv::getInstance();
    pStrobe->init(1);
    int times = 15;
    while(times--)
    {
        pStrobe->setPreOn();
        usleep(50000);
        ret =pStrobe->setOnOff(1);
        usleep(50000);
        pStrobe->setOnOff(0);
        usleep(100000);
    }
    usleep(100000);
    pStrobe->uninit();
    if (ret!=0){
        srobeEntry.value.color = REDCOLOR;
        srobeEntry.state = TEST_FAIL;
        strcpy(srobeEntry.value.name,uistr_info_test_fail );
    }else{
        srobeEntry.value.color = GREENCOLOR;
        srobeEntry.state = TEST_PASS;
        strcpy(srobeEntry.value.name,uistr_info_test_pass );
    }
    drawItemValueBehind(&srobeEntry);
    setProinfoItemResult(srobeEntry.id,srobeEntry.state);
    return NULL;
}


void* strobe_start(void *priv)
{
   LOGD("strobe_entry %d\n",__LINE__);
    int chosen;
    bool exit = false;
    struct camera *cam = (struct camera *)malloc(sizeof(struct camera));
    memset(cam,0,sizeof(struct camera));
    static int isTestDone = 0;
    strcpy(srobeEntry.value.name, uistr_info_testing);
    drawItemValueBehind(&srobeEntry);
    pthread_t strobeTestTh;
    pthread_create(&strobeTestTh, NULL, strobe_test_thread, cam);

    LOGD("strobe_entry %d\n",__LINE__);
    pthread_join(strobeTestTh, NULL);
    LOGD("strobe_entry %d\n",__LINE__);
    //strcpy(srobeEntry.value.name,uistr_info_testover);
    //drawItemValueBehind(&srobeEntry);
    DrawButtonBehindEntry(&strobebutton,&srobeEntry);
    if (cam!=NULL)
    {
    	free(cam);
    }
    return NULL;
}


void * jlink_strobe_start(void*para){

    drawTestItem(&srobeEntry);
    //start_backlight(NULL);
    initTestButton(&strobebutton,strobe_start);
   // DrawButtonBehindEntry(&strobebutton,&srobeEntry);
    strobetnentry.btn = &strobebutton;
    strobetnentry.next = NULL;
    addButtionCallback(&strobetnentry);
    strobe_start(NULL);
    return NULL;
}
