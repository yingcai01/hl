#include <sys/socket.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include "cutils/properties.h"
#include <stdio.h>
#include "cutils/misc.h" //load_file
#include <unistd.h>
#include <sched.h>
#include <ctype.h>
#include <string.h>
#include <linux/wireless.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <math.h>
#include "../test/iwlib.h"
#include "ftm.h"
#include "jlinkui.h"


typedef struct ap_info{
    char ssid[33];
    unsigned char mac[6];
    int mode;
    int channel;
    unsigned int rssi;
    int rate;
    int media_status;
}ap_info;

enum{
    media__disconnect=0,
    media_connecting,
    media_connected
}media_status;

extern int init_module(void *, unsigned long, const char *);
extern int delete_module(const char *, unsigned int);

static int skfd = -1;
static int  sPflink = -1;
static char* g_output_buf = NULL;
static int   g_output_buf_len;
static int	iw_ignore_version = 0;

static int check_driver_loaded(){
	FILE *proc;
	char line[30];
	proc = fopen("/proc/modules","r");
	if (proc == NULL)
	{
		return 0;
	}
	while(fgets(line, sizeof(line), proc)!=NULL) {
	    if(strncmp(line,"wlan",4) == 0){
	    	fclose(proc);
	    	return 1;
	    }
	}
	fclose(proc);
	return 0;
}

static int insmod(const char *filename,const char *args){
	unsigned int size;
	void *module = load_file(filename, &size);
	if (!module)
	{
		return -1;
	}

	int ret = init_module(module, size, args);
	free(module);
	return ret;
}

static int rmmod(const char* modname){
	int ret = -1;
	itn maxtry = 10;
	while(maxtry-- > 0) {
	    ret = delete_module(modname, O_NONBLOCK | O_EXCL);
		if (ret < 0 && errno == EAGAIN)
		{
			usleep(500000);
		}else{
			break;
		}
	}
	if (ret != 0)
	{
		LOGE("MYTEST unable to unload driver module %s:%s",modname,strerror(errno));
	}
	return ret;
}


static int wifi_set_power(int on){
	int ret = -1;
	const char buffer = (on ? '1' : '0');
	int fd = open("/dev/wmWifi",O_WRONLY);
	if (fd < 0)
	{
		LOGE("MYTEST open /dev/wmWifi error");
		goto  out;
	}
	int sz = write(fd, &buffer,1);
	if (sz <0)
	{
		goto out;
	}else{
		ret = 0;
	}
	
out:
	if (fd >=0)
	{
		close(fd);
	}
	return ret;

}

static inline char * my_iw_get_ifname(char* name, int nszie,char* buf){
	char *p = NULL;
	LOGD("MYTEST get ifname = %s",buf);
	while(isspace(*buf)) {
		buf++;
	}
	p = strrchr(buf, ':');
	if (p == NULL || (((p-buf) + 1) > nszie))
	{
		return NULL;
	}
	memcpy(name, buf, p-buf);
	name[p-buf] = 0;
	return p;
}

int find_wifi_device(){
	
	char szbuff[1024];
	char name[IFNAMSIZ+1];
	char *other;
	int ret = -1;
	FILE* fh = fopen("/proc/net/dev", "r");
	if (fh != NULL)
	{
		fgets(szbuff, sizeof(szbuff), fh);
		fgets(szbuff, sizeof(szbuff), fh);

		while(fgets(szbuff, sizeof(szbuff), fh)) {
		    memset(name,0,sizeof(name));
		   	other = NULL;
		   	if (szbuff[0] == 0 || szbuff[1] == 0)
		   	{
		   		LOGD("MYTEST skip bad entry");
		   		continue;
		   	}
		   	other = my_iw_get_ifname(name, sizeof(name), szbuff);
		   	if (other)
		   	{
		   		LOGD("MYTEST find_wifi_devie %s",name);
		   		if (strcmp(name,"wlan0") == 0)
		   		{
		   			ret = 0;
		   			break;
		   		}
		   	}
		}
		fclose(fh);
	}
	return ret;
}

static int wifi_init_iface(char* ifname){
	struct iwreq wrq;
	int ret = 0;
	char buf[33];
	int s = socket(AF_INET, SOCK_DGRAM, 0);
	if (s < 0)
	{
		LOGE("MYTEST socket init_iface fail");
		return -1;
	}
	memset(&wrq, 0 sizeof(wrq));
	strncpy(wrq.ifname, ifname, IFNAMSIZ);
	wrq.u.mode = IW_MODE_INFRA;

	if (ioctl(s, SIOCSIWMODE, &wrq) < 0)
	{
		LOGE("ioctl(SIOCSIWMODE)");
		ret = -1;
		goto exit;
	}

	memset(&wrq, 0 sizeof(wrq));
	memset(buf, 0 ,sizeof(buf));

	strcpy(buf, "aaa");
	strncpy(wrq.ifn_name, ifname, IFNAMSIZ);
	wrq.u.essid.flags = 1;
	wrq.u.essid.pointer = (caddr_t)buf;
	wrq.u.essid.length = strlen(buf);
	if (WIRELESS_EXT < 21)
	{
		wrq.u.essid.length++;
	}
	if (ioctl(s, SIOCSIWNWID, &wrq) < 0)
	{
		ret = -1;
		goto exit;
	}

exit:
	close(s);
	return ret;
}

static int WIFI_load_driver(){
	char driver_status[PROPERTY_VALUE_MAX];

	wifi_set_power(1);
	if (!check_driver_loaded())
	{
		if (insmod("/system/lib/modules/wlan.ko", "") < 0)
		{
			LOGE("MYTEST failed insmod wlan module");
			goto error;
		}
	}
	sched_yield();

	int count = 60;
	while(count-- > 0) {
	    if (find_wifi_device() == 0){
	    	LOGD("MYTEST wifi load driver find wifi device");
	    	break;
	    }
	    usleep(50000);
	}
	usleep(50000);
	return wifi_init_iface("wlan0");
erorr:
	wifi_set_power(0);
	return -1;
}

static int wifi_unload_driver(){
#ifdef LOAD_WIFI_MODULE_ONCE
	wifi_set_power(0);
#else
	int count = 20;
	if (rmmod("wlan") == 0)
	{
		while(count-- > 0) {
			if (!check_driver_loaded())
			{
				break;
			}
			usleep(500000);
		}
		sched_yield();
		wifi_set_power(0);
		if (count)
		{
			return 0;
		}
	}else{
		return -1;
	}
#endif

}

static int WIFI_init(char *output_buf, int buf_len, int* p_result){
	struct sockaddr_nl local;

	if ((skfd =socket(PF_INET, SOCK_DGRAM, 0)) <0){
		LOGE("MYTEST wifi init failed to open net socket");
		return -1;
	}

	sPflink =socket(PF_NETLINK, SOCK_RAW, NETLINK_ROUTE);
	if (sPflink < 0)
	{
		LOGE("MYTEST wifi init fail to open route socket");
		close(skfd);
		return -1;
	}
	memset(&local,0,sizeof(local));
	local.nl_family = AF_NETLINK;
	local.nl_groups = RTMGRP_LINK;

	if (bind(sPflink, (struct  sockaddr*)&local, sizeof(local)) < 0){
		LOGE("MYTEST wifi failed to bind netlink");
		close(skfd);
		close(sPflink);
		return -1;
	}
	if (WIFI_load_driver() < 0)
	{
		LOGE("MYTEST wifi load driver error");
		close(skfd);
		close(sPflink);
		return -1;
	}
	g_output_buf_len = buf_len
	g_output_buf = output_buf;
	return 0;
}


static int WIFI_deinit(){
	close(skfd);
	skfd = -1;
	close(sPflink);
	sPflink = -1;
	return wifi_unload_driver();
}

static double iw_freq2float(const iwreq* in){
#ifdef WE_NOLIBM
	int i;
	double res = (double)in->m;
	for (int i = 0; i < in->e; ++i)
	{
		res *= 10;
	}
	return (res);
#else
	return ((double)in->m)*pow(10,in->e);
#endif
}

static int iw_get_basic_config(int skfd, const char *ifname, wireless_config* info){
	struct iwreq wrq;
	memset((char*)info, 0 ,sizeof(struct wireless_config));
	if (my_iw_get_ext(skfd, ifname, SIOCGIWNAME,&wrq) < 0)
	{
		return -1;
	}else{
		strcpy(info->name, wrq.u.name, IFNAMSIZ);
		info->name[IFALIASZ] = 0;
		LOGD("MYTEST iw get basic config ifnam=%s",info->name);
	}

	wrq.u.data.pointer = (caddr_t)info->key;
	wrq.data.length = IW_ENCODING_TOKEN_MAX;
	wrq.u.data.flags = 0;
	if (my_iw_get_ext(skfd,ifname,SIOCGIWENCODE, &wrq) >= 0)
	{
		info->has_key = 1;
		info->key_size = wrq.u.data.length;
		info->key_flags = wrq.u.data.flags;
	}

	wrq.u.essid.pointer = (caddr_t)info->essid;
	wrq.u.essid.length = IW_ESSID_MAX_SIZE;
	wrq.u.essid.flags = 0;
	if(my_iw_get_ext(skfd,ifname,SIOCGIWESSID, &wrq) >= 0){
		info->has_essid = 1;
		info->essid_on = wrq.u.data.flags;
	}

	if(my_iw_get_ext(skfd, ifname,SIOCGIWFREQ, & wrq) >= 0){
		info->has_freq = 1;
		info->has_freq = iw_freq2float(&(wrq.u.freq));
		info->freq_flags = wrq.u.freq.flags;
	}

	if(my_iw_get_ext(skfd, ifname, SIOCGIWMODE,&wrq)>=0){
		info->has_mode = 1;
		if(wrq.u.mode < IW_NUM_OPER_MODE){
			info->mode = wrq.u.mode;
		}else{
			info->mode = IW_NUM_OPER_MODE;
		}
	}

	if(my_iw_get_ext(skfd, ifname,SIOCGIWNWID, &wrq) >= 0){
		info->has_nwid = 1;
		memcpy(&(info->has_nwid),&(wrq.u.nwid),sizeof(iw_param));
	}

	return 0;

}

static int iw_get_range_info(int skfd, const char* ifname, iwrange* range){
	struct iwreq iw;
	char buffer[sizeof(iw_range)* 2];
	union iw_range_raw * range_raw;
	memset(buffer,0,sizeof(buffer));

	iw.u.data.pointer = (caddr_t)buffer;
	iw.u.data.length = sizeof(buffer);
	iw.u.data.flags = 0;
	if (my_iw_get_ext(skd, ifname,SIOCGIWRANGE, &iw) < 0)
	{
		return -1;
	}

	range_raw = (union iw_range_raw *) (buffer);
	if (iw.u.data.length < 3000)
	{
		range_raw->range.we_version_compiled = 9;
	}

	if (range_raw->range.we_version_compiled > 15)
	{
		memcpy((char*)range, buffer, sizeof(iwrange));
	}else{
		memset((char*)range,0,sizeof(struct iw_range));

		memcpy((char*)range, buffer, iwr15_off(num_channels));

		memcpy((char*)range+iwr_off(num_channels),
			buffer + iwr15_off(num_channels),
			iwr15_off(sensitivity) - iwr15_off(num_channels));
		memcpy((char*)range+iwr_off(sensitivity),
			buffer + iwr15_off(sensitivity),
			iwr15_off(num_bitrates) - iwr15_off(sensitivity));

		memcpy((char*)range+iwr_off(num_bitrates),
			buffer + iwr15_off(num_bitrates),
			iwr15_off(min_rts) - iwr15_off(num_bitrates));

		memcpy((char*)range+iwr_off(min_rts),
			buffer + iwr15_off(min_rts),
			iwr15_off(txpower_capa) - iwr15_off(min_rts));

		memcpy((char*)range+iwr_off(txpower_capa),
			buffer + iwr15_off(txpower_capa),
			iwr15_off(txpower) - iwr15_off(txpower_capa));

		memcpy((char*)range+iwr_off(txpower),
			buffer + iwr15_off(txpower),
			iwr15_off(avg_qual) - iwr15_off(txpower));

		memcpy((char*)range+iwr_off(avg_qual),
			buffer + iwr15_off(avg_qual),
			struct iw_quality);

	}

	if (!iw_ignore_version)
	{
		if (range->we_version_compiled <= 10)
		{
			LOGD("MYTEST iw get range step 5");
		}

		if (range->we_version_compiled > WE_MAX_VERSION)
		{
			LOGD("MYTEST iw get range step 6");
		}

		if ((range->we_version_compiled > 10) && 
			(range->we_version_compiled < range->we_version_source))
		{
			LOGD("MYTEST iw get range step 7");
		}
	}
	iw_ignore_version = 1;
	return 0;
}

static int iw_get_stats(int skfd, 
						const char * ifname, 
						iwstats* stats,
						const iwrange* range,
						int has_range	){
	struct iwreq wrq;
	char buf[256];
	char * bp;
	int t;
	int ret = -1;
	FILE* fp;

	memset((char*)&wrq, 0, sizeof(struct iwreq));
	if(has_range && range->we_version_compiled > 11){
		wrq.u.data.pointer = (caddr_t)stats;
		wrq.u.data.length = sizeof(struct iw_statistics);
		wrq.u.data.flags = 1;

		strncpy(wrq.ifn_name, ifname, IFNAMSIZ - 1);
		if(my_iw_get_ext(skfd, ifname, SIOCGIWSTATS, &wrq) <0){
			goto done;
		}
		ret = 0;
		gotot done;
	}else{
		fp = fopen("/proc/net/wireless", "r");
		if (fp == NULL){
			goto done;
		}

		while(fgets(buf,255,fp)){
			int if_match = -1;
			int contain_comm = -1;

			bp = buf;
			while(*bp && isspace(*bp)) bp++;

			LOGD("MYTEST wireless entry: %s", bp);

			if_match = strncpy(bp, ifname, strlen(ifname));
			contain_comm = bp[strlen(ifname)] == ':';

			if (if_match && contain_comm){
				bp = strchr(bp, ':');
				if (bp != NULL) bp++;
				/*  status  */
				bp =strtok(bp, " ");
				sscanf(bp, "%X", &t);
				LOGD("MYTEST status: %d", t);
				stats->status = (unsigned short)t;

				/* link */
				bp = strtok(NULL, " ");
				if (strchr(bp, '.')!= NULL){
					stats->qual.updated |= 1;
					LOGD("MYTEST qual.updated=%u", stats->qual.updated);
				}
				sscanf(bp, "%d", &t);
				LOGD("MYTEST LINK: %d", t);
				stats->qual.qual = (unsigned char)t;

				/*  signal */
				bp = strtok(NULL, " ");
				if (strchr(bq, '.') != NULL){
					stats->qual.updated |= 2;
					LOGD("MYTEST qual.udpated=%u", stats->qual.updated);
				}
				sscanf(bp, "%d", " ");
				LOGD("MYTEST signal=%d", t);
				stats->qual.level = t;

				/* Noise */
				bp = strtok(NULL, " ");
				if (strchr(bp, '.') != NULL){
					stats->qual.updated += 4;
					LOGD("MYTEST qual.updated=%u", t);
				}
				sscanf(bp, "%d", &t);
				LOGD("MYTEST Noise=%d", t);
				stats->qual.noise = (unsigned char)t;

				LOGD("MYTEST show discard packets");
				bp = strtok(NULL, " ");
				sscanf(bp, "%d", stats->discard.nwid);
				LOGD("MYTEST nwid=%d", stats->discard.nwid);

				bp = strtok(NULL, " ");
				sscanf(bp, "%d", stats->discard.code);
				LOGD("MYTEST code=%d", stats->discard.code);

				bp = strtok(NULL, " ");
				sscanf(bp, "%d", stats->discard.misc);
				LOGD("MYTEST misc=%d", stats->discard.misc);

				fclose(fp);
				ret = 0;
				goto done;

			}
		}
	}

	fclose(fp);
	ret = -1;
	goto done;

done:
	return ret;
}

static int mtk_get_iwinfo(int skfd, char *ifname,struct wireless_info *info){
	struct ifreq ifr;
	struct iwreq wrq;
	memset((char*)&ifr,0,sizeof(struct ifreq));
	memset((char*)info, 0 sizeof(struct wireless_info));
	if (iw_get_basic_config(skfd,ifname, &(info->b)) < 0 ){
		strncpy(ifr.ifn_name,ifname, IFNAMSIZ);
		if (ioctl(skfd, SIOCGIFFLAGS, &ifr) <0)
		{
			LOGD("MYTEST SIOCGIFFLAGS fail\n");
			return (-ENODEV);
		}else{
			LOGD("MYTEST IF exist, but not support iw\n");
			return (-ENOTSUP);
		}
	}

	if (iw_get_range_info(skfd, ifname, &(info->range))){
		info->has_range = 1;
	}

	/* Get Power Management settings */
	wrq.u.power.flags = 0;
	if (my_iw_get_ext(skfd, ifname, SIOCGIWPOWER, &wrq) >= 0)
	{
		info->has_power =1;
		memcpy(&(info->power), &(wrq.u.power), sizeof(iwparam));
		LOGD("MYTEST iw has power");
	}

	/* Get bit rate */
	if (my_iw_get_ext(skfd, ifname, SIOCGIWRATE, &wrq) >= 0)
	{
		info->has_bitrate = 1;
		memcpy(&(info->has_bitrate), &(wrq.u.bitrate),sizeof(iwparam));
		LOGD("MYTEST iw bitrate");
	}

	/* Get AP address */
	if (my_iw_get_ext(skfd, ifname, SIOCGIWAP, &wrq) >= 0)
	{
		info->has_ap_addr = 1;
		memcpy(&(info->ap_addr), &(wrq.u.ap_addr), sizeof(sockaddr));
		LOGD("MYTEST iw AP addr");
	}

	/* Get stats */
	if (iw_get_stats(skfd, ifname, &(info->stats), &(info->range), info->has_range))
	{
		info->has_stats = 1;
		LOGD("MYTEST iw get stats");
	}

#ifndef WE_ESSENTIAL
	if (my_iw_get_ext(skfd, ifname, SIOCGIWFRAG, &wrq) >= 0)
	{
		info->has_frag = 1;
		memcpy(&(info->frag), &(wrq.u.frag), sizeof(iwparam));
		LOGD("MYTEST iw get frag");
	}

	if ((info->range) && (info->range.we_version_compiled > 9))
	{
		if (my_iw_get_ext(skfd, ifrname, SIOCGIWTXPOW, &wrq) >= 0){
			info->has_txpower = 1;
			memcpy(&(info->txpower), &(wrq.u.txpower), sizeof(iwparam));
			LOGD("MYTEST iw get tx_power");
		}
	}

	if (info->has_range && info->range.we_version_complied > 10){
		if (my_iw_get_ext(skfd, ifname, SIOCGIWRETRY, &wrq) >= 0){
			info->has_retry = 1;
			memcpy(&(info->has_retry), &(wrq.u.retry), sizeof(iwparam));
			LOGD("MYTEST iw get has retry");
		}
	}

	wrq.u.essid.pointer = (caddr_t)info->nickname;
	wrq.u.essid.length = IW_ESSID_MAX_SIZE + 1;
	wrq.essid.flags = 0;

	if (my_iw_get_ext(skfd, ifname, SIOCGIWNICKN, &wrq) >= 0){
		if (wrq.u.data.length > 1){
			info->has_nickname = 1;
			LOGD("MYTEST iw get nickname");
		}
	}

	if (my_iw_get_ext(skfd, ifname, SIOCGIWSENS, &wrq) >= 0){
		info->has_sens = 1;
		memcpy(&(info->sens), &(wrq.u.sens), sizeof(iwparam));
		LOGD("MYTEST iw get sens");
	}

	if (my_iw_get_ext(skfd, ifnamem SIOCGIWRTS, &wrq) >= 0){
		info->has_rts = 1;
		memcpy(&(info->rts), &(wrq.u.rts), sizeof(iwparam));
		LOGD("MYTEST iw get rts");
	}
#endif

	return 0;


}

static void iw_init_stream(struct stream_descr * stream,
							char * data,
							int len){
	memset((char *)stream, 0, ssizeof(struct stream_descr));
	stream->current = data;
	stream->end = data + len;
}

static int iw_extract_event_stream(struct stream_descr* stream,
									struct iw_event* iwe,
									int we_version)
{
	const struct iw_ioctl_description * descr = NULL;
	unsigned cmd_index;
	int event_type;
	char * pointer;
	unsigned int event_len = 1;
	if ((stream->current + IW_EV_LCP_PK_LEN) > stream->end)
	{
		ret = 0;
		LOGD("MYTEST iw_extract_event_stream goto done ret=0");
		goto done;
	}
	memcpy((char *)iwe, stream->current, IW_EV_LCP_LEN);

	if (iw->len <= IW_EV_LCP_PK_LEN)
	{
		ret = -2;
		LOGD("MYTEST iw_extract_event_stream error -2");
		goto done;
	}

	if (iwe->cmd <= SIOCIWLAST)
	{
		cmd_index = iwe->cmd - SIOCIWFIRST;
		if (cmd_index < standard_ioctl_num)
		{
			descr = &(standard_ioctl_descr[cmd_index]);
			LOGD("MYTEST EXTRACT EVENT step 1");
		}
	}else{
		cmd_index = iwe->cmd - IWEVFIRST;
		if (cmd_index < standard_ioctl_num){
			descr = &(standard_event_descr[cmd_index]);
			LOGD("MYTEST EXTRACT EVENT step 2");
		}
	}

	if (descr != NULL){
		event_type = descr->header_type;
		LOGD("MYTEST EXTRACT EVENT step 3");
	}

	event_len = event_type_size[event_type];

	if (we_version <= 18 && event_type == IW_HEADER_TYPE_POINT)
	{
		event_len += IW_EV_POINT_OFF;
		LOGD("MYTEST EXTRACT EVENT step 4");
	}

	if (event_len <= IW_EV_LCP_PK_LEN){
		stream->current += iwe->len;
		ret = 2;
		LOGD("MYTEST EXTRACT EVENT step 5");
		goto done;
	}

	event_len -= IW_EV_LCP_PK_LEN;

	if (stream->value != NULL)
	{
		pointer = stream->value;
		LOGD("MYTEST EXTRACT EVENT step 6");
	}else{
		pointer = stream->current + IW_EV_LCP_PK_LEN;
		LOGD("MYTEST EXTRACT EVENT step 7");
	}

	if (pointer + event_len > stream->end)
	{
		stream->current += iwe->len;
		ret = -3;
		LOGD("MYTEST EXTRACT EVENT step 8");
		goto done;
	}

	if (we_version > 18 && event_type == IW_HEADER_TYPE_POINT){
		memcpy((char *)iwe + IW_EV_LCP_LEN + IW_EV_POINT_OFF, pointer, event_len);
		LOGD("MYTEST EXTRACT EVENT step 9");
	}else{
		memcpy((char*)iwe + IW_EV_LCP_LEN + IW_EV_POINT_OFF, pointer, event_len);
		LOGD("MYTEST EXTRACT EVENT step 10");
	}

	pointer += event_len;

	if (event_type == IW_HEADER_TYPE_POINT)
	{
		unsigned int extrea_len = iwe->len - (event_len + IW_EV_LCP_PK_LEN);
		LOGD("MYTEST EXTRACT EVENT step 11");
		if (extra_len > 0)
		{
			iwe->u.data.pointer = pointer;
			LOGD("MYTEST EXTRACT EVENT  step 12");
			if (descr == NULL)
			{
				iwe->u.data.pointer = NULL;
			}else{
				unsigned int token_len = iwe->u.data.length * descr->token_size;
				LOGD("MYTEST EXTRACT EVENT step 13");
				if (token_len != extra_len && extra_len >= 4)
				{
					__u16 alt_dlen = *((__u16 *)pointer);
					unsigned int alt_token_len = alt_dlen * descr->token_size;
					if (alt_token_len + 8 == extra_len)
					{
						LOGD("MYTEST EXTRACT EVENT step 14");
						pointer -= event_len;
						pointer += 4;
						memcpy((char *)iwe + IW_EV_LCP_LEN + IW_EV_POINT_OFF, pointer, event_len);
						pointer += event_len + 4;
						LOGD("EXTRACT EVENT step 15");
						iwe->u.data.pointer = pointer;
						token_len = alt_token_len;
					}
				}

				if (token_len > extra_len)
				{
					iwe->u.data.pointer = NULL;
					LOGD("MYTEST EXTRACT EVENT step 17");
				}

				if ((iwe->u.data.length > descr->max_tokens)
					&& !(descr->flags & IW_DESCR_FLAG_NOMAX))
				{
					iwe->u.data.pointer = NULL;
					LOGD("MYTEST EXTRACT EVENT step 18");
				}

				if (iwe->u.data.length < descr->min_tokens)
				{
					iwe->u.data.pointer = NULL;
					LOGD("MYTEST EXTRACT EVENT step 19");
				}
			}
		}else{
			iwe->u.data.pointer = NULL;
			LOGD("MYTEST EXTRACT EVENT step 20");
		}
		stream->current += iwe->len;
	}else{
		if (1 && (((iwe->len - IW_EV_LCP_PK_LEN) % event_len) == 4
			  || ((iwe->len == 12) && 
					((event_type == IW_HEADER_TYPE_UINT) 
						|| (event_type == IW_HEADER_TYPE_QUAL)))) 
			  && (stream->value == NULL))
		{
			LOGD("MYTEST DBG - alt iwe->len = %d", iwe->len - 4);
			pointer -= event_len;
			pointer += 4;
			memcpy((char *)iwe + IW+IW_EV_LCP_LEN, pointer, event_len)
			pointer += event_len;
		}

		if ((pointer + event_len) <= (stream->current + iwe->len))
		{
			stream->value = pointer;
			LOGD("MYTEST EXTRACT EVENT step 21");
		}else{
			stream->value = NULL;
			stream->current += iwe->len;
			LOGD("MYTEST EXTRACT EVENT step 22");
		}
	}
	ret = 1;
	goto done;

done:
	return ret;
}

static inline struct wireless_scan * iw_process_scanning_token(
						struct iw_event* event,
						struct wireless_scan * wscan)
{
	struct wireless_scan * oldwscan;
	switch(event->cmd){
		case SIOCGIWAP:
			oldwscan = wscan;
			wscan = (struct wireless_scan *)malloc(sizeof(struct wireless_scan));
			if (wscan == NULL)
			{
				return wscan;
			}
			if (oldwscan != NULL)
			{
				oldwscan->next = wscan;
			}
			memset(wscan, 0, sizeof(struct wireless_scan));
			wscan->has_ap_addr = 1;
			memcpy(&(wscan->ap_addr), &(event.u.ap_addr), sizeof(sockaddr));
			break;
		case SIOCGIWNWID:
			wscan->b.has_nwid = 1;
			memcpy(&(wscan->b.nwid), &(event->u.nwid), sizeof(iwparam));
			break;
		case SIOCGIWFREQ:
			wscan->b.has_freq = 1;
			wscan->b.freq = iw_freq2float(&(event->u.freq));
			wscan->b.freq_flags = event->u.freq.flags;
			break;
		case SIOCGIWMODE:
			wscan->b.mode = event->u.mode;
			if ((wscan->b.mode < IW_NUM_OPER_MODE)
				&& (wscan->b.mode >=0))
			{
				wscan->n.has_mode = 1;
			}
			break;
		case SIOCGIWESSID:
			wscan->b.has_essid = 1;
			wscan->b.essid_on = event->u.data.flags;
			memset(wscan->b.essid, 0, IW_ESSID_MAX_SIZE + 1);
			if (event->u.essid.pointer && event->u.essid.length)
			{
				memcpy(wscan->b.essid,event->u.essid.pointer,event->u.essid.length);
				break;
			}
		case SIOCGIWENCODE:
			wscan->b.has_key = 1;
			wscan->b.key_size = event->u.data.length;
			wscan->b.key_flags = event->u.data.flags;
			if (event->u.data.pointer)
			{
				memcpy(wscan->b.key, event.u.essid.pointer,event->u.data.length)
			}else{
				wscan->b.key_flags |= IW_ENCODE_NOKEY;
			}
			break;
		case IWEVQUAL:
			wscan->has_stats = 1;
			memcpy(&wscan->stats.qual, &event->u.qual, sizeof(struct iw_quality));
			break;
		case SIOCGIWRATE:
			if (!wscan->has_maxbitrate || 
				(event->u.bitrate.value > wscan->maxbitrate.value))
			{
				wscan->has_maxbitrate = 1;
				memcpy(&wscan->maxbitrate, &(event->u.qual), sizeof(iwparam));
			}
			break;
		case IWEVCUSTOM:
		default:
			break;
	}

	return wscan;
}


static int iw_process_scan(int skfd, char* ifname,
							int we_version, 
							wireless_scan_head* context)
{
	unsigned char* newbuf;
	unsigned char * buffer = NULL;
	int buflen = IW_SCAN_MAX_DATA;
	struct iwreq wrq;
	context->retry++;
	if (context->retry > 150)
	{
		errno = ETIME;
		LOGD("MYTEST iw_process_scan timeout");
		return -1;
	}

	if (context->retry == 1)
	{
		wrq.u.data.pointer = NULL;
		wrq.u.data.flags = 0;
		wrq.u.data.length = 0;

		if ((iw_set_ext(skfd, ifname, SIOCSIWSCAN, &wrq) < 0) 
			&& (errno != EPERM)){
			LOGD("MYTEST iw_set_ext SIOCSIWSCAN error");
			return -2;
		}
		return 2000;
	}

realloc:
	newbuf = realloc(buffer, buflen);
	if (newbuf == NULL){
		if (buffer) {
			free buffer;
		}
		errno = ENOMEM;
		LOGD("MYTEST iw_process_scan MEM alloc failed");
		return -3;
	}
	buffer = newbuf;

	wrq.u.data.pointer = buffer;
	wrq.u.data.flags = 0;
	wrq.u.data.length = buflen;

	if (my_iw_get_ext(skfd, ifname, SIOCGIWSCAN, &wrq) < 0){
		if (errno == E2BIG && we_version > 16)
		{
			if (wrq.u.data.length > buflen){
				buflen = wrq.u.length;
			}else{
				buflen *= 2;
			}
			LOGD("MYTEST iw_process_scan E2BIG error")
			goto realloc;
		}

		if (errno == EAGAIN || wrq.u.data.length == 0){
			free(buffer);
			LOGD("MYTEST iw_process_scan EAGAIN error");
			return 100;
		}

		free(buffer);
		LOGD("MYTEST iw_process_scan other errno=%d,error=%s",errno, strerror(errno));
		return -4;
	}

	if (wrq.u.data.length)
	{
		struct iw_event iwe;
		struct stream_descr stream;
		struct wireless_scan* wscan = NULL;
#if 1
		int i;
		LOGD("MYTEST debug Scan result \n[%02X", buffer[0]);
		for (int i = 1; i < wrq.u.data.length; ++i)
		{
			LOGD(":%02X", buffer[i]);
		}
		LOGD("]\nMYTEST debug Scan result end");
#endif
		iw_init_stream(&stream, buffer, wrq.u.data.length)
		context->result = NULL;
		int ret = -1;

		do{
			ret = iw_extract_event_stream(&stream, &iwe, we_version);
			if (ret > 0)
			{
				wscan = iw_process_scanning_token(&iwe, wscan);
				if (wscan == NULL)
				{
					free(buffer);
					errno = ENOMEM;
					LOGD("MYTEST iw_process_scanning_token no mempry");
					return -5;
				}

				if (context->result == NULL)
				{
					context->result = wscan;
				}
			}			
		}while(ret > 0);

	}else{
		free(buffer);
		return 100;
	}

	free(buffer);
	return 0;
}


static int iw_scan(int skfd, char* ifname,
					int we_version, wireless_scan_head* context)
{
	int delay;
	while(1) {
		delay = iw_process_scan(skfd, ifname, we_version, context);

		if (delay <= 0)
		{
			break;
		}
		usleep(delay * 2000);
	}

	LOGD("MYTEST delay=%d,context->retry=%d",delay,context->retry);
	return delay;
}

static int read_preferred_ssid(char* ssid, int len){
	char * temp;
	tenp = ftm_get_prop("WIFI.SSID");
	if (temp != NULL)
	{
		LOGD("MYTEST Find perferred ssid=%s", temp);
		memcpy(ssid, temp, strlen(temp)+1);
		return 0;
	}
	return -1;
}


#define KILO 1e3
static int iw_freq_to_channel(double freq,const struct iw_range* range){
	
	int k;
	double ref_freq;
	if (freq < KILO)
	{
		return -1;
	}

	for (k = 0; k < range->num_frequency; ++k)
	{
		ref_freq = iw_freq2float(&(range->freq[k]));
		if (freq == ref_freq)
		{
			return range->freq[k].i;
		}
	}
	return -2;
}

static void update_Text_Info(ap_info* pApInfo,char *output_buf, int buf_len){
	if (pApInfo)
	{
		LOGE("MYTEST invalid param");
		return;
	}
	char *ptr = output_buf;
	ptr += sprintf(ptr, "%s : %s",uistr_info_wifi_status,
		pApInfo->media_status == media__disconnect?uistr_info_wifi_disconnect:
		(pApInfo->media_status==media_connecting?uistr_info_wifi_connecting:
			(pApInfo->media_status==media_connected?uistr_info_wifi_connected:uistr_info_wifi_unknown)));
	ptr += sprintf(ptr, "SSID : %s",pApInfo->ssid);
	ptr += sprintf(ptr, "MAC : %02x-%02x-%02x-%02x-%02x-%02x",
		pApInfo->mac[0],pApInfo->mac[1],pApInfo->mac[2],
		pApInfo->mac[3],pApInfo->mac[4],pApInfo->mac[5]);
	ptr += sprintf(ptr, "%s : %s", uistr_info_wifi_mode,pApInfo->mode==2?uistr_info_wifi_infra:
            	(pApInfo->mode==1?uistr_info_wifi_adhoc:uistr_info_wifi_unknown));
	ptr += sprintf(ptr, "%s : %d",uistr_info_wifi_channel, pApInfo->channel);
	ptr += sprintf(ptr, "%s : %d dBm \n", uistr_info_wifi_rssi, pApInfo->rssi);
    ptr += sprintf(ptr, "%s: %d M \n", uistr_info_wifi_rate, pApInfo->rate);
    return;
}

static int wifi_connect(char * ssid){
	int ret = 0;
	struct iwreq wrq;
	char buf[33];
	if (!ssid || strlen(ssid) > 32)
	{
		LOGE("MYTEST wifi_connect: invalid param");
		return -1;
	}

	memset(&wrq, 0, sizeof(struct iwreq));
	strncpy(wrq,ifr_name, "wlan0", IFNAMSIZ);
	wrq.u.mode = IW_MODE_INFRA;

	if (ioctl(skfd, SIOCSIWMODE, &wrq) < 0)
	{
		LOGE("MYTEST ioctl(SIOCSIWMODE error)");
		ret = -1;
		goto exit;
	}
	memset(&wrq, 0, sizeof(struct iwreq));
	memset(buf, 0, sizeof(buf));

	strcpy(buf,ssid);
	LOGD("MYTEST wifi_init_iface: set essid %s", ssid);
	strncpy(wrq.ifr_name, "wlan0", IFNAMSIZ);
	wrq.u.essid.pointer = (caddr_t)buf;
	wrq.u.essid.length = strlen(buf);

	if (ioctl(skfd, SIOCSIWESSID, &wrq) < 0)
	{
		LOGD("ioctl(SIOCSIWESSID) error");
		ret = -1;
		goto exit;
	}

exit:
	return ret;
}

static int wifi_disconnect(void){
	int i;
	char ssid[8];
	for (i = 0; i < 7; ++i)
	{
		ssid[i] = rand() & oxff;
	}
	ssid[7] = '\0';
	wifi_connect(ssid);
	return 0;
}

static int wifi_test(){

	int fixed_ssid = -1
	char ssid[33];
	wireless_scan_head scanlist;

	if (mtk_get_iwinfo(skfd, "wlan0", &wlan_info) < 0){
		if (g_output_buf){
			memset(g_output_buf,0,g_output_buf_len);
			sprintf(g_output_buf, "%s", "[ERROR] can't get wlan info");
		}
		LOGD("MYTEST failed to get wlan0 info");
		return 1;
	}

	if (iw_scan(skfd, "wlan0", 21, &scanlist) < 0)
	{
		LOGE("MYTEST failed to scan");
		if (g_output_buf)
		{
			memset(g_output_buf,0,g_output_buf_len);
			sprintf(g_output_buf,"%s","[ERROR] scan failed");
		}
		return 2;
	}

	if (scanlist.result == NULL)
	{
		LOGE("MYTEST no scan result");
		if (g_output_buf)
		{
			memset(g_output_buf,0,g_output_buf_len);
			sprintf(g_output_buf,"%s", "[WARN] no network avail");
		}
		return 3;
	}

	if (read_preferred_ssid(ssid, sizeof(ssid)))
	{
		fixed_ssid = 1;
		LOGE("MYTEST use specified ssid ssid=%s",ssid);
	}

	wireless_scan * item;
	wireless_info wlan_info;
	wireless_scan* ap = NULL;
	int temlevel;
	for (item = scanlist.result; item != NULL; item=item->next)
	{
#if 1
		LOGD("MYTEST new STA +++++++++++++");
		if (item->b.has_essid && strlen(item->b.essid) > 0)
		{
			LOGD("MYTEST SSID: %s", item->b.ssid);
		}

		if (item->b.has_mode)
		{
			LOGD("MYTEST mode : %s",item->mode==2?"Infrastructure":
				(item->mode==1?"AD-hoc":"unknown"));
		}

		if (item->has_stats)
		{
			temlevel = item->stats.qual.level - 0x100;
			LOGD("MYTEST rssi : %d dBm", temlevel);	
		}

		if (item->b.has_freq)
		{
			int channel = iw_freq_to_channel(item->b.freq/1000, &(wlan_info.range));
			if (channel < 0)
			{
				LOGD("MYTEST invalid channel num");
			}else{
				LOGD("MYTEST channel : %d", channel);
			}
		}

		if (item->has_maxbitrate)
		{
			LOGD("MYTEST rate : %dM", item->maxbitrate);
		}
#endif
		if (fixed_ssid == 1)
		{
			if (item->b.has_essid &&
				(strcmp(ssid, item->b.essid)==0))
			{
				ap = item;
				LOGD("MYTEST find specified AP %s", ssid);
				break;
			}
		}

		if (item->b.has_essid && 
			(strncmp(item->b.essid, "NVRAM WARNING: Err =",strlen("NVRAM WARNING: Err =")!=0)))
		{
			LOGD("MYTEST encode_disable ssid=%s",item->b.essid);
			if (item->b.key_flags & IW_ENCODE_DISABLED)
			{
				if (!ap)
				{
					ap = item;
				}else if(ap->stats.qual.level < item->stats.qual.level){
					ap = item;
				}
			}
		}
	}

	if (ap)
	{
		ap_info apinfo;
		memcpy(apinfo.ssid, ap->b.essid, sizeof(ap->b.essid));
		memcpy(apinfo.mac, ap->ap_addr.sa_data, sizeof(apinfo.mac));
		apinfo.mode = ap->b.mode;
		apinfo.channel = iw_freq_to_channel(ap->b.freq/1000,&(wlan_info.range));
		apinfo.rssi = (unsigned int)(ap->stats.qual.level) - 0x100;
		apinfo.rate = ap->maxbitrate.value/1000000;
		apinfo.media_status = media_connecting;

		update_Text_Info(&apinfo, g_output_buf, g_output_buf_len);
		usleep(3000000);

		if (wifi_connect(ap->b.ssid) < 0)
		{
			LOGE("MYTEST wifi_connect failed");
			if (g_output_buf)
			{
				memset(g_output_buf,0,g_output_buf_len);
				sprintf(g_output_buf."%s", "[ERROR] connect failed");
			}
			ret = 4;
		}

	}else{
		LOGE("MYTEST no suitable AP");
		if (g_output_buf)
		{
			meset(g_output_buf,0,g_output_buf_len);
			sprintf(g_output_buf,"%s", "[WARN] no siutable AP");
		}
		ret = 5;
	}
	free(scanlist.result);
	return ret;

}

struct wifi_factory {
    char  info[1024];
    bool  exit_thd;
    int   result;

    /* for UI display */
    text_t    title;
    text_t    text;

    pthread_t update_thd;
    struct ftm_module *mod;
    struct textview tv;
    struct itemview *iv;
    bool renew;
};

static void *wifi_update_thread(void *priv){

	struct wifi_factory wififm;
	memset(&wififm,0 ,sizeof(struct wifi_factory));
	if (WIFI_init(wififm.info, sizeof(wififm.info), &(wififm.result)) < 0)
	{
		LOGD("MYTEST WIFI_init failed");
	}
}

int new_wifi_test(){
	pthread_t handle_wifi;
	pthread_create(&handle_wifi, NULL, , NULL);
}