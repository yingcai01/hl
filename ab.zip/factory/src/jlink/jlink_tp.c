#include "jlinkui.h"
#include "events.h"

static struct input_event ev_queue[2048];
static int ev_tail_num = 0;
static int auto_ev_tail_num = 0;
static int auto_ev_head_num = 0;
static int ev_head_num = 0;
static int cross_num = 0;
#define TOUCH_UPDATE_FR_DIV 2
static pthread_mutex_t event_mutex = PTHREAD_MUTEX_INITIALIZER;

extern char rotate_lcm[];

static void del_event() {
     pthread_mutex_lock(&event_mutex);
     ev_tail_num++; 
     if (ev_tail_num == 2048) ev_tail_num = 0;
     pthread_mutex_unlock(&event_mutex);
}

static int jtprun = 0;

void jlink_stop_tp(){
    jtprun=0;
}

int getRotation(){
    if (0 == strncmp(rotate_lcm, "0", 1)){
        return 0;
    }
    else if (0 == strncmp(rotate_lcm, "90", 2)){
        return 1;
    }else if (0 == strncmp(rotate_lcm, "180", 3)){
        return 2;
    }else if (0 == strncmp(rotate_lcm, "270", 3)){
        return 3;
    }
    return 0;
}

extern int jlcd_height;
extern int jlcd_width;
extern void handevent(struct input_event *event);
void *start_touch_tp(void *para) {

    struct input_event data;
    int x=0,y=0,p=0,px=0,py=0,pp=0,d=0,count=0;
    int x2=0,y2=0,p2=0,pc=0, point_count=0;
    bool enter = true, release = true;
    line_t line = {0,0,0,0,2,COLOR_WHITE};
    char ptloc[80];
    int status = 0,i=0,distance=0, p_distance=0;
    int zoomrate = 0;
    int temrotate = getRotation();
    bool detect_flags;
    LOGD(TAG "enter update thread\n");
    jtprun = 1;
    while (jtprun) {
        
        //LOGD("MYTEST here 8 tpd->scene=%d,ITEM_TOUCH_CHOOSER=%d",tpd->scene,ITEM_TOUCH_CHOOSER);
        ev_head_num = get_ev_head_num();     
        if (ev_head_num == ev_tail_num)  {
            continue;
        }
        get_ev_arr(&data, ev_tail_num);
        del_event();
        handevent(&data);
        //LOGD("[touch] data.value:%d\n", data.value);
        if(data.type==EV_ABS && data.code==ABS_X) {x = data.value;}
        else if(data.type==EV_ABS && data.code==ABS_MT_POSITION_X) {x = data.value;}
        else if(data.type==EV_ABS && data.code==ABS_Y) {y = data.value;  }
        else if(data.type==EV_ABS && data.code==ABS_MT_POSITION_Y) {y = data.value; }
        else if(data.type==EV_ABS && data.code==ABS_PRESSURE) { p=data.value; }
        else if(data.type==EV_ABS && data.code==ABS_MT_TOUCH_MAJOR) { p=data.value; }
        else if(data.type==EV_KEY && data.code==BTN_TOUCH) { d=data.value; }
        else if(data.type==EV_SYN && data.code==SYN_MT_REPORT) {
            //LOGD("[touch] x:%d y:%d p:%d\n", x,y,p);
            if(pc==0) { x2 = x; y2 =y; p2 = p; }
            pc++;
            if(p==0) distance = 0;
        } else if(data.type==EV_SYN) {
            point_count++; 
            if(enter==true || release==true) { px=x;py=y;enter=false; release=false; }    
            //ui_color(255,255,255,255);
            do_grline(px,py,x,y,2,COLOR_WHITE);  
            //LOGD(TAG "freemode: x = %d, y = %d ; px = %d, py = %d\n", x, y, px, py);
#ifdef LINK_ITEM_DEBUG
            //不刷新,让重力感应刷新
            if (!(point_count%TOUCH_UPDATE_FR_DIV))
                ui_flip();
            point_count=point_count%TOUCH_UPDATE_FR_DIV;
#endif
                px=x,py=y;pc=0;
            if(d==0) release=true;
                
        }
       
    }
    LOGD(TAG "exit thread\n");
    pthread_exit(NULL);
    return NULL;
}
