#include "jlinkui.h"
#include <sys/mount.h>


extern TestEntry sdcardEntry;
static void mcard_update_info()
{
    unsigned int nr_sec;
    unsigned int sd_total_size = 0;
    int fd;
#ifdef MTK_EMMC_SUPPORT
    if ((fd = open("/dev/block/mmcblk1", O_RDONLY, 0644)) < 0) {
#else
    if ((fd = open("/dev/block/mmcblk0", O_RDONLY, 0644)) < 0) {
#endif
    } else {
        if ((ioctl(fd, BLKGETSIZE, &nr_sec)) == -1) {
			LOGD("BLKGETSIZE fail \n");
        } else {
            sd_total_size = (nr_sec /2048);
        }
        close(fd);
    }
    sprintf(sdcardEntry.value.name, "%s: %d MB\n",uistr_info_emmc_sd_total_size,
        sd_total_size);
	if (sd_total_size == 0){
        sdcardEntry.value.color = REDCOLOR;
		sdcardEntry.state = TEST_FAIL;
    }else{
		sdcardEntry.state = TEST_PASS;
	}
	setProinfoItemResult(sdcardEntry.id,sdcardEntry.state);
    return;
}



void * jlink_sdcard_start(void*para){

    drawTestItem(&sdcardEntry);
    mcard_update_info();
    drawItemValueBehind(&sdcardEntry);
    pthread_exit(NULL);
    return NULL;
}
