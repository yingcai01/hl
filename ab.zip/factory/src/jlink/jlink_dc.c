#include "jlinkui.h"

extern TestEntry dcEntry;
static int dcrunning = 0;
static int dc_update_info()
{
	char *ptr;
	int inode = 0;
	char buf[10];
	float temsize = 0;
	ssize_t len = 0;
	inode = open("/proc/dcdet_status", O_RDONLY|O_NONBLOCK);
	if (inode < 0) {
		printf("open error!\n");
		dcEntry.state = TEST_FAIL;
        sprintf(dcEntry.value.name,"%s",uistr_info_dcnonode);
		setProinfoItemResult(dcEntry.id,dcEntry.state);
		return -1;
	}
	memset(buf, 0, sizeof(buf));
    len = read(inode, buf, sizeof(buf) - 1);

    if (len == 1){
        sprintf(dcEntry.value.name,"%s",uistr_info_dcfail);
        dcEntry.state = TEST_FAIL;
        dcEntry.value.color = REDCOLOR;
        drawItemValueBehind(&dcEntry);
    }else{
        sprintf(dcEntry.value.name,"%s",uistr_info_finddc);
        dcEntry.state = TEST_PASS;
        dcEntry.value.color = GREENCOLOR;
        drawItemValueBehind(&dcEntry);
    }
    
	close(inode);
	setProinfoItemResult(dcEntry.id,dcEntry.state);
	return 0;
}



void * jlink_dc_start(void*para){

    drawTestItem(&dcEntry);
    dcrunning = 1;
    dc_update_info();
    return NULL;
}

