#include "jlinkui.h"

#include <linux/sensors_io.h>
#include <linux/hwmsensor.h>
#include "libhwm.h"

#define MPU3000_AXIS_X          0
#define MPU3000_AXIS_Y          1
#define MPU3000_AXIS_Z          2
#define MPU3000_AXES_NUM        3
#define MPU3000_FIFOSIZE				512
#define MPU3000_FS_MAX_LSB			131
static int bias_thresh = 5242; // 40 dps * 131.072 LSB/dps
static float RMS_thresh = 687.19f; // (.2 dps * 131.072) ^ 2
static int gyrorun = 0;
extern TestEntry gyroEntry;
struct gyro_priv
{
    /*specific data field*/
    char    *dev;
    int     fd;
    float gyro_x;
    float gyro_y;
    float gyro_z;
	HwmData dat;
    int resultcode;
	int smtflag;
	int smtRes;
};

struct gyro_data
{
    struct gyro_priv gyro;

    /*common for each factory mode*/
    char  info[1024];
    bool  avail;
    bool  exit_thd;

    text_t    title;
    text_t    text;
    text_t    left_btn;
    text_t    center_btn;
    text_t    right_btn;
    
    pthread_t update_thd;
    struct ftm_module *mod;
    struct textview tv;
    struct itemview *iv;
};


static int gyro_init_priv(struct gyro_priv *gyro)
{
    memset(gyro, 0x00, sizeof(*gyro));
    gyro->fd = -1;
    gyro->dev = "/dev/gyroscope";
    return 0;
}

static int gyro_open(struct gyro_priv *gyro)
{
    int err, max_retry = 3, retry_period = 100, retry;
    unsigned int flags = 1;
    if (gyro->fd == -1) {
        gyro->fd = open("/dev/gyroscope", O_RDONLY);
        if (gyro->fd < 0) {
            LOGE("Couldn't open '%s' (%s)", gyro->dev, strerror(errno));
            return -1;
        }
        retry = 0;
        while ((err = ioctl(gyro->fd, GYROSCOPE_IOCTL_INIT, &flags)) && (retry ++ < max_retry))
            usleep(retry_period*1000);
        if (err) {
            LOGE("enable gyro fail: %s", strerror(errno));
            return -1;            
        }          
    }
    LOGD("%s() %d\n", __func__, gyro->fd);
    return 0;
}

static int gyro_close(struct gyro_priv *gyro)
{
    unsigned int flags = 0;
    int err;
    if (gyro->fd != -1) {
        close(gyro->fd);
    }
    memset(gyro, 0x00, sizeof(*gyro));
    gyro->fd = -1;
    gyro->dev = "/dev/gyroscope";
    return 0;
}

static int gyro_update_info(struct gyro_priv *gyro)
{
    //short data[800];
    //int smtRes=-1;
    int i;
    int retval =0;
    int err = -EINVAL;
	char buf[64];
	int x,y,z=0;
		
    if (gyro->fd == -1) {
        LOGE("invalid fd\n");
        return err;
    }
	
    err = ioctl(gyro->fd, GYROSCOPE_IOCTL_READ_SENSORDATA, buf);
	if(err)
	{
        LOGE("read gyro data failed: %d(%s)\n", errno, strerror(errno));
        return err;
    }
	sscanf(buf, "%x %x %x", &x, &y, &z);
	LOGD("read data: x=%d, y=%d, z=%d, \n", x,  y,  z);
	
	
	gyro->gyro_x = ( (float)x / 1000); //driver multiple 1000 then divid in kernel
	gyro->gyro_y = ( (float)y / 1000);
	gyro->gyro_z = ( (float)z / 1000);
	gyro->resultcode = gyro->smtRes;
	LOGD("read gyro data OK: x=%f, y=%f, z=%f, resultcode=0x%4x\n", 
		gyro->gyro_x, gyro->gyro_y, gyro->gyro_z, gyro->resultcode);

	
    return 0;
}


static void *gyro_update_iv_thread(void *priv)
{
    struct gyro_data *dat = (struct gyro_data *)priv; 
    struct gyro_priv *gyro = &dat->gyro;
    int err = 0;
    int len = 0;
    float total;
    char *status;
    gyro_init_priv(gyro);
    gyroEntry.state = TEST_FAIL;
    LOGD(TAG "%s: Start\n", __FUNCTION__);
    if ((err = gyro_open(gyro))) {
        gyroEntry.value.color = REDCOLOR;
        sprintf(gyroEntry.value.name,"%s",uistr_info_sensor_init_fail);
        drawItemValueBehind(&gyroEntry);
        setProinfoItemResult(gyroEntry.id,gyroEntry.state);
        pthread_exit(NULL);
        return NULL;
    }
    int times = 0;
    int keepresult = 0;
    float x = 0.0f,y = 0.0f,z = 0.0f;
    while (gyrorun) {
        
        if ((err = gyro_update_info(gyro))){
	   		LOGE("gyro_update_info() = (%s), %d\n", strerror(errno), err);
            break;
        }
        LOGD("MPU3000 gyro_update_info OK\n"); 
	
        sprintf(gyroEntry.value.name, "%+7.4f %+7.4f %+7.4f",gyro->gyro_x, gyro->gyro_y, gyro->gyro_z);
        drawItemValueBehind(&gyroEntry);
        if (times < 10){
            if (times == 0){
                x = gyro->gyro_x;
                y = gyro->gyro_y;
                z = gyro->gyro_z;
            }else{
                if (x!=gyro->gyro_x || y != gyro->gyro_y || z != gyro->gyro_z){
                    keepresult++;
                }
            }
            times++;
            if (times>=10){
                if (keepresult>=3){
                    gyroEntry.value.color = GREENCOLOR;
                    gyroEntry.state = TEST_PASS;
                }else{
                    gyroEntry.value.color = REDCOLOR;
                    gyroEntry.state = TEST_FAIL;
                }
                setProinfoItemResult(gyroEntry.id,gyroEntry.state);
            }
        }

    }
    gyro_close(gyro);
    LOGD(TAG "%s: Exit\n", __FUNCTION__);    
    pthread_exit(NULL);    
    return NULL;
}


void* jlink_gyro_start(void *para)
{
    drawTestItem(&gyroEntry);
    struct gyro_data *dat = (struct gyro_data *)calloc(sizeof(struct gyro_data),1);
    gyrorun = 1;
    sprintf(gyroEntry.value.name, "%s\n",  uistr_info_sensor_initializing);
    drawItemValueBehind(&gyroEntry);
    pthread_create(&dat->update_thd, NULL, gyro_update_iv_thread, dat);
    pthread_join(dat->update_thd, NULL);
    if (dat!=NULL) free(dat);
    return NULL;
}

void stop_gyro(){
	gyrorun = 0;
}
