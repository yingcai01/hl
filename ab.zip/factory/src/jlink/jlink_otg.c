#include "jlinkui.h"
#include <sys/statfs.h>
#include <sys/mount.h>

#define OTG_STATE_PATH "/sys/class/switch/otg_state/state"
#define MOUNT_PATH "/storage/usbotg"
#define DEV_PATH "/dev/block/sda"
#define DEV_PATH2 "/dev/block/sda1"
#define DEV_BUS_PATH "/sys/bus/usb/devices/1-1/speed"
#define DEV_INPUT_DEVICE "/proc/bus/input/devices"

#define BUF_LEN 1
static char r_buf[BUF_LEN] = {'\0'};
static char w_buf[BUF_LEN] = {'1'};

#define TEST_IDDIG_5V_ONLY 1
#define TEST_CHECK_BUSDEVICE 1
#define TEST_CHECK_MOUSE  1

static int getInputMouse(){
  char buf[100] = {0};
  int ret = 0;
  FILE *file = fopen(DEV_INPUT_DEVICE,"r");
  char * tem = NULL;
  if (file!=NULL){
    while((tem=fgets(buf,100,file))!=NULL){
      if (strstr(buf,"Mouse")!=NULL)
      {
		ret = 1;
        break;
	  }
      tem = NULL;
    }
  }
  if (file != NULL) fclose(file);
/*
  if (tem!=NULL){
    
    tem = strtok(buf," ");
    while(tem != NULL){
      if((tem = strtok(NULL," "))!=NULL){
        if (*tem>= '0' && *tem <= '9'){
          break;
        }
      }
    }
    return size;
  }
  */  
  return ret;
}


static void otg_update_info(TestEntry* otgentry)
{
    char *ptr;
    int rc;
	int fd = -1;
	int fd_state = -1;
	int hb_status = 0;
	int ret = 0;
	int flags;
	int device_state = 0;
	struct statfs stat;

	int avail = 0;
	fd = open(OTG_STATE_PATH, O_RDONLY, 0);
	if (fd < 0) {
		LOGD(TAG "Can't open %s\n", OTG_STATE_PATH);
		goto EXIT;
	}
	if (read(fd, r_buf, BUF_LEN) < 0) {
		LOGD(TAG "Can't read %s\n",OTG_STATE_PATH);
		goto EXIT2;
	}

        LOGD("OTG state is %s\n",r_buf);

#if TEST_CHECK_MOUSE	
	fd_state = getInputMouse();
	if(fd_state <= 0)
	{
		device_state = 1;
		LOGD(TAG "Can't find mouse info in %s\n",DEV_INPUT_DEVICE);
		goto EXIT2;
	}else
		device_state = 2;
#endif

#if TEST_CHECK_BUSDEVICE
	fd_state = open(DEV_BUS_PATH, O_RDONLY, 0);
	if (fd_state < 0) {
		LOGD(TAG "Can't open %s\n", DEV_BUS_PATH);
		goto EXIT2;
	}
	else
		device_state = 3;

       if (strncmp(w_buf, r_buf, BUF_LEN)) { /*the same*/
    	    goto EXIT2;
       }

	flags = MS_NODEV | MS_NOEXEC | MS_NOSUID | MS_DIRSYNC;
	rc = mount(DEV_PATH, MOUNT_PATH, "vfat", flags,
		"utf8,uid=1000,gid=1015,fmask=702,dmask=702,shortname=mixed");
	if(rc)
		rc = mount(DEV_PATH2, MOUNT_PATH, "vfat", flags,
			"utf8,uid=1000,gid=1015,fmask=702,dmask=702,shortname=mixed");

    if(rc){
		LOGE(TAG "%s: mount fail, %d (%s)\n", __FUNCTION__, errno, strerror(errno));
		goto EXIT2;
	}

	rc = statfs(MOUNT_PATH, &stat);
	if(rc){
		LOGE(TAG "%s: statfs fail, %d (%s)\n", __FUNCTION__, errno, strerror(errno));
		goto EXIT3;
	}

	avail = 1;
	otgentry->value.color = GREENCOLOR;

EXIT3:
	umount(MOUNT_PATH);
#endif
EXIT22:
	close(fd_state);
EXIT2:
	close(fd);
EXIT:
    /* preare text view info */
    ptr  = otgentry->value.name;
    #if !TEST_IDDIG_5V_ONLY
    if(avail){
            otgentry->state = TEST_PASS;
	  otgentry->value.color = GREENCOLOR;
          ptr += sprintf(ptr, "Total Size: %d MB\n",(unsigned int)(stat.f_blocks * stat.f_bsize >> 20));
    }
    else{
            otgentry->state = TEST_FAIL;
			otgentry->value.color=REDCOLOR;
            ptr += sprintf(ptr, "Cannot access storage\n");
    }
    #else
	otgentry->state = TEST_PASS;
    otgentry->value.color=GREENCOLOR;
    if (strncmp(r_buf, "0", 1) == 0){
            ptr += sprintf(ptr, "Device mode, NO OTG devices!\n");
			otgentry->state = TEST_FAIL;
    		otgentry->value.color=REDCOLOR;
	}
    else if (strncmp(r_buf, "1",1) == 0) {
	if(device_state == 3)
	{
    		ptr += sprintf(ptr, "[Host-5V]U-disk(%d MB) Or Bus-devices plugged in!!\n",(unsigned int)(stat.f_blocks * stat.f_bsize >> 20));
	}else if(device_state == 2)
	{

    		ptr += sprintf(ptr, "[Host-5V]mouse plugged in And 5V applied!!\n");
	}
	else{
    		ptr += sprintf(ptr, "[Host-5V]OTG devices plugged in!!\n");
	}
    }
    else if (strncmp(r_buf, "2",1) == 0)
    {
         ptr += sprintf(ptr, "[Host-5V]OTG devices plugged in!!\n");
    }
    else{
		otgentry->state = TEST_FAIL;
    	otgentry->value.color = REDCOLOR;
        ptr += sprintf(ptr, "Fail!!\n");
    }
    #endif
    setProinfoItemResult(otgentry->id,otgentry->state);
    return;
}


extern TestEntry otgEntry;
void * jlink_otg_start(void*para){
	/*
	TestEntry otgEntry;
	int row = 0;
	if (para!=NULL)
	{
		row = *(int*)para;
	}
	
	memset(&otgEntry,0,sizeof(otgEntry));
    otgEntry.entry.color = YELLOWCOLOR;
    otgEntry.entry.row = row;
    otgEntry.entry.backcolor = BACKCOLOR;
    otgEntry.entry.col = ITEMCOL;
    strcpy(otgEntry.entry.name,uistr_info_otg_status);
    otgEntry.value.color = REDCOLOR;
    otgEntry.value.backcolor = BACKCOLOR;
    */
    drawTestItem(&otgEntry);
    strcpy(otgEntry.value.name,uistr_info_waiting);
    drawItemValueBehind(&otgEntry);
    sleep(10);
    otg_update_info(&otgEntry);
    drawItemValueBehind(&otgEntry);

    return NULL;
}