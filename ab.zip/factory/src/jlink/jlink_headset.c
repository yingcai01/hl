#include "jlinkui.h"
#include "../test/ftm_audio_Common.h"
#include "ftm.h"
#include <linux/ioctl.h>

#include "DIF_FFT.h"
#include "Audio_FFT_Types.h"
#include "Audio_FFT.h"


#define HEADSET_STATE_PATH "/sys/class/switch/h2w/state"
static const char *HEADSET_PATH = "/dev/accdet";

static int headset_phonetest_state = 0;
static int HeadsetFd = 0;
extern enum HEADSET_POLE_TYPE
{
    HEADSET_POLE_UNKNOWN = -1,
    HEADSET_POLE_3 = 3,
    HEADSET_POLE_4 = 4,
    HEADSET_POLE_5 = 5
};
#define ACCDET_IOC_MAGIC 'A'
#define SET_CALL_STATE    _IO(ACCDET_IOC_MAGIC,1)  // when state is changing , tell headset driver.
#define GET_BUTTON_STATUS _IO(ACCDET_IOC_MAGIC,2)  // ioctl to get hook button state.

#define BUF_LEN 1
static char rbuf[BUF_LEN] = {'\0'};
static char wbuf[BUF_LEN] = {'1'};
static char wbuf_2[BUF_LEN] = {'2'};
static char hs5pole_id[BUF_LEN] = {'3'};

extern struct headset
{
    char  info[1024];
    bool  avail;
    bool  Headset_mic;
    enum HEADSET_POLE_TYPE num_hs_pole;
    bool  exit_thd;
    pthread_t hRecordThread;
    pthread_t headset_update_thd;
    struct ftm_module *mod;
    struct textview tv;
    struct itemview *iv;
    int  recordDevice;
    text_t    title;
    text_t    text;
    text_t    left_btn;
    text_t    center_btn;
    text_t    right_btn;
    bool  isPhoneTest;
};


static bool read_preferred_recorddump(void)
{
    char *pDump = NULL;
    char uName[64];

    memset(uName, 0, sizeof(uName));
    sprintf(uName, "%s", "Audio.Record.Dump");
    pDump = ftm_get_prop(uName);
    ALOGD("pDump:%s", pDump);

    if (pDump != NULL)
    {
        if (!strcmp(pDump, "1"))
        {
            ALOGD("Dump record data");
            return true;
        }
        else
        {
            ALOGD("No need to dump record data");
            return false;
        }
    }
    else
    {
        ALOGD("Dump record prop can't get");
        return false;
    }
}

static void read_preferred_magnitude(int *pUpper, int *pLower)
{
    char *pMagLower = NULL, *pMagUpper = NULL;
    char uMagLower[64], uMagUpper[64];

    *pUpper = 0;
    *pLower = 0;
    memset(uMagLower, 0, sizeof(uMagLower));
    memset(uMagUpper, 0, sizeof(uMagUpper));

    sprintf(uMagLower, "%s", "Lower.Magnitude.Headset");
    sprintf(uMagUpper, "%s", "Upper.Magnitude.Headset");

    pMagLower = ftm_get_prop(uMagLower);
    pMagUpper = ftm_get_prop(uMagUpper);
    if (pMagLower != NULL && pMagUpper != NULL)
    {
        *pLower = (int)atoi(pMagLower);
        *pUpper = (int)atoi(pMagUpper);
        ALOGD("Lower.Magnitude:%d,Upper.Magnitude:%d\n", *pLower, *pUpper);
    }
    else
    {
        ALOGD("Lower/Upper.Magnitude can not get\n");
    }
}


static void *Audio_Record_thread(void *mPtr)
{
    struct headset *hds  = (struct headset *)mPtr;
    ALOGD(TAG "%s: Start", __FUNCTION__);
    usleep(100000);
    bool dumpFlag = read_preferred_recorddump();
    //    bool dumpFlag = true;//for test
    int magLower = 0, magUpper = 0;
    read_preferred_magnitude(&magUpper, &magLower);
    int lowFreq = 1000 * (1 - 0.1); //1k
    int highFreq = 1000 * (1 + 0.1);
    short *pbuffer, *pbufferL, *pbufferR;
    unsigned int freqDataL[3] = {0}, magDataL[3] = {0};
    unsigned int freqDataR[3] = {0}, magDataR[3] = {0};
    int checkCnt = 0;
    uint32_t samplerate = 0;

    pbuffer = (short *)malloc(8192 * sizeof(short));
    if (pbuffer == NULL) {
        ALOGE(TAG "%s: pbuffer allocate fail !!", __FUNCTION__);
        return NULL;
    }

    pbufferL = (short *)malloc(4096 * sizeof(short));
    if (pbufferL == NULL) {
        ALOGE(TAG "%s: pbufferL allocate fail !!", __FUNCTION__);
        free(pbuffer);
        return NULL;
    }

    pbufferR = (short *)malloc(4096 * sizeof(short));
    if (pbufferR == NULL) {
        ALOGE(TAG "%s: pbufferR allocate fail !!", __FUNCTION__);
        free(pbuffer);
        free(pbufferL);
        return NULL;
    }

    // headsetLR: Phone level test; headset: Non-Phone level test.
    //return_data.headsetL.freqL = return_data.headsetR.freqL = freqDataL[0];
    //return_data.headsetL.freqR = return_data.headsetR.freqR = freqDataR[0];
    //return_data.headsetL.amplL = return_data.headsetR.amplL = magDataL[0];
    //return_data.headsetL.amplR = return_data.headsetR.amplR = magDataR[0];

    recordInit(hds->recordDevice, &samplerate);
    while (1)
    {
        memset(pbuffer, 0, 8192 * sizeof(short));
        memset(pbufferL, 0, 4096 * sizeof(short));
        memset(pbufferR, 0, 4096 * sizeof(short));

        int readSize  = readRecordData(pbuffer, 8192 * 2);
        for (int i = 0 ; i < 4096 ; i++)
        {
            pbufferL[i] = pbuffer[2 * i];
            pbufferR[i] = pbuffer[2 * i + 1];
        }

        if (dumpFlag)
        {
            char filenameL[] = "/data/record_headset_dataL.pcm";
            char filenameR[] = "/data/record_headset_dataR.pcm";
            FILE *fpL = fopen(filenameL, "wb+");
            FILE *fpR = fopen(filenameR, "wb+");

            if (fpL != NULL)
            {
                fwrite(pbufferL, readSize / 2, 1, fpL);
                fclose(fpL);
            }

            if (fpR != NULL)
            {
                fwrite(pbufferR, readSize / 2, 1, fpR);
                fclose(fpR);
            }
        }

        memset(freqDataL, 0, sizeof(freqDataL));
        memset(freqDataR, 0, sizeof(freqDataR));
        memset(magDataL, 0, sizeof(magDataL));
        memset(magDataR, 0, sizeof(magDataR));
        ApplyFFT256(samplerate, pbufferL, 0, freqDataL, magDataL);
        ApplyFFT256(samplerate, pbufferR, 0, freqDataR, magDataR);
        for (int i = 0; i < 3 ; i ++)
        {
            SLOGV("%d.freqDataL[%d]:%d,magDataL[%d]:%d", i, i, freqDataL[i], i, magDataL[i]);
            SLOGV("%d.freqDataR[%d]:%d,magDataR[%d]:%d", i, i, freqDataR[i], i, magDataR[i]);
        }

        if (hds->isPhoneTest)
        {
            if (headset_phonetest_state == 0) // CH1
            {
                //CH1 Log
                /*
                return_data.headsetL.freqL = freqDataL[0];
                return_data.headsetL.amplL = magDataL[0];
                return_data.headsetL.freqR = freqDataR[0];
                return_data.headsetL.amplR = magDataR[0];
				*/

                if ((freqDataL[0] <= highFreq && freqDataL[0] >= lowFreq) && (magDataL[0] <= magUpper && magDataL[0] >= magLower))
                {
                    checkCnt ++;
                    if (checkCnt >= 5)
                    {
                        ALOGD("[Headset-L] freqDataL:%d,magDataL:%d,freqDataR:%d,magDataR:%d", freqDataL[0], magDataL[0], freqDataR[0], magDataR[0]);
                        checkCnt = 0;
                    }
                }
                else
                {
                    checkCnt = 0;
                }
            }
            else if (headset_phonetest_state == 1) // CH2
            {
                if ((freqDataR[0] <= highFreq && freqDataR[0] >= lowFreq) && (magDataR[0] <= magUpper && magDataR[0] >= magLower))
                {
                    checkCnt ++;
                    if (checkCnt >= 5)
                    {
                        ALOGD("[Headset-R] freqDataL:%d,magDataL:%d,freqDataR:%d,magDataR:%d", freqDataL[0], magDataL[0], freqDataR[0], magDataR[0]);
                        snprintf(hds->info, sizeof(hds->info), "Check freq pass.\n");
                        ALOGD(" @ info : %s", hds->info);
                        break;
                    }
                }
                else
                {
                    checkCnt = 0;
                }
            }
            else
            {
                break;
            }
        }
        else // Non Phone level test
        {
            if ((hds->num_hs_pole != HEADSET_POLE_5 &&
                (freqDataL[0] <= highFreq && freqDataL[0] >= lowFreq) &&
                (magDataL[0] <= magUpper && magDataL[0] >= magLower))
                ||
                (hds->num_hs_pole == HEADSET_POLE_5 &&
                (freqDataL[0] <= highFreq && freqDataL[0] >= lowFreq) &&
                (magDataL[0] <= magUpper && magDataL[0] >= magLower) &&
                (freqDataR[0] <= highFreq && freqDataR[0] >= lowFreq) &&
                (magDataR[0] <= magUpper && magDataR[0] >= magLower)))
            {
                checkCnt ++;
                ALOGD("[HS mic] checkCnt[%d], freqDataL:%d,magDataL:%d,freqDataR:%d,magDataR:%d", checkCnt, freqDataL[0], magDataL[0], freqDataR[0], magDataR[0]);
                if (checkCnt >= 5)
                {
                    snprintf(hds->info, sizeof(hds->info), "Check freq pass.\n");
                    ALOGD(" @ info : %s", hds->info);
                    break;
                }
            }
            else
            {
                checkCnt = 0;
                ALOGD("[HS mic] FAIL, checkCnt reset [%d], freqDataL:%d,magDataL:%d,freqDataR:%d,magDataR:%d", checkCnt, freqDataL[0], magDataL[0], freqDataR[0], magDataR[0]);
            }

            if (hds->exit_thd)
            {
                break;
            }
        }
    }

    // Log and ATA Return
    /*
    if (hds->isPhoneTest)
    {
        //CH2 Log
        
        return_data.headsetR.freqL = freqDataL[0];
        return_data.headsetR.freqR = freqDataR[0];
        return_data.headsetR.amplL = magDataL[0];
        return_data.headsetR.amplR = magDataR[0];
        ALOGD(TAG "ATA Return Data[Headset-L]: [Mic1]Freq = %d, Amp = %d, [Mic2]Freq = %d, Amp = %d", return_data.headsetL.freqL, return_data.headsetL.amplL, return_data.headsetL.freqR, return_data.headsetL.amplR);
        ALOGD(TAG "ATA Return Data[Headset-R]: [Mic1]Freq = %d, Amp = %d, [Mic2]Freq = %d, Amp = %d", return_data.headsetR.freqL, return_data.headsetR.amplL, return_data.headsetR.freqR, return_data.headsetR.amplR);
    	
    }
    else
    {
        if (headset_phonetest_state == 0)   // L ch
        {
        	
            return_data.headset.freqL = freqDataL[0];   // HS mic record in single channel format, data is the same in L && R channel
            return_data.headset.amplL = magDataL[0];
            ALOGD(TAG "ATA Return Data[Headset-L]: Freq = %d, Amp = %d", return_data.headset.freqL, return_data.headset.amplL);
       		
        }
        else if (headset_phonetest_state == 1)  // R ch
        {
            if (hds->num_hs_pole == HEADSET_POLE_5)
            {
                return_data.headset.freqR = freqDataR[0];
                return_data.headset.amplR = magDataR[0];
            }
            else // hds->num_hs_pole == HEADSET_POLE_4
            {
                return_data.headset.freqR = freqDataL[0];
                return_data.headset.amplR = magDataL[0];
            }
            ALOGD(TAG "ATA Return Data[Headset-R]: Freq = %d, Amp = %d", return_data.headset.freqR, return_data.headset.amplR);
        }
    }
    */
    free(pbuffer);
    free(pbufferL);
    free(pbufferR);

    ALOGD(TAG "%s: Stop", __FUNCTION__);
    pthread_exit(NULL); // thread exit
    return NULL;
}

static void headset_update_info(struct headset *hds, char *info)
{

    char *ptr;
    int rc;
    int fd = -1;
    int hb_status = 0;
    int ret = 0;
    hds->Headset_mic = false;

    fd = open(HEADSET_STATE_PATH, O_RDONLY, 0);
    if (fd == -1)
    {
        LOGD(TAG "Can't open %s\n", HEADSET_STATE_PATH);
        hds->avail = false;
        goto EXIT;
    }
    if (read(fd, rbuf, BUF_LEN) == -1)
    {
        LOGD(TAG "Can't read %s\n", HEADSET_STATE_PATH);
        hds->avail = false;
        close(fd);
        goto EXIT;
    }

    if (!strncmp(wbuf, rbuf, BUF_LEN))   /*the same*/
    {
        ALOGD(TAG "state == %s", wbuf);
        hds->avail = true;
        hds->Headset_mic = true;
        hds->num_hs_pole = HEADSET_POLE_4;
    }
    else
    {
        ALOGD(TAG "state != %s", wbuf);
        hds->avail = false;
        hds->num_hs_pole = HEADSET_POLE_UNKNOWN;
    }
    if (!strncmp(wbuf_2, rbuf, BUF_LEN))   /*the same*/
    {
        ALOGD(TAG "state == %s", wbuf_2);
        hds->avail = true;
        hds->Headset_mic = false;
        hds->num_hs_pole = HEADSET_POLE_3;
    }
    if (!strncmp(hs5pole_id, rbuf, BUF_LEN))   /*the same*/
    {
        ALOGD(TAG "state == %s", hs5pole_id);
        hds->avail = true;
        hds->Headset_mic = true;
        hds->num_hs_pole = HEADSET_POLE_5;
    }
    close(fd);

EXIT:
    //return_data.headset.hds_state = hds->avail ? 1 : 0;
    //return_data.headset.hds_mic_state = hds->Headset_mic ? 1 : 0;

    //if (hds->avail) {
    if (!strncmp(wbuf, rbuf, BUF_LEN))
    {
#ifdef HEADSET_BUTTON_DETECTION
        // open headset device
        HeadsetFd = open(HEADSET_PATH, O_RDONLY);
        if (HeadsetFd < 0)
        {
            LOGD(TAG "FTM:HEADSET open %s error fd = %d", HEADSET_PATH, HeadsetFd);
            goto EXIT_HEADSET;
        }

        // enable button detection
        LOGD(TAG "enable button detection \n");
        ret = ioctl(HeadsetFd, SET_CALL_STATE, 1);

        // read button status
        LOGD(TAG "read button status \n");
        ret = ioctl(HeadsetFd, GET_BUTTON_STATUS, 0);
        if (ret == 0)
        {
            hb_status = 0;
        }
        else
        {
            hb_status = 1;
        }

        // disable button detection
        //LOGD(TAG "disable button detection \n");
        //ret = ::ioctl(HeadsetFd,HEADSET_SET_STATE,0);
        close(HeadsetFd);
#endif
    }

EXIT_HEADSET:
    /* preare text view info */
    ptr  = info;
    if (!hds->avail)
    {
        ptr += sprintf(ptr, "%s", uistr_info_audio_headset_note);
    }
    ptr += sprintf(ptr, "%s : %s\n\n", uistr_info_avail , hds->avail ? "Yes" : "No");
#if 0
    if (hds->avail)
    {
        ptr += sprintf(ptr, "%s", "Please listen the sound from the headset\n\n");
    }
    else
    {
        ptr += sprintf(ptr, "%s", "Please insert the headset to test this item\n\n");
    }
#endif

#ifdef HEADSET_BUTTON_DETECTION
    if (hds->avail)
    {
        ptr += sprintf(ptr, "%s: %s\n\n", uistr_info_button, hb_status ? uistr_info_press : uistr_info_release);
    }
#endif
    if (hds->avail)
    {
        ptr += sprintf(ptr, "%s %s\n\n", uistr_info_audio_headset_mic_avail, hds->Headset_mic ? uistr_info_audio_yes : uistr_info_audio_no);
        if (!hds->Headset_mic)
        {
            ptr += sprintf(ptr, "%s:N/A\n", uistr_info_audio_loopback_headset_mic);
        }
    }

    return;
}
static bool ishead_threadrun;
int jlink_headset_entry(TestEntry* headsetentry)
{
    int chosen;
    bool exit = false;
    struct headset *hds = (struct headset *)malloc(sizeof(struct headset));
    memset(hds,0,sizeof(struct headset));

    LOGD(TAG "%s\n", __FUNCTION__);

    int    play_time = 3000;//ms
    LOGD(TAG "error-00\n");
    //hds->mod->test_result = FTM_TEST_FAIL;

    hds->exit_thd = false;
    LOGD(TAG "error-01\n");
    // check hs state
    strcpy(headsetentry->value.name,uistr_headset_tips);
    drawItemValueBehind(headsetentry);
    headsetentry->state = TEST_FAIL;
    while (ishead_threadrun){
        headset_update_info(hds, hds->info);
        if (hds->num_hs_pole!=HEADSET_POLE_UNKNOWN)
        {
        	headsetentry->state = TEST_PASS;
            headsetentry->value.color = GREENCOLOR;
            break;
        }
        usleep(300000);
    }
    
    LOGD(TAG "error-02\n");
    memset(hds->info, 0, sizeof(hds->info));
    char *ptr = headsetentry->value.name;
    ptr += sprintf(ptr, "Headset Pole = %d\n", hds->num_hs_pole);
    //iv->redraw(iv);
    drawItemValueBehind(headsetentry);

    if (hds->num_hs_pole == HEADSET_POLE_4)
    {
        ptr += sprintf(ptr, "%s", "Insert HeadsetMic\n");
    }
    else if (hds->num_hs_pole == HEADSET_POLE_5)
    {
    }
    else    // HEADSET_POLE_3 or HEADSET_POLE_UNKNOWN
    {
        ptr += sprintf(ptr, "%s", "Insert Headset without Mic\n");
        //iv->redraw(iv);
        
//        usleep(1500000);
//        return 0;
    }
    drawItemValueBehind(headsetentry);
    ALOGD("start play and freq check");

#if 0 //去掉播放音频和扬声器冲突
    // start test
    Common_Audio_init();

    memset(hds->info, 0, sizeof(hds->info) / sizeof(*(hds->info)));
    hds->recordDevice = WIRED_HEADSET;
    pthread_create(&hds->hRecordThread, NULL, Audio_Record_thread, hds);

    bool leftChPass = false;
    bool rightChPass = false;

    //----- Test CH1
    EarphoneTest(1);
    EarphoneTestLR(0);
    headset_phonetest_state = 0;    // for passing which HS channel is in use to Audio_Record_thread(), 0: L ch, 0: R ch
    for (int i = 0; i < 500 ; i ++)
    {
        if (strstr(hds->info, "Check freq pass"))
        {
            leftChPass = true;
            ALOGD("L channel check freq pass");
            break;
        }
        usleep(play_time * 20);
    }
    EarphoneTest(0);
    hds->exit_thd = true;
    pthread_join(hds->hRecordThread, NULL);
    Common_Audio_deinit();

    // create new record thread to check right channel
    Common_Audio_init();

    memset(hds->info, 0, sizeof(hds->info) / sizeof(*(hds->info)));
    hds->exit_thd = false;
    pthread_create(&hds->hRecordThread, NULL, Audio_Record_thread, hds);

    //----- Test CH2
    EarphoneTest(1);
    EarphoneTestLR(1);
    headset_phonetest_state = 1;    // for passing which HS channel is in use to Audio_Record_thread(), 0: L ch, 0: R ch
    for (int i = 0; i < 500 ; i ++)
    {
        if (strstr(hds->info, "Check freq pass"))
        {
            rightChPass = true;
            ALOGD("R channel check freq pass");
            break;
        }
        usleep(play_time * 20);
    }
    EarphoneTest(0);
    hds->exit_thd = true;
    pthread_join(hds->hRecordThread, NULL);

    ALOGD("stop play and freq check");
    if (leftChPass && rightChPass)
    {
        //hds->mod->test_result = FTM_TEST_PASS;
        ALOGD("Headset Loopback Test PASS");
    }
    else
    {
        ALOGD("Headset Loopback Test FAIL!!!!!");
    }

    // deinit
    Common_Audio_deinit();
#endif

    LOGD(TAG "%s: End\n", __FUNCTION__);
    free(hds);
    setProinfoItemResult(headsetentry->id,headsetentry->state);
    return 0;
}

extern TestEntry headsetEntry;
void * jlink_heaset_start(void *para){

    ishead_threadrun = true;
    drawTestItem(&headsetEntry);
    jlink_headset_entry(&headsetEntry);
	return NULL;
}

void stopHeadset(){
    ishead_threadrun = false;
}