#include "jlinkui.h"
#include <linux/sensors_io.h>

struct lps_priv
{
    /*specific data field*/
    char    *dev;
    int     fd;
    unsigned int als_raw;
    unsigned int ps_raw;
    unsigned int ps_threshold_value;//yucong add for cust support
    unsigned int ps_threshold_high;//yucong add for cust support
    unsigned int ps_threshold_low;//yucong add for cust support
    unsigned int als_threshold_value;//yucong add for cust support
    unsigned int als_threshold_high;//yucong add for cust support
    unsigned int als_threshold_low;//yucong add for cust support
};

struct lps_data
{
    struct lps_priv lps;

    /*common for each factory mode*/
    char  info[1024];
    //bool  avail;
    bool  exit_thd;

    text_t    title;
    text_t    text;
    text_t    left_btn;
    text_t    center_btn;
    text_t    right_btn;
    
    pthread_t update_thd;
    struct ftm_module *mod;
    //struct textview tv;
    struct itemview *iv;
};

static int thread_run = 1;
static int isslpsopen = -1;

static int alsps_open(struct lps_priv *lps)
{
    int err = 0, max_retry = 3, retry_period = 100, retry = 0;
    unsigned int flags = 1;
    isslpsopen = -1;

    if (lps->fd == -1) {
        lps->fd = open("/dev/als_ps", O_RDONLY);
        if (lps->fd < 0) {
        	isslpsopen = 0;
            LOGE(TAG"Couldn't open '%s' (%s)", lps->dev, strerror(errno));
            return -1;
        }
        isslpsopen = 1;
        retry = 0;
        while ((err = ioctl(lps->fd, ALSPS_SET_PS_MODE, &flags)) && (retry ++ < max_retry))
            usleep(retry_period*1000);
        if (err) {
            LOGE(TAG"enable ps fail: %s", strerror(errno));
            return -1;            
        } 
        retry = 0;
        while ((err = ioctl(lps->fd, ALSPS_SET_ALS_MODE, &flags)) && (retry ++ < max_retry)) 
            usleep(retry_period*1000);
        if (err) {
            LOGE(TAG"enable als fail: %s", strerror(errno));
            return -1;            
        }
    }
    LOGD(TAG"%s() %d\n", __func__, lps->fd);
    return 0;
}

static int alsps_close(struct lps_priv *lps)
{
    unsigned int flags = 0;
    int err = 0;
    if (lps->fd != -1) {
        if ((err = ioctl(lps->fd, ALSPS_SET_PS_MODE, &flags))) {
            LOGE("disable ps fail: %s", strerror(errno));
            return -1;            
        } else if ((err = ioctl(lps->fd, ALSPS_SET_ALS_MODE, &flags))) {
            LOGE("disable als fail: %s", strerror(errno));
            return -1;            
        }
        close(lps->fd);
    }
    memset(lps, 0x00, sizeof(*lps));
    lps->fd = -1;
    lps->dev = "/dev/als_ps";
    return 0;
}


extern TestEntry alpsEntry;

static int alsps_update_info(struct lps_priv *lps)
{
    int err = -EINVAL;
    int als_dat, ps_dat, ps_threshold_dat, ps_high, ps_low;//yucong add for factory mode test support
    if (lps->fd == -1) {
        LOGE(TAG"invalid fd\n");
        return -EINVAL;
    }else if ((err = ioctl(lps->fd, ALSPS_GET_PS_RAW_DATA, &ps_dat))) {
        LOGE(TAG"read ps  raw: %d(%s)\n", errno, strerror(errno));
        return err;
    }else if ((err = ioctl(lps->fd, ALSPS_GET_ALS_RAW_DATA, &als_dat))) {
        LOGE(TAG"read als raw: %d(%s)\n", errno, strerror(errno));
        return err;
    }else if ((err = ioctl(lps->fd, ALSPS_GET_PS_TEST_RESULT, &ps_threshold_dat))) {//yucong add for factory mode test support
        //LOGE(TAG"get thresheld infr: %d(%s)\n", errno, strerror(errno));
	    ps_threshold_dat = 2;
    } 
    if ((err = ioctl(lps->fd, ALSPS_GET_PS_THRESHOLD_HIGH, &ps_high))) {//yucong add for factory mode test support
        //LOGE(TAG"get thresheld high infr: %d(%s)\n", errno, strerror(errno));
	    ps_high = 0;
    }
    if ((err = ioctl(lps->fd, ALSPS_GET_PS_THRESHOLD_LOW, &ps_low))) {//yucong add for factory mode test support
        //LOGE(TAG"get thresheld low infr: %d(%s)\n", errno, strerror(errno));
	    ps_low = 0;
    }

    lps->als_raw = als_dat;
    lps->ps_raw = ps_dat;
    lps->ps_threshold_value = ps_threshold_dat;//yucong add for factory mode test support
    lps->ps_threshold_high = ps_high;//yucong add for factory mode test support
    lps->ps_threshold_low = ps_low;//yucong add for factory mode test support

	//add sensor data to struct sp_ata_data for PC side
	//return_data.alsps.als = lps->als_raw;
	//return_data.alsps.ps = lps->ps_raw;
	
    return 0;
}

static bool changeState = false;
static void *alsps_update_iv_thread(void *priv)
{
    struct lps_data *dat = (struct lps_data *)priv; 
    struct lps_priv *lps = &dat->lps;
    struct itemview *iv = dat->iv;
    lps->fd = -1;
    lps->dev = "/dev/als_ps";    
    int err = 0, len = 0;
    char *status;
    int cnt=0;
    int als_chkcnt = 0;
    int ps_chkcnt = 0;
    unsigned int alsv;
    unsigned int psv;

    LOGD(TAG "%s: Start\n", __FUNCTION__);
    if ((err = alsps_open(lps))) {
    	//memset(dat->info, 0x00, sizeof(dat->info));
        sprintf(alpsEntry.value.name,"%s",uistr_info_sensor_init_fail);
        //iv->redraw(iv);
        drawItemValueBehind(&alpsEntry);
        alpsEntry.state = TEST_FAIL;
		setProinfoItemResult(alpsEntry.id,alpsEntry.state);
        LOGE(TAG"alsps() err = %d(%s)\n", err, dat->info);
        return NULL;
    }
        
    while (thread_run) {
        
        if (isslpsopen ==0 || dat->exit_thd)
            break;
            
        if ((err = alsps_update_info(lps)))
            continue;     

        len = 0;
        len += snprintf(alpsEntry.value.name, sizeof(alpsEntry.value.name)-len, "ALS:%Xh\n", lps->als_raw);      
        len += snprintf(alpsEntry.value.name+len, sizeof(alpsEntry.value.name)-len, " PS:%Xh\n", lps->ps_raw);
		//check change als and ps value; by wubo
	 	if(cnt>1)
	 	{
		 	//LOGD(TAG "%s: ------>alsv:%d:%d------psv:%d:%d\n", __FUNCTION__,alsv,lps->als_raw,psv,lps->ps_raw);
		 	if(lps->als_raw != alsv)
	 		{ 			
				als_chkcnt++;
	 		}
			 if(lps->ps_raw!=psv)
		 	{
		 		ps_chkcnt++;
		 	}
			 if(!changeState && ps_chkcnt>4 && als_chkcnt>4)
		 	{
		 		//dat->mod->test_result = FTM_TEST_PASS;
				changeState = true;
	 			alpsEntry.value.color = GREENCOLOR;
		 		alpsEntry.state = TEST_PASS;
				setProinfoItemResult(alpsEntry.id,alpsEntry.state);
				LOGD(TAG "%s: PASS----------FTM_TEST_PASS---------\n", __FUNCTION__);
				//break;
		 	}
	 	}
	 	alsv = lps->als_raw;
	 	psv = lps->ps_raw;
	 
	 	cnt++;
        /*
		if(lps->ps_threshold_high == 0){
			len += snprintf(alpsEntry.value.name+len, sizeof(alpsEntry.value.name)-len, "%s: %s\n", uistr_info_sensor_alsps_thres_high, uistr_info_sensor_alsps_check_command);//yucong add for factory mode test support
		}else{
			len += snprintf(alpsEntry.value.name, sizeof(alpsEntry.value.name)-len, "%s: %4Xh\n", uistr_info_sensor_alsps_thres_high, lps->ps_threshold_high);	
		}
		if(lps->ps_threshold_low == 0){
			len += snprintf(alpsEntry.value.name, sizeof(alpsEntry.value.name)-len, "%s: %s\n", uistr_info_sensor_alsps_thres_low, uistr_info_sensor_alsps_check_command);//yucong add for factory mode test support
		}else{
			len += snprintf(alpsEntry.value.name, sizeof(alpsEntry.value.name)-len, "%s: %4Xh\n", uistr_info_sensor_alsps_thres_low, lps->ps_threshold_low);	
		}
		if(lps->ps_threshold_value == 2){
			len += snprintf(alpsEntry.value.name, sizeof(alpsEntry.value.name)-len, "%s: %s\n", uistr_info_sensor_alsps_result, uistr_info_sensor_alsps_check_command);//yucong add for factory mode test support
		}else{
			len += snprintf(alpsEntry.value.name, sizeof(alpsEntry.value.name)-len, "%s: %s\n", uistr_info_sensor_alsps_result, (lps->ps_threshold_value == 1)?uistr_info_sensor_pass:uistr_info_sensor_fail	);//yucong add for factory mode test support
		}
        */
        //iv->set_text(iv, &dat->text);
        //iv->redraw(iv);
		drawItemValueBehind(&alpsEntry);
        usleep(10000);
        /**
        pthread_mutex_lock (&alsps_mutex);
        if(sp_ata_status == FTM_AUTO_ITEM)
        { 
            alsps_thread_exit = true;  
            pthread_mutex_unlock (&alsps_mutex);
            break;
        }
        pthread_mutex_unlock (&alsps_mutex);
        **/
    }
    if (!changeState){
        alpsEntry.state = TEST_FAIL;
        setProinfoItemResult(alpsEntry.id,alpsEntry.state);
    }
    alsps_close(lps);
    LOGD(TAG "%s: Exit\n", __FUNCTION__);      
    return NULL;
}


int alsps_start()
{
    char *ptr;
    int chosen;
    struct lps_data *dat = (struct lps_data *)calloc(sizeof(struct lps_data),1);

    changeState = false;
    LOGD(TAG "%s\n", __FUNCTION__);

/*
    init_text(&dat->title, param->name, COLOR_YELLOW);
    init_text(&dat->text, &dat->info[0], COLOR_YELLOW);
    init_text(&dat->left_btn, uistr_info_sensor_fail, COLOR_YELLOW);
    init_text(&dat->center_btn, uistr_info_sensor_pass, COLOR_YELLOW);
    init_text(&dat->right_btn, uistr_info_sensor_back, COLOR_YELLOW);
 */
    thread_run = 1;
    snprintf(alpsEntry.value.name, sizeof(alpsEntry.value.name), uistr_info_sensor_initializing);
    drawItemValueBehind(&alpsEntry);
    dat->exit_thd = false;  

    pthread_create(&dat->update_thd, NULL, alsps_update_iv_thread, dat);
    pthread_join(dat->update_thd, NULL);
    if(dat!=NULL){
    	free(dat);
    }
    return 0;
}

extern int currentrow;
void * jlink_alps_start(void*para){
    int row = 0;
    if (para!=NULL)
    {
        row = *(int*)para;
    }
    drawTestItem(&alpsEntry);
    alsps_start();
    return NULL;
}

void stop_alps(){
    thread_run = 0;
}
