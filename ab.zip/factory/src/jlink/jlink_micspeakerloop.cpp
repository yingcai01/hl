
#include "../test/ftm_audio_Common.h"
#include "ftm.h"

extern "C" {
#include "DIF_FFT.h"
#include "jlinkui.h"
#include "Audio_FFT_Types.h"
#include "Audio_FFT.h"
};


#define TEXT_LENGTH (1024)
#define MAX_FILE_NAME_SIZE (100)
#define WAVE_PLAY_SLEEP_TIME (100)
#define FFT_DAT_MAXNUM 200
#define FFT_SIZE 4096
#define mod_to_mAudio(p)     (struct mAudio*)((char*)(p) + sizeof(struct ftm_module))

static char FileListNamesdcard[] = "/sdcard/factory.ini";
static char FileListName[]           = "/vendor/etc/factory.ini";
static char FileStartString_LoudspkPlayback[]      = "//AudioRingtonePlayFile";

static const char ouput_dev_name[3][16] = {"Receiver", "Headset", "Speaker"};
static int Receiver_Frequency[5] = {2000, 2500, 3000, 3500, 4000};
static int Speaker_Frequency[5] = {500, 750, 1000, 1500, 2000};
extern  sp_ata_data return_data;
extern struct mAudio
{
    struct ftm_module *mod;
    struct textview tv;
    struct itemview *iv;
    pthread_t hHeadsetThread;
    pthread_t hRecordThread;
    pthread_mutex_t mHeadsetMutex;
    int avail;
    int Headset_change;
    int Headset_mic;
    bool exit_thd;
    char  info[TEXT_LENGTH];
    char  file_name[MAX_FILE_NAME_SIZE];
    int   i4OutputType;
    int   i4Playtime;
    int  recordDevice;
    text_t    title;
    text_t    text;
    text_t    left_btn;
    text_t    center_btn;
    text_t    right_btn;
};

typedef enum {
    L_CH_ONLY,
    R_CH_ONLY,
    ALL_CH
} pass_channl_criteria_t;


static item_t audio_items_auto[] =
{
    { -1, NULL, 0, 0},
};

extern TestEntry micspkEntry;
static int testpass = 0;
static int FreqLoop = 0,FreqTestResult[5] = {0};

static const char * FileStartString_Speaker_FreqResponse[5] = {"//AudioSpeakerFreq05K", "//AudioSpeakerFreq075K", "//AudioSpeakerFreq1K", "//AudioSpeakerFreq15K", "//AudioSpeakerFreq2K"};

static float ConvertToDB(unsigned int *pData)
{
	float dBValue;

    if (*pData == 0)
        return 0;
    dBValue = 10*log10((float)pData[0]);
    return dBValue;
}

static int read_preferred_ringtone_freq(void)
{
    int freq = 0;
    char *pFreq = NULL;
    char uName[64];

    memset(uName, 0, sizeof(uName));
    sprintf(uName, "%s", "Freq.Ringtone");
    pFreq = ftm_get_prop(uName);
    if (pFreq != NULL)
    {
        freq = (int)atoi(pFreq);
        ALOGD("preferred_ringtone_freq: %d hz\n", freq);
    }
    else
    {
        ALOGE("preferred_ringtone_freq can't get\n");
    }

    if (freq <= 0)
    {
        freq = 1000;
        ALOGE("preferred_ringtone_freq not valid, return value freq = 1000\n");
    }

    return freq;
}

static int getFileNAmeSize(char buffer[])
{
    int length = 0;
    while (buffer[length] != '\0' &&  buffer[length] != '\n' &&  buffer[length] != '\r' && buffer[length] != ';')
    {
        //printf("buffer[%d] = %x \n",length,buffer[length]);
        length++;
    }
    return length;
}

static int read_preferred_sw_gain(void)
{
    int gain = 2; //default 2:12dB
    char *pGain = NULL;

    pGain = ftm_get_prop("Audio.SWGain");
    if (pGain != NULL){
        gain = (int)atoi(pGain);
        ALOGD("read_preferred_sw_gain: %d \n",gain);
    }
    else{
        ALOGD("read_preferred_sw_gain can't get\n");
    }
    return gain;
}


static int read_preferred_ringtone_time(void)
{
    int time = 0;
    char *pTime = NULL;
    char uName[64];

    memset(uName, 0, sizeof(uName));
    sprintf(uName, "%s", "Audio.Ringtone");
    pTime = ftm_get_prop(uName);
    if (pTime != NULL)
    {
        time = (int)atoi(pTime);
        ALOGD(TAG"preferred_ringtone_time: %d sec\n", time);
    }
    else
    {
    	time = 5;//配置文件中读取,未执行配置前默认
        ALOGD(TAG"preferred_ringtone_time can't get\n");
    }
    return time;
}


static void Audio_Wave_clear_WavePlayInstance(WavePlayData *pWaveInstance)
{
    if (pWaveInstance->FileName != NULL)
    {
        delete[] pWaveInstance->FileName;
        pWaveInstance->FileName = NULL;
    }
    printf("delete[] WavePlayInstance.FileName; \n");
    if (pWaveInstance->pFile != NULL)
    {
        fclose(pWaveInstance->pFile);
        pWaveInstance->pFile = NULL;
    }
    printf(" fclose(WavePlayInstance.pFile; \n");
    memset((void *)pWaveInstance, 0 , sizeof(WavePlayData) - sizeof(pthread_t));
    printf("memset((void*)&WavePlayInstance, 0 ,sizeof(WavePlayData) - sizeof(pthread_t)) \n");
}

static bool read_preferred_recorddump(void)
{
    char *pDump = NULL;
    char uName[64];

    memset(uName, 0, sizeof(uName));
    sprintf(uName, "%s", "Audio.Record.Dump");
    pDump = ftm_get_prop(uName);
    ALOGD("pDump:%s", pDump);

    if (pDump != NULL)
    {
        if (!strcmp(pDump, "1"))
        {
            ALOGD("Dump record data");
            return true;
        }
        else
        {
            ALOGD("No need to dump record data");
            return false;
        }
    }
    else
    {
        ALOGD("Dump record prop can't get");
        return false;
    }
}


static void CalculateStatistics(float *pData, int length, int start, int end, audio_data_statistic *data_stat)
{
    float sum = 0, mean = 0;
    float sq_sum = 0, std_dev = 0;
    float max = pData[start];
    float min = pData[start];
    int i = 0;

    //start: how many data ignored at the start
    //end:  how many data ignore at the end
    int len = length - start - end;

    //Calculate max, min and mean value
    for (i=start; i<length-end; i++)
    {
        if (pData[i] > max )
        {
            max = pData[i];
        }
        else if (pData[i] < min)
        {
            min = pData[i];
        }
        sum += pData[i];
    }
    mean = sum / len ;

    //Calculate deviation
    for (i=start; i<length-end; i++)
    {
        sq_sum += (pData[i]-mean) * (pData[i]-mean);
    }
    std_dev = sqrt(sq_sum / len);

    data_stat->mean = mean;
    data_stat->deviation = std_dev;
    data_stat->max = max;
    data_stat->min = min;
}

static void *Audio_Wave_Playabck_thread(void *mPtr)
{
    struct mAudio *hds  = (struct mAudio *)mPtr;
    struct itemview *iv = hds->iv;
    int wave_play_time  = hds->i4Playtime;

    ALOGD(TAG "%s: Start\n", __FUNCTION__);

    // for filelist and now read file
    FILE *pFileList = NULL;
    FILE *PReadFile = NULL;
    // buffer fir read filelist and file
    char FileNamebuffer[MAX_FILE_NAME_SIZE];
    int readlength = 0;
    bool FileListEnd = false;
    bool openfielerror = false;
    WavePlayData WavePlayInstance;
    memset((void *)&WavePlayInstance, 0 , sizeof(WavePlayData));
    LOGD("MYTEST here 4");
    //open input file  list
    pFileList = fopen(FileListNamesdcard, "rb");
    if (pFileList == NULL)
    {
    	LOGD("MYTEST here 4-1");
        printf("error reopen file %s\n", FileListNamesdcard);
        pFileList = fopen(FileListName, "rb");
        if (pFileList == NULL)
        {
            FileListEnd = true;
            openfielerror = true;
            printf("error opening file %s\n", FileListName);
        }
    }
    LOGD("MYTEST here 5");
    while (pFileList && !feof(pFileList) && (!hds->exit_thd))
    {
        char *CompareNamebuffer = NULL;
        int filelength = 0;
        int CompareResult = -1;
        memset((void *)FileNamebuffer, 0, MAX_FILE_NAME_SIZE);
        fgets(FileNamebuffer, 100, pFileList);

        // crop file name to waveplay data structure
        filelength = getFileNAmeSize(FileNamebuffer);
        LOGD("MYTEST getFileNAmeSize = %d\n", filelength);
        printf("getFileNAmeSize = %d\n", filelength);
        if (filelength > 0)
        {
            CompareNamebuffer = new char[filelength + 1];
            memset((void *)CompareNamebuffer, '\0', filelength + 1);
            memcpy((void *)CompareNamebuffer, (void *)FileNamebuffer, filelength);
            printf("get file list filename %s\n", FileNamebuffer);
            LOGD(TAG"get file list filename %s\n", FileNamebuffer);
            printf("get file list CompareNamebuffer %s\n", CompareNamebuffer);
            LOGD(TAG"get file list CompareNamebuffer %s\n", CompareNamebuffer);
            CompareResult = strcmp(CompareNamebuffer, hds->file_name);
            printf("CompareResult = %d \n", CompareResult);
            LOGD(TAG"CompareResult = %d \n", CompareResult);
        }

        if (CompareNamebuffer)
        {
            delete[] CompareNamebuffer;
            CompareNamebuffer = NULL;
        }

        if (CompareResult == 0)
        {
            printf("CompareResult ==0 \n");
            break;
        }
    }
    LOGD("MYTEST here 6");
    WavePlayInstance.i4Output = hds->i4OutputType;

    while (1)
    {
        if (openfielerror == true)
        {
            /* preare text view info */
            char *ptr;
            ptr = hds->info;
            ptr += sprintf(ptr, "%s", "error open ini file\n");
        }
        // read file list is not null
        while (((pFileList && !feof(pFileList) && FileListEnd == false) || (WavePlayInstance.ThreadStart == true)) && hds->exit_thd == false)
        {
            if (wave_play_time < 0)
            {
                WavePlayInstance.ThreadExit = true;
                goto WAVE_SLEEP;
            }
            if (WavePlayInstance.ThreadStart == false)
            {
                // clear all wave data.
                if (WavePlayInstance.ThreadExit == true && WavePlayInstance.ThreadStart == false)
                {
                    printf("WavePlayInstance.ThreadExit = true clean all data\n");
                    LOGD(TAG"WavePlayInstance.ThreadExit = true clean all data\n");
                    Audio_Wave_clear_WavePlayInstance(&WavePlayInstance);
                    WavePlayInstance.WavePlayThread = (pthread_t) NULL;
                }

                // get Filelist FileNamebuffer
                int filelength = 0;
                memset((void *)FileNamebuffer, 0, MAX_FILE_NAME_SIZE);
                if (pFileList != NULL)
                {
                    fgets(FileNamebuffer, 100, pFileList);
                }
                printf("get file list filename %s\n", FileNamebuffer);
                LOGD(TAG"get file list filename %s\n", FileNamebuffer);
                // crop file name to waveplay data structure
                filelength = getFileNAmeSize(FileNamebuffer);
                printf("getFileNAmeSize = %d\n", filelength);
                if (filelength > 0)
                {
                    WavePlayInstance.FileName = new char[filelength + 7 + 1];
                    memset((void *)WavePlayInstance.FileName, '\0', filelength + 7 + 1);
                    memcpy((void *)WavePlayInstance.FileName, "/vendor", 7);  // add prefix "/vendor"
                    memcpy((void *)((char *)WavePlayInstance.FileName + 7), (void *)FileNamebuffer, filelength);
                }
                printf("get filename %s\n", WavePlayInstance.FileName);
                LOGD(TAG"get filename %s\n", WavePlayInstance.FileName);
                // create audio playback rounte
                if (WavePlayInstance.WavePlayThread == (pthread_t) NULL)
                {
                    WavePlayInstance.ThreadStart = true ;
                    WavePlayInstance.ThreadExit = false ;
                    printf("Audio_Wave_playback\n");
                    LOGD(TAG"Audio_Wave_playback\n");
                    Audio_Wave_playback((void *)&WavePlayInstance);
                    printf("Audio_Wave_playback thread create\n");
                    LOGD(TAG"Audio_Wave_playback thread create\n");
                }
            }
            if (hds->exit_thd)
            {
                break;
            }
            

WAVE_SLEEP:
            usleep(WAVE_PLAY_SLEEP_TIME * 1000); // sleep 100 ms
            wave_play_time -= WAVE_PLAY_SLEEP_TIME ;
        }

        if (hds->exit_thd)
        {
            WavePlayInstance.ThreadExit = true;

            printf("+WavePlayInstance.ThreadStart = %d\n", WavePlayInstance.ThreadStart);
            LOGD(TAG"+WavePlayInstance.ThreadStart = %d\n", WavePlayInstance.ThreadStart);
            pthread_join(WavePlayInstance.WavePlayThread, NULL);
            printf("-WavePlayInstance.ThreadStart = %d\n", WavePlayInstance.ThreadStart);
            LOGD(TAG"-WavePlayInstance.ThreadStart = %d\n", WavePlayInstance.ThreadStart);
            
            // clear all wave data.
            if (WavePlayInstance.ThreadExit == true)
            {
                printf("WavePlayInstance.ThreadExit = true clean all data\n");
                LOGD(TAG"WavePlayInstance.ThreadExit = true clean all data\n");
                Audio_Wave_clear_WavePlayInstance(&WavePlayInstance);
            }
            break;
        }
        usleep(WAVE_PLAY_SLEEP_TIME * 1000); // sleep 100 ms
        //iv->set_text(iv, &hds->text);
        //iv->redraw(iv);
    }
    LOGD("MYTEST here 7");
    ALOGD(TAG "%s: Audio_Wave_Playabck_thread Exit \n", __FUNCTION__);
    pthread_exit(NULL); // thread exit
    return NULL;
}


static void * Audio_Response_Record_thread(void *mPtr)
{
    struct mAudio *hds  = (struct mAudio *)mPtr;
    ALOGD(TAG "%s: Start", __FUNCTION__);
    usleep(100000);
    int freqOfRingtone = read_preferred_ringtone_freq();
    int lowFreq = freqOfRingtone * (1-0.05);
    int highFreq = freqOfRingtone * (1+0.05);
    short pbuffer[8192]={0};
    short pbufferL[4096]={0};
	short pbufferR[4096]={0};
    unsigned int freqDataL[3]={0},magDataL[3]={0};
	unsigned int freqDataR[3]={0},magDataR[3]={0};
    int len = 0;
    float AmpDB = 0;
    float RspDB[FFT_DAT_MAXNUM];
    int swGain = read_preferred_sw_gain();
    audio_data_statistic rsp_sta;


    uint32_t sampleRate;
    recordInit(hds->recordDevice, &sampleRate);
    SetRecordEnhance(false);
    while (1) {
        memset(pbuffer,0,sizeof(pbuffer));
        memset(pbufferL,0,sizeof(pbufferL));
        memset(pbufferR,0,sizeof(pbufferR));

        int readSize  = readRecordData(pbuffer,8192*2);
        for(int i = 0 ; i < 4096 ; i++)
        {
           pbufferL[i] = pbuffer[2 * i] << swGain;     //apply +12db gain
           pbufferR[i] = pbuffer[2 * i + 1] << swGain; //apply +12db gain
        }

        memset(freqDataL,0,sizeof(freqDataL));
        memset(freqDataR,0,sizeof(freqDataR));
        memset(magDataL,0,sizeof(magDataL));
        memset(magDataR,0,sizeof(magDataR));
        ApplyFFT256(sampleRate,pbufferL,0,freqDataL,magDataL);
        ApplyFFT256(sampleRate,pbufferR,0,freqDataR,magDataR);

        //Calculate target tone peak value (dB)
        AmpDB = ConvertToDB(&magDataL[0]);
        ALOGD("freqDataL:%d, AmpDB:%f",freqDataL[0], AmpDB);

        RspDB[len] = AmpDB;
        len++;

        if (hds->exit_thd){
	       break;
	     }
      }
      CalculateStatistics(RspDB, len, 1, 1, &rsp_sta);
      ALOGD(TAG "Max:%f, Min:%f",rsp_sta.max, rsp_sta.min);
      ALOGD(TAG "Mean:%f, Deviation:%f",rsp_sta.mean, rsp_sta.deviation);

      if(rsp_sta.deviation < 0.5)
      {
          snprintf(hds->info + strlen(hds->info), sizeof(hds->info) - strlen(hds->info), "Check freq pass.\n");
          ALOGD(" @ info : %s",hds->info);
      }

      SetRecordEnhance(true);

      
      if(hds->i4OutputType == Output_LPK)//speaker
      {
          return_data.spk_response.freqresponse[FreqLoop].mean = rsp_sta.mean;
          return_data.spk_response.freqresponse[FreqLoop].deviation = rsp_sta.deviation;
          return_data.spk_response.freqresponse[FreqLoop].max = rsp_sta.max;
          return_data.spk_response.freqresponse[FreqLoop].min = rsp_sta.min;

          ALOGD(TAG "Frequency Response(Speaker) at %d Hz: %f", Speaker_Frequency[FreqLoop], return_data.spk_response.freqresponse[FreqLoop].mean);
      }
      else if(hds->i4OutputType == Output_HS)
      {
          return_data.rcv_response.freqresponse[FreqLoop].mean = rsp_sta.mean;
          return_data.rcv_response.freqresponse[FreqLoop].deviation = rsp_sta.deviation;
          return_data.rcv_response.freqresponse[FreqLoop].max = rsp_sta.max;
          return_data.rcv_response.freqresponse[FreqLoop].min = rsp_sta.min;
          ALOGD(TAG "Frequency Response(Receiver) at %d Hz: %f", Receiver_Frequency[FreqLoop], return_data.rcv_response.freqresponse[FreqLoop].mean);
      }

      ALOGD(TAG "%s: Stop", __FUNCTION__);
      pthread_exit(NULL); // thread exit
      return NULL;
}

static void read_preferred_magnitude(const int device, int *pUpperL, int *pLowerL, int *pUpperR, int *pLowerR)
{
    char *pMagLowerL = NULL, *pMagUpperL = NULL;
    char *pMagLowerR = NULL, *pMagUpperR = NULL;
    char uMagLowerL[64], uMagUpperL[64];
    char uMagLowerR[64], uMagUpperR[64];

    memset(uMagLowerL, 0, sizeof(uMagLowerL));
    memset(uMagUpperL, 0, sizeof(uMagUpperL));
    memset(uMagLowerR, 0, sizeof(uMagLowerR));
    memset(uMagUpperR, 0, sizeof(uMagUpperR));

    if (device == Output_LPK) //speaker
    {
        sprintf(uMagLowerL, "%s", "Lower.Magnitude.Speaker.L");
        sprintf(uMagUpperL, "%s", "Upper.Magnitude.Speaker.L");
        sprintf(uMagLowerR, "%s", "Lower.Magnitude.Speaker.R");
        sprintf(uMagUpperR, "%s", "Upper.Magnitude.Speaker.R");
    }
    else if (device == Output_HS) //receiver
    {
        sprintf(uMagLowerL, "%s", "Lower.Magnitude.Receiver.L");
        sprintf(uMagUpperL, "%s", "Upper.Magnitude.Receiver.L");
        sprintf(uMagLowerR, "%s", "Lower.Magnitude.Receiver.R");
        sprintf(uMagUpperR, "%s", "Upper.Magnitude.Receiver.R");
    }

    pMagLowerL = ftm_get_prop(uMagLowerL);
    pMagUpperL = ftm_get_prop(uMagUpperL);
    pMagLowerR = ftm_get_prop(uMagLowerR);
    pMagUpperR = ftm_get_prop(uMagUpperR);
    if (pMagLowerL != NULL && pMagUpperL != NULL && pMagLowerR != NULL && pMagUpperR != NULL)
    {
        *pLowerL = (int)atoi(pMagLowerL);
        *pUpperL = (int)atoi(pMagUpperL);
        *pLowerR = (int)atoi(pMagLowerR);
        *pUpperR = (int)atoi(pMagUpperR);
        ALOGD("read_preferred_magnitude: [%s] Lower.Magnitude.L:%d,Upper.Magnitude.L:%d\n", ouput_dev_name[device], *pLowerL, *pUpperL);
        ALOGD("read_preferred_magnitude: [%s] Lower.Magnitude.R:%d,Upper.Magnitude.R:%d\n", ouput_dev_name[device], *pLowerR, *pUpperR);
    }
    else
    {
        ALOGD("[Warning] Read Parameters Failed: Lower/Upper.Magnitude parameters in factory.ini\n");
        ALOGD("[Warning] \t%s, %s, %s, %s", uMagLowerL, uMagUpperL, uMagLowerR, uMagUpperR);
        ALOGD("[Warning] Using default parameters");
        *pLowerL = (device == Output_LPK) ? 1000000 : 100;
        *pUpperL = 1000000000;
        *pLowerR = (device == Output_LPK) ? 500000 : 1000;
        *pUpperR = 1000000000;
        ALOGD("\tDefault %s = %d", uMagLowerL, *pLowerL);
        ALOGD("\tDefault %s = %d", uMagUpperL, *pUpperL);
        ALOGD("\tDefault %s = %d", uMagLowerR, *pLowerR);
        ALOGD("\tDefault %s = %d", uMagUpperR, *pUpperR);
    }
}

static pass_channl_criteria_t read_preferred_ch_to_check(const int device)
{
    pass_channl_criteria_t chToCheck;
    char *pChToCheck = NULL;
    char uName[64];

    memset(uName, 0, sizeof(uName));
    if (device == Output_LPK) //speaker
    {
        sprintf(uName, "%s", "Loopback.Speaker.chToCheck");
    }
    else if (device == Output_HS) //receiver
    {
        sprintf(uName, "%s", "Loopback.Receiver.chToCheck");
    }

    pChToCheck = ftm_get_prop(uName);
    if (pChToCheck != NULL)
    {
        if (strcmp(pChToCheck, "L") == 0)
        {
            chToCheck = L_CH_ONLY;
        }
        else if (strcmp(pChToCheck, "R") == 0)
        {
            chToCheck = R_CH_ONLY;
        }
        else if (strcmp(pChToCheck, "ALL") == 0)
        {
            chToCheck = ALL_CH;
        }
        else
        {
           ALOGD("[ERROR] given parameter not recognized");
           ALOGD("\t, available option: L, R, ALL");
           ALOGD("\t use default option: ALL");
           chToCheck = ALL_CH;
        }
        ALOGD("read_preferred_ch_to_check: %s\n", pChToCheck);
    }
    else
    {
        ALOGD("[Warning] read_preferred_ch_to_check: can't get parameter\n");
        ALOGD("\t: %s", uName);
        ALOGD("\t use default option: ALL");
        chToCheck = (device == Output_LPK) ? ALL_CH : R_CH_ONLY;
        ALOGD("[Warning] Using default parameters");
        ALOGD("\tDefault %s = %s", uName, (device == Output_LPK) ? "ALL" : "R");
    }
    
    return chToCheck;
}

static void *Audio_Record_thread(void *mPtr)
{
    struct mAudio *hds  = (struct mAudio *)mPtr;
    ALOGD(TAG "%s: Start", __FUNCTION__);
    usleep(100000);
    bool dumpFlag = read_preferred_recorddump();
    //dumpFlag=true;//for test
    int magLowerL, magUpperL;
    int magLowerR, magUpperR;
    read_preferred_magnitude(hds->i4OutputType, &magUpperL, &magLowerL, &magUpperR, &magLowerR);
    pass_channl_criteria_t chToCheck = read_preferred_ch_to_check(hds->i4OutputType);
    int freqOfRingtone = read_preferred_ringtone_freq();
    int lowFreq = freqOfRingtone * (1 - 0.05);
    int highFreq = freqOfRingtone * (1 + 0.05);
    short *pbuffer, *pbufferL, *pbufferR;
    unsigned int freqDataL[3] = {0}, magDataL[3] = {0};
    unsigned int freqDataR[3] = {0}, magDataR[3] = {0};
    int checkCnt = 0;
    uint32_t samplerate = 0;
    if(dumpFlag){
    	LOGD("==MYTEST==  dumpFlag=true");
    }else{
    	LOGD("==MYTEST==  dumpFlag=false");
    }
    LOGD("==MYTEST==  freqOfRingtone=%d",freqOfRingtone);
    LOGD("==MYTEST==  lowFreq=%d",lowFreq);
    LOGD("==MYTEST==  highFreq=%d",highFreq);
    LOGD("==MYTEST==  hds->i4OutputType=%d",hds->i4OutputType);
    LOGD("==MYTEST==  magUpperL=%d",magUpperL);
    LOGD("==MYTEST==  magLowerL=%d",magLowerL);
    LOGD("==MYTEST==  magUpperR=%d",magUpperR);
    LOGD("==MYTEST==  magLowerR=%d",magLowerR);
    if (hds->i4OutputType == Output_LPK) //speaker
    {
        return_data.speaker.freqL = 0;
        return_data.speaker.freqR = 0;
        return_data.speaker.amplL = 0;
        return_data.speaker.amplR = 0;
    }
    else if (hds->i4OutputType == Output_HS)
    {
        return_data.receiver.freqL = 0;
        return_data.receiver.freqR = 0;
        return_data.receiver.amplL = 0;
        return_data.receiver.amplR = 0;
    }

    pbuffer = (short *)malloc(8192 * sizeof(short));
    if (pbuffer == NULL) {
        ALOGE(TAG "%s: pbuffer allocate fail !!", __FUNCTION__);
        return NULL;
    }

    pbufferL = (short *)malloc(4096 * sizeof(short));
    if (pbufferL == NULL) {
        ALOGE(TAG "%s: pbufferL allocate fail !!", __FUNCTION__);
        free(pbuffer);
        return NULL;
    }

    pbufferR = (short *)malloc(4096 * sizeof(short));
    if (pbufferR == NULL) {
        ALOGE(TAG "%s: pbufferR allocate fail !!", __FUNCTION__);
        free(pbuffer);
        free(pbufferL);
        return NULL;
    }
    LOGD("MYTEST here 9");
    recordInit(hds->recordDevice, &samplerate);
    LOGD("==MYTEST==  samplerate=%d",samplerate);
	int jcount = 0;
    while (1)
    {
    	//LOGD("MYTEST here 9-00");
        memset(pbuffer,  0, 8192 * sizeof(short));
        memset(pbufferL, 0, 4096 * sizeof(short));
        memset(pbufferR, 0, 4096 * sizeof(short));
        //LOGD("MYTEST here 9-01");
        int readSize  = readRecordData(pbuffer, 8192 * 2);
        //LOGD("MYTEST here 9-02");
        for (int i = 0 ; i < 4096 ; i++)
        {
            pbufferL[i] = pbuffer[2 * i];
            pbufferR[i] = pbuffer[2 * i + 1];
        }
        //LOGD("MYTEST here 9-1");
        if (dumpFlag)
        {
            char filenameL[] = "/data/record_dataL.pcm";
            char filenameR[] = "/data/record_dataR.pcm";
            FILE *fpL = fopen(filenameL, "wb+");
            FILE *fpR = fopen(filenameR, "wb+");

            if (fpL != NULL)
            {
                fwrite(pbufferL, readSize / 2, 1, fpL);
                fclose(fpL);
            }

            if (fpR != NULL)
            {
                fwrite(pbufferR, readSize / 2, 1, fpR);
                fclose(fpR);
            }
        }
        //LOGD("MYTEST here 9-2");
        memset(freqDataL, 0, sizeof(freqDataL));
        memset(freqDataR, 0, sizeof(freqDataR));
        memset(magDataL, 0, sizeof(magDataL));
        memset(magDataR, 0, sizeof(magDataR));
        ApplyFFT256(samplerate, pbufferL, 0, freqDataL, magDataL);
        ApplyFFT256(samplerate, pbufferR, 0, freqDataR, magDataR);
        for (int i = 0; i < 3 ; i ++)
        {
            SLOGV("%d.freqDataL[%d]:%d,magDataL[%d]:%d", i, i, freqDataL[i], i, magDataL[i]);
            SLOGV("%d.freqDataR[%d]:%d,magDataR[%d]:%d", i, i, freqDataR[i], i, magDataR[i]);
        }
    	//LOGD("MYTEST here 9-3");
	if (chToCheck == ALL_CH && ((freqDataL[0] <= (unsigned int)highFreq && freqDataL[0] >= (unsigned int)lowFreq) && (magDataL[0] <= (unsigned int)magUpperL && magDataL[0] >= (unsigned int)magLowerL)) && ((freqDataR[0] <= (unsigned int)highFreq && freqDataR[0] >= (unsigned int)lowFreq) && (magDataR[0] <= (unsigned int)magUpperR && ((magDataR[0] >= magDataL[0]/100) || ( magDataR[0] >= (unsigned int)magLowerR)))))
        {
            ALOGD(TAG"chToCheck = ALL_CH");
            checkCnt ++;
            ALOGD(TAG"[%s] checkCnt[%d], freqDataL:%d,magDataL:%d,freqDataR:%d,magDataR:%d", ouput_dev_name[hds->i4OutputType], checkCnt, freqDataL[0], magDataL[0], freqDataR[0], magDataR[0]);
        }
        else if (chToCheck == L_CH_ONLY && ((freqDataL[0] <= (unsigned int)highFreq && freqDataL[0] >= (unsigned int)lowFreq) && (magDataL[0] <= (unsigned int)magUpperL && magDataL[0] >= (unsigned int)magLowerL)))
        {
            ALOGD(TAG"chToCheck = L_CH_ONLY");
            checkCnt ++;
            ALOGD(TAG"[%s] checkCnt[%d], freqDataL:%d,magDataL:%d,freqDataR:%d,magDataR:%d", ouput_dev_name[hds->i4OutputType], checkCnt, freqDataL[0], magDataL[0], freqDataR[0], magDataR[0]);
        }
        else if (chToCheck == R_CH_ONLY 
&& ((freqDataR[0] <= (unsigned int)highFreq && freqDataR[0] >= (unsigned int)lowFreq) && (magDataR[0] <= (unsigned int)magUpperR && magDataR[0] >= (unsigned int)magLowerR)))
        {
            ALOGD("chToCheck = R_CH_ONLY");
            checkCnt ++;
            ALOGD("[%s] checkCnt[%d], freqDataL:%d,magDataL:%d,freqDataR:%d,magDataR:%d", ouput_dev_name[hds->i4OutputType], checkCnt, freqDataL[0], magDataL[0], freqDataR[0], magDataR[0]);
        }
        else
        {
            checkCnt = 0;
            ALOGD(TAG"[%s] FAIL, checkCnt reset [%d], freqDataL:%d,magDataL:%d,freqDataR:%d,magDataR:%d", ouput_dev_name[hds->i4OutputType], checkCnt, freqDataL[0], magDataL[0], freqDataR[0], magDataR[0]);
        }
        //LOGD("MYTEST here 9-4");
        //麦克和扬声器相隔很远
        if (magDataL[0] > 1000 && magDataR[0] > 1000){
            jcount++;
        }

        if (checkCnt >= 5 || jcount >=5)
        {
            snprintf(hds->info, sizeof(hds->info), "Check freq pass.\n");
            ALOGD(TAG" @ info : %s", hds->info);
            break;
        }
        //LOGD("MYTEST here 9-5");
        if (hds->exit_thd)
        {
            break;
        }
    }

    if (hds->i4OutputType == Output_LPK) //speaker
    {
        return_data.speaker.freqL = freqDataL[0];
        return_data.speaker.freqR = freqDataR[0];
        return_data.speaker.amplL = magDataL[0];
        return_data.speaker.amplR = magDataR[0];
        ALOGD(TAG "ATA Return Data(Speaker): FreqL = %d, FreqR = %d, AmpL = %d, AmpR = %d", return_data.speaker.freqL, return_data.speaker.freqR, return_data.speaker.amplL, return_data.speaker.amplR);
    }
    else if (hds->i4OutputType == Output_HS)
    {
        return_data.receiver.freqL = freqDataL[0];
        return_data.receiver.freqR = freqDataR[0];
        return_data.receiver.amplL = magDataL[0];
        return_data.receiver.amplR = magDataR[0];
        ALOGD(TAG "ATA Return Data(Receiver): FreqL = %d, FreqR = %d, AmpL = %d, AmpR = %d", return_data.receiver.freqL, return_data.receiver.freqR, return_data.receiver.amplL, return_data.receiver.amplR);
    }

    LOGD("MYTEST here 10");
    free(pbuffer);
    free(pbufferL);
    free(pbufferR);

    ALOGD(TAG "%s: Stop", __FUNCTION__);
    pthread_exit(NULL); // thread exit
    return NULL;
}


static int mAudio_loopback_phonemicspk_auto(TestEntry* micspkentry,struct mAudio*mc)
{
    char *ptr;
    int chosen;
    bool exit = false;
    //struct mAudio *mc = (struct mAudio *)priv;

    ALOGD(TAG "--------------mAudio_entry----------------\n");
    ALOGD(TAG "%s\n", __FUNCTION__);

    // init Audio
    Common_Audio_init();
    mc->exit_thd = false;


    LOGD("MYTEST here 1");
    memset(mc->info, 0, sizeof(mc->info) / sizeof(*(mc->info)));
    memset(mc->file_name, 0, MAX_FILE_NAME_SIZE);
    strcpy(mc->file_name, FileStartString_LoudspkPlayback);
    mc->i4OutputType = Output_LPK;
    mc->i4Playtime = read_preferred_ringtone_time() * 1000; //ms
    //mc->recordDevice = BUILTIN_MIC;   //Yi-Lung: Record device is selected in function init.
    LOGD("MYTEST here 2");
    pthread_create(&mc->hHeadsetThread, NULL, Audio_Wave_Playabck_thread, mc);
    pthread_create(&mc->hRecordThread, NULL, Audio_Record_thread, mc);
    LOGD("MYTEST here 3");
    int    play_time = mc->i4Playtime;
    LOGD("MYTEST ====play_time=%d=====",play_time);
    //mc->mod->test_result = FTM_TEST_FAIL;
    testpass = 0;
    for (int i = 0; i < 100 ; i ++)
    {
        if (strstr(mc->info, "Check freq pass"))
        {
            //mc->mod->test_result = FTM_TEST_PASS;
            testpass = 1;
            ALOGD("Check freq pass");
            break;
        }
        usleep(play_time * 10);
    }

    if (testpass == 0)
    {
        ALOGD("Check freq fail");
        micspkentry->value.color = REDCOLOR;
        strcpy(micspkentry->value.name,"Check freq fail");
    }
    else if (testpass == 1)
    {
        micspkentry->value.color = GREENCOLOR;
    	strcpy(micspkentry->value.name,"Check freq sucess");
        usleep(2000000);
    }
	 if (testpass) {
        micspkEntry.state = TEST_PASS;
        micspkEntry.value.color = GREENCOLOR;
        ALOGD("loopback_phonemicspk PASS\n");
    } else {
        micspkEntry.state  = TEST_FAIL;
        micspkEntry.value.color = REDCOLOR;
        ALOGD("loopback_phonemicspk FAIL\n");
    }
	
    drawItemValueBehind(micspkentry);
	setProinfoItemResult(micspkEntry.id,micspkEntry.state);
    mc->exit_thd = true;
    pthread_join(mc->hRecordThread, NULL);
    pthread_join(mc->hHeadsetThread, NULL);
    Common_Audio_deinit();

    LOGD(TAG "%s: End\n", __FUNCTION__);

    return 0;
}

static int mAudio_speaker_freqresponse_entry(TestEntry* micspkentry,void *priv)
{
    char *ptr;
    int chosen;
    bool exit = false;
    struct mAudio*mc = (struct mAudio *)priv;
    struct textview *tv;
    struct itemview *iv;

    ALOGD(TAG "--------------mAudio_speaker_freqresponse_entry----------------\n" );
    ALOGD(TAG "%s\n", __FUNCTION__);

    memset(return_data.spk_response.freqresponse, 0, sizeof(ftm_ata_freq_response));

    for(FreqLoop = 0; FreqLoop < 5; FreqLoop++)
    {
        // init ATA return data
        //return_data.spk_response.freqresponse[FreqLoop]=0;

        // init Audio
        Common_Audio_init();
        mc->exit_thd = false;
        /*
        if (!mc->iv) {
            iv = ui_new_itemview();
            if (!iv) {
                ALOGD(TAG "No memory");
                return -1;
            }
            mc->iv = iv;
        }
        iv = mc->iv;
        iv->set_title(iv, &mc->title);
        iv->set_items(iv, audio_items_auto, 0);
        iv->set_text(iv, &mc->text);
        iv->start_menu(iv,0);
        iv->redraw(iv);
		*/
        memset(mc->info, 0, sizeof(mc->info) / sizeof(*(mc->info)));
        memset(mc->file_name,0,MAX_FILE_NAME_SIZE);
        strcpy(mc->file_name,FileStartString_Speaker_FreqResponse[FreqLoop]);
        mc->i4OutputType = Output_LPK;
        mc->i4Playtime = 2*read_preferred_ringtone_time()*1000/5;//ms
        pthread_create(&mc->hHeadsetThread, NULL, Audio_Wave_Playabck_thread, priv);
        pthread_create(&mc->hRecordThread, NULL, Audio_Response_Record_thread, priv);

        int play_time = mc->i4Playtime*5/2;
        FreqTestResult[FreqLoop] = FTM_TEST_FAIL;

        for(int i = 0; i < 40; i ++)
        {
          //if (strstr(mc->info, "Check freq pass"))
          //{
          //    FreqTestResult[FreqLoop] = FTM_TEST_PASS;
          //    ALOGD("Check freq pass");
          //    break;
          //}
          usleep(play_time * 10); //100ms
        }

        //if(FreqTestResult[FreqLoop] == FTM_TEST_FAIL)
        //   ALOGD("Check freq fail");
        //if(FreqTestResult[FreqLoop] == FTM_TEST_PASS)
        //    usleep(2000000);

        mc->exit_thd = true;
        pthread_join(mc->hRecordThread, NULL);
        pthread_join(mc->hHeadsetThread, NULL);

        if (strstr(mc->info, "Check freq pass"))
        {
            FreqTestResult[FreqLoop] = FTM_TEST_PASS;
            ALOGD("Check freq pass");
        }

        if(FreqTestResult[FreqLoop] == FTM_TEST_FAIL){
           ALOGD("Check freq fail");
           
        }
        
        Common_Audio_deinit();
    }

    //check result
    int failCnt = 0;
    for(int i=0;i<5;i++)
    {
        if(FreqTestResult[i] == FTM_TEST_FAIL)
        {
            failCnt++;
            ALOGD("[Speaker] Check freq response fail at %d Hz.", Receiver_Frequency[i]);
        }
    }
    if(!failCnt){
        testpass = 1;
        micspkentry->state = TEST_PASS;
        strcpy(micspkentry->value.name,"Check freq pass");
    }
    else{
        testpass = 0;
        micspkentry->state = TEST_FAIL;
        strcpy(micspkentry->value.name,"Check freq fail");
    }
    drawItemValueBehind(micspkentry);
    setProinfoItemResult(micspkentry->id,micspkentry->state);
    LOGD(TAG "%s: End\n", __FUNCTION__);
    return 0;
}

static float CalculateTHD(unsigned int sampleRate, short *pData, kal_uint32 signalFrequency, float frequencyMargin)
{
    unsigned int baseI = FFT_SIZE/2 * 2 * signalFrequency / sampleRate;
    unsigned int iMargin = baseI * frequencyMargin;
    unsigned int baseSignalLoc, peakLoc, baseSignalMag = 0, peakMagValue = 0;
    unsigned int IdxStart = 0;
    unsigned int magData[FFT_SIZE/2];
    kal_uint32 freqData[3] = {0};
    kal_uint32 HFreq[6] = {0}, HData[6] = {0}, P0 =0, Pothers = 0;
    kal_uint32 i, j, k;
    float dFreqIdx = (float)sampleRate/FFT_SIZE;
    float thdPercentage;

    Complex ComData[FFT_SIZE];
    ApplyFFT(sampleRate, pData, 0, ComData, freqData, magData);

    //Search base signal frequency location
    for (i=baseI-2; i<=baseI+2; i++)
    {
        if (magData[i] > baseSignalMag)
        {
            baseSignalLoc = i;
            baseSignalMag = magData[i];
        }
    }

    //Search peak signal frequency location
    for (i=IdxStart; i<FFT_SIZE/2; i++)
    {
        if (magData[i] > peakMagValue)
        {
            peakLoc = i;
            peakMagValue = magData[i];
        }
    }

    if (baseSignalLoc != peakLoc)
    {
        ALOGD("ERROR Wrong peak signal, baseSignalLoc:%d, peakLoc:%d", baseSignalLoc, peakLoc);
        return 0;
    }

    HFreq[0] = baseSignalLoc * dFreqIdx;
    HData[0] = baseSignalMag;
    P0 = baseSignalMag;

    ALOGD("baseSignalLoc:%d, P0:%d, iMargin:%d", baseSignalLoc, P0, iMargin);
    ALOGD("HFreq[%d]:%d,HData[%d]:%d", 0, HFreq[0], 0, HData[0]);

    //Search  ith harmonic signal frequency location and caculate rms power
    if (baseSignalLoc != 0)
    {
        unsigned int multiBaseSignalLoc = 0, multiBaseSignalMag = 0;
        k = 1;
        for (i=baseSignalLoc*2; i<FFT_SIZE/2; i+=baseSignalLoc)
        {
            multiBaseSignalMag = 0;

            //search local peak
            for (j=i-3; j<=i+3; j++)
            {
                if (j >= FFT_SIZE/2) break;
                if (magData[j] > multiBaseSignalMag)
                {
                    multiBaseSignalLoc = j;
                    multiBaseSignalMag = magData[j];
                }
                //ALOGD("HFreq[%d]:%d,HData[%d]:%d", j ,(unsigned int)(j * dFreqIdx), j, magData[j]);
            }


            for (j = multiBaseSignalLoc- iMargin; j <= multiBaseSignalLoc+ iMargin; j++)
            {
                Pothers += magData[j];
            }
            if (k < 6)
            {
                ALOGD("HFreq[%d]:%d,HData[%d]:%d", k, (unsigned int)(multiBaseSignalLoc * dFreqIdx), k, magData[multiBaseSignalLoc]);
            }
            k++;
        }
        //Pothers = sqrt(Pothers);
        ALOGD("Pothers:%d", Pothers);
    }

    thdPercentage = ((float)Pothers/P0) * 100;
    return thdPercentage;
}


static void * Audio_THD_Record_thread(void *mPtr)
{
    struct mAudio *hds  = (struct mAudio *)mPtr;
    ALOGD(TAG "%s: Start", __FUNCTION__);
    usleep(100000);
    int freqOfRingtone = read_preferred_ringtone_freq();
    int lowFreq = freqOfRingtone * (1-0.05);
    int highFreq = freqOfRingtone * (1+0.05);
    short pbuffer[8192]={0};
    short pbufferL[4096]={0};
	short pbufferR[4096]={0};
    unsigned int freqDataL[3]={0},magDataL[3]={0};
	unsigned int freqDataR[3]={0},magDataR[3]={0};
    float thdPercentage = 0;
    int len = 0;
    float thdData[FFT_DAT_MAXNUM];
    audio_data_statistic thd_sta;

    uint32_t sampleRate;
    recordInit(hds->recordDevice, &sampleRate);
    //SetRecordEnhance(false);
    while (1) {
        memset(pbuffer,0,sizeof(pbuffer));
        memset(pbufferL,0,sizeof(pbufferL));
        memset(pbufferR,0,sizeof(pbufferR));

        int readSize  = readRecordData(pbuffer,8192*2);
        for(int i = 0 ; i < 4096 ; i++)
        {
           pbufferL[i] = pbuffer[2 * i];
           pbufferR[i] = pbuffer[2 * i + 1];
        }

        memset(freqDataL,0,sizeof(freqDataL));
        memset(freqDataR,0,sizeof(freqDataR));
        memset(magDataL,0,sizeof(magDataL));
        memset(magDataR,0,sizeof(magDataR));
        ApplyFFT256(sampleRate,pbufferL,0,freqDataL,magDataL);
        ApplyFFT256(sampleRate,pbufferR,0,freqDataR,magDataR);


        for(int i = 0;i < 3 ;i ++)
        {
            ALOGD("freqDataL[%d]:%d,magDataL[%d]:%d",i,freqDataL[i],i,magDataL[i]);
            ALOGD("freqDataR[%d]:%d,magDataR[%d]:%d",i,freqDataR[i],i,magDataR[i]);
        }

	    //if (((freqDataL[0] <= highFreq && freqDataL[0] >= lowFreq) && (magDataL[0] <= magUpper && magDataL[0] >= magLower))&&((freqDataR[0] <= highFreq && freqDataR[0] >= lowFreq) && (magDataR[0] <= magUpper && magDataR[0] >= magLower)))
	    {
            thdPercentage = CalculateTHD(sampleRate, pbufferL, freqOfRingtone, 0.0);
            ALOGD("THD: %f", thdPercentage);
            thdData[len] = thdPercentage;
            len++;
        }

        if (hds->exit_thd){
	       break;
	     }
      }

      CalculateStatistics(thdData, len, 4, 1, &thd_sta);
      ALOGD(TAG "Max:%f, Min:%f",thd_sta.max, thd_sta.min);
      ALOGD(TAG "Mean:%f, Deviation:%f",thd_sta.mean, thd_sta.deviation);

      if(thd_sta.deviation < 0.5)
      {
          snprintf(hds->info + strlen(hds->info), sizeof(hds->info) - strlen(hds->info), "Check THD pass.\n");
          ALOGD(" @ info : %s",hds->info);
      }

      //SetRecordEnhance(true);

      if(hds->i4OutputType == Output_LPK)//speaker
      {
         return_data.spk_thd.thd.mean = thd_sta.mean;
         return_data.spk_thd.thd.deviation = thd_sta.deviation;
         return_data.spk_thd.thd.max = thd_sta.max;
         return_data.spk_thd.thd.min = thd_sta.min;
         ALOGD(TAG "ATA Return THD(Speaker): Mean = %f, Deviation = %f, Max = %f, Min = %f", return_data.spk_thd.thd.mean, return_data.spk_thd.thd.deviation, return_data.spk_thd.thd.max, return_data.spk_thd.thd.min);
      }
      else if(hds->i4OutputType == Output_HS)
      {
         return_data.rcv_thd.thd.mean = thd_sta.mean;
         return_data.rcv_thd.thd.deviation = thd_sta.deviation;
         return_data.rcv_thd.thd.max = thd_sta.max;
         return_data.rcv_thd.thd.min = thd_sta.min;
         ALOGD(TAG "ATA Return THD(Receiver): Mean = %f, Deviation = %f, Max = %f, Min = %f", return_data.rcv_thd.thd.mean, return_data.rcv_thd.thd.deviation, return_data.rcv_thd.thd.max, return_data.rcv_thd.thd.min);
      }
      
      ALOGD(TAG "%s: Stop", __FUNCTION__);
      pthread_exit(NULL); // thread exit
      return NULL;
}

static int mAudio_speaker_thd_entry(TestEntry* micspkentry,void *priv)
{
    char *ptr;
    int chosen;
    bool exit = false;
    struct mAudio*mc = (struct mAudio *)priv;
    struct textview *tv;
    struct itemview *iv;

    ALOGD(TAG "--------------mAudio_speaker_thd_entry----------------\n" );
    ALOGD(TAG "%s\n", __FUNCTION__);


    // init Audio
    Common_Audio_init();
    mc->exit_thd = false;
/*
    if (!mc->iv) {
        iv = ui_new_itemview();
        if (!iv) {
            ALOGD(TAG "No memory");
            return -1;
        }
        mc->iv = iv;
    }
    iv = mc->iv;
    iv->set_title(iv, &mc->title);
    iv->set_items(iv, audio_items_auto, 0);
    iv->set_text(iv, &mc->text);
	iv->start_menu(iv,0);
    iv->redraw(iv);
*/
    memset(mc->info, 0, sizeof(mc->info) / sizeof(*(mc->info)));
    memset(mc->file_name,0,MAX_FILE_NAME_SIZE);
    strcpy(mc->file_name,FileStartString_LoudspkPlayback);
    mc->i4OutputType = Output_LPK;
	mc->i4Playtime = 2*read_preferred_ringtone_time()*1000/5;//ms
    pthread_create(&mc->hHeadsetThread, NULL, Audio_Wave_Playabck_thread, priv);
    pthread_create(&mc->hRecordThread, NULL, Audio_THD_Record_thread, priv);

    int play_time = mc->i4Playtime*5/2;
    testpass = 0;

    for(int i = 0; i < 40 ; i ++)
    {
      //if (strstr(mc->info, "Check freq pass"))
      //{
      //    mc->mod->test_result = FTM_TEST_PASS;
      //    ALOGD("Check freq pass");
      //    break;
      //}
      usleep(play_time * 10); //50ms
    }

    //if(mc->mod->test_result == FTM_TEST_FAIL)
    //   ALOGD("Check freq fail");
    //if(mc->mod->test_result == FTM_TEST_PASS)
    //    usleep(2000000);

    mc->exit_thd = true;
    pthread_join(mc->hRecordThread, NULL);
    pthread_join(mc->hHeadsetThread, NULL);

    if (strstr(mc->info, "Check THD pass"))
    {
        testpass = 1;
        ALOGD("Check THD pass");
        strcpy(micspkentry->value.name,"Check THD pass");
        micspkentry->state = TEST_PASS;
    }else{
    	strcpy(micspkentry->value.name,"Check THD fail");
    	micspkentry->state = TEST_FAIL;
    }
    drawItemValueBehind(micspkentry);
    Common_Audio_deinit();
    setProinfoItemResult(micspkentry->id,micspkentry->state);
    LOGD(TAG "%s: End\n", __FUNCTION__);

    return 0;
}


static int mAudio_loopback_phonemicspk_entry(TestEntry *micspkentry)
{
    struct mAudio *mc = (struct mAudio *)malloc(sizeof(struct mAudio));
    char *outputType = NULL;

    strcpy(micspkEntry.value.name, uistr_info_testing);
    drawItemValueBehind(&micspkEntry);
    outputType = ftm_get_prop("Audio.Auto.OutputType");
    ALOGD("Audio.Auto.OutputType = %s\n", outputType);
    LOGD("====MYTEST==== outputType=%s",outputType);
    if (outputType == NULL)
    {
        // @ default PCBA level, phone speaker -> phone mic
        mc->recordDevice = BUILTIN_MIC;
        LOGD("MYTEST here 0");
        mAudio_loopback_phonemicspk_auto(micspkentry,mc);
    }
    else
    {
        if (atoi(outputType) == 0) // @ PCBA level, phone speaker -> phone mic
        {
            mc->recordDevice = BUILTIN_MIC;
            mAudio_loopback_phonemicspk_auto(micspkentry,mc);
        }
        else if (atoi(outputType) == 1) // @ Phone level, phone speaker -> headset mic loopback
        { 
            mc->recordDevice = WIRED_HEADSET;
            mAudio_loopback_phonemicspk_auto(micspkentry, mc);
        }
        else if (atoi(outputType) == 2) // @ Phone level, freq response
        {
            mc->recordDevice = WIRED_HEADSET;
            mAudio_speaker_freqresponse_entry (micspkentry, mc);
        }
        else if (atoi(outputType) == 3) // @ Phone level, THD
        {
            mc->recordDevice = WIRED_HEADSET;
            mAudio_speaker_thd_entry (micspkentry,mc);
        }
    }


    free(mc);
    return 0;
}



pthread_mutex_t audioMutex;
void * jlink_micspeaker_start(void*para){

    drawTestItem(&micspkEntry);
    strcpy(micspkEntry.value.name, uistr_info_waiting);
    drawItemValueBehind(&micspkEntry);
    pthread_mutex_lock(&audioMutex);
    sleep(1);
    mAudio_loopback_phonemicspk_entry(&micspkEntry);
    pthread_mutex_unlock(&audioMutex);
    pthread_exit(NULL);
    //Audio_PhoneMic_Speaker_loopback_entry(&micspkEntry);
    return NULL;
}