#include "jlinkui.h"
#include <linux/hdmitx.h>
#define HDMIPATH "/dev/hdmitx"
#include "../test/ftm_audio_Common.h"

#define JLINK_HDMI_MANUAL

extern TestEntry hdmiEntry;
static bool hdmi_run = 1;
static int hdmi_enable(){
	int ret;
	int check_res = 0;
	int capability = 0;
	int fd = open(HDMIPATH, O_RDONLY);
	if (fd == -1)
	{
		LOGD("MYTEST Can't open %s",HDMIPATH);
		//sprintf(hdmiEntry.value.name,"Can't open %s", HDMIPATH);
		return -1;
	}
	ret = ioctl(fd, MTK_HDMI_GET_CAPABILITY,&capability);
	if (ret < 0 || (capability & MTK_HDMI_FACTORY_MODE_ENABLE) == 0)
	{
		ret = ioctl(fd, MTK_HDMI_FACTORY_MODE_ENABLE,1);
		if (ret < 0)
		{
			check_res = -1;
			goto check_exit;
		}

		check_res = ioctl(fd,MTK_HDMI_AUDIO_VIDEO_ENABLE, 1);
		if (check_res < 0)
		{
			goto check_exit;
		}
	} else if (capability & HDMI_FACTORY_MODE_NEW)
	{
		ret = ioctl(fd, MTK_HDMI_FACTORY_CHIP_INIT, &check_res);
		if (ret < 0)
		{
			LOGD("MYTEST MTK_HDMI_FACTORY_CHIP_INIT fail");
			goto check_exit;
		}
	}

	LOGD("MYTEST ioctl MTK_HDMI_AUDIO_VIDEO_ENABLE");
	ioctl(fd, MTK_HDMI_AUDIO_VIDEO_ENABLE,1);
	check_res = ioctl(fd, MTK_HDMI_AUDIO_CONFIG,(2 |(HDMI_MAX_SAMPLERATE_44 << 4) |(HDMI_MAX_BITWIDTH_16 << 7)));
	if (check_res < 0)
	{
		LOGD("MYTEST ioctl MTK_HDMI_AUDIO_CONFIG fail");
	}

	LOGD("MYTEST ioctl MTK_HDMI_AUDIO_ENABLE");
	check_res = ioctl(fd,MTK_HDMI_AUDIO_ENABLE,1);
	if (check_res < 0)
	{
		LOGD("MYTEST MTK_HDMI_AUDIO_ENABLE fail");
	}

	LOGD("MYTEST hdmi_enable to start audio");
	Common_Audio_init();
	LOGD("MYTEST hdmi_enable to start sinetome");
	Audio_HDMI_SineTonePlayback(true, 44100); 
	LOGD("MYTEST hdmi_enable to start audio done");

check_exit:
	close(fd);
	return check_res;
}


static int hdmi_disable(){
	int ret;
	int capability = 0;
	int fd = open(HDMIPATH, O_RDONLY);
	if (fd == -1)
	{
		LOGE("MYTEST hdmi_disable Can't open %s", HDMIPATH);
		return -1;
	}
	ret = ioctl(fd, MTK_HDMI_GET_CAPABILITY, &capability);
	if (ret < 0 || (capability & HDMI_FACTORY_MODE_NEW) == 0)
	{
		ret = ioctl(fd, MTK_HDMI_AUDIO_VIDEO_ENABLE, 0);
		ioctl(fd, MTK_HDMI_FACTORY_MODE_ENABLE, 0);
	}
	close(fd);
	LOGD("MYTEST hdmi_enable to stop audio \n");
    Audio_HDMI_SineTonePlayback(false, 44100);
    LOGD("MYTEST hdmi_enable to stop audio sinetone done\n");
    Common_Audio_deinit();
    LOGD("MYTEST hdmi_enable to stop audio done\n");
    
    return ret;
}

void hdmi_start(){
	int check_res = 0;
	int capability = 0;
	int check_cnt = 0;
	int ret = 0;
	hdmiEntry.state = TEST_FAIL;
	if (hdmi_enable())
	{
		strcpy(hdmiEntry.value.name,"HDMI enable fail");
		drawItemValueBehindLine(&hdmiEntry);
	}else{
		LOGD("MYTEST hdmi basic test pass and to test connect\n");
		int fd = open(HDMIPATH, O_RDONLY);
#ifdef JLINK_HDMI_MANUAL
		strcpy(hdmiEntry.value.name, "Please plug hdmi cable and connect the projection equipment");
		drawItemValueBehindLine(&hdmiEntry);
		while(hdmi_run) {
		    ret = ioctl(fd, MTK_HDMI_GET_CAPABILITY, &capability);
		    if (ret >= 0 && (capability & HDMI_FACTORY_MODE_NEW))
		    {
		    	ioctl(fd, MTK_HDMI_FACTORY_JUDGE_CALLBACK, &check_res);
		    }else{
		    	ioctl(fd, MTK_HDMI_FACTORY_GET_STATUS, &check_res);
		    }

		    if (check_res <= 0)
		    {
		    	check_cnt++;
		    }else{
		    	break;
		    }

		    if (check_cnt > 60)
		    {
		    	sprintf(hdmiEntry.value.name, "%s","please check your cable and retest.");
		    	drawItemValueBehindLine(&hdmiEntry);
		    	close(fd);
		    	goto skip_dp_exit;
		    }

		    usleep(1000*500);
		}
		if (ret >= 0 && (capability & HDMI_FACTORY_MODE_NEW))
		{
			ret = ioctl(fd, MTK_HDMI_FACTORY_START_DPI_AND_CONFIG, 0x20000);
			if (ret < 0)
			{
				LOGD("MYTEST MTK_HDMI_FACTORY_START_DPI_AND_CONFIG fail");
				sprintf(hdmiEntry.value.name, "%s","start dpi and config fail");
				drawItemValueBehindLine(&hdmiEntry);
				close(fd);
				goto skip_dp_exit;
			}
		}else{
			usleep(1000*30);
			ioctl(fd, MTK_HDMI_VIDEO_CONFIG, 2);

			usleep(1000*30);
			ioctl(fd, MTK_HDMI_FACTORY_DPI_TEST, &check_res);
		}
		hdmiEntry.state = TEST_PASS;
		hdmiEntry.value.color = GREENCOLOR;
		sprintf(hdmiEntry.value.name, "HDMI Basic %s please check TV status", uistr_pass);
		drawItemValueBehindLine(&hdmiEntry);
		close(fd);
		usleep(1000*10);
#else
		bool result = true;
		unsigned int leng=0;
		int size = 0;
		int looptime;
		#ifdef MTK_HDMI_HDCP_SUPPORT
		#ifdef MTK_HDCP_DRM_KEY_MNG_SUPPORT
			size = get_clearDrmkey_size(HDCP_1X_TX_ID , &leng);
		#else
			size = -1;
		#endif
		#else
			size = -1;
		#endif

		if (size == -1)
		{
			strcpy(hdmiEntry.value.name,"HDCP KEY NOT FOUND");
			result = false;
		}else{
			strcpy(hdmiEntry.value.name,"HDCP KEY FOUND");
		}

		drawItemValueBehindLine(&hdmiEntry);
		for (looptime = 0; looptime < 1000; ++looptime)
		{
			if (!hdmi_run) goto skip_dp_exit;
			ioctl(fd, MTK_HDMI_FACTORY_GET_STATUS, &check_res);

			if (check_res >= 0)
			{
				LOGE("MYTEST hdmi plug in");
				strcpy(hdmiEntry.value.name,"plug in");
				drawItemValueBehindLine(&hdmiEntry);
				break;
			}else if (check_res == -3)
			{
				LOGE("MYTEST hdmi EDID check fail");
				strcpy(hdmiEntry.value.name,"EDID check fail");
				drawItemValueBehindLine(&hdmiEntry);
				result = false;
				break;
			}
			sleep(1);
		}
		if (check_res == 1)
		{
			hdmiEntry.value.color = GREENCOLOR;
			sprintf(hdmiEntry.value.name, "HDMI Basic %s please check TV status", uistr_pass);
			drawItemValueBehindLine(&hdmiEntry);
			ioctl(fd, MTK_HDMI_FACTORY_DPI_TEST, &check_res);
			result = true;
		}

		if (result)
		{
			looptime = 0;
			do{
				ioctl(fd, MTK_HDMI_FACTORY_GET_STATUS, &check_res);
				if (check_res < 0)
				{
					strcpy(hdmiEntry.value.name, "plug out");
					break;
				}

				looptime++;
				if (looptime > 120)
				{
					result = false;
					strcpy(hdmiEntry.value.name,"wait cable plug out fail");
					break;
				}
				sleep(1);
			}while(1);
		}
		drawItemValueBehindLine(&hdmiEntry);
		if (result)
		{
			hdmiEntry.state = TEST_PASS;
		}else{
			hdmiEntry.state = TEST_FAIL;
		}
		close(fd);
#endif
	}

skip_dp_exit:

	hdmi_disable();
	setProinfoItemResult(hdmiEntry.id,hdmiEntry.state);
	return;
}

void* jlink_hdmi_start(void* para){
	drawTestItem(&hdmiEntry);
	hdmi_run = 1;
	hdmi_start();
	pthread_exit(NULL);
	return NULL;
}
void jlink_stop_hdmi(){
	hdmi_run = 0;
}