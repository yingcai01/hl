
#include <ftm.h>
#include <poll.h>
#include <linux/rtc.h>


extern "C" {
#include "jlinkui.h"
}

enum {
	ITEM_PASS,
	ITEM_FAIL
};

#define rtc_init_tm(tm, y, m, d, h, mi, s)	\
do {						\
	(tm)->tm_year = (y) - 1900;		\
	(tm)->tm_mon = (m) - 1;			\
	(tm)->tm_mday = (d);			\
	(tm)->tm_hour = (h);			\
	(tm)->tm_min = (mi);			\
	(tm)->tm_sec = (s);			\
} while (0)

#define RTC_DEV_PATH	"/dev/rtc0"
static volatile int Alarm_flag=0;
extern TestEntry rtcEntry;
extern struct rtc {
	struct ftm_module *mod;
	int fd;

	pthread_t tm_pt;
	pthread_t alm_pt;
	bool tm_exit;
	bool alm_exit;

	text_t title;
	text_t text;
	char time[32];
	struct itemview *iv;
};

static void *rtc_alm_pthread(void *priv)
{
	int r;
	unsigned long data;
	struct pollfd ev_fd;
	struct rtc *rtc = (struct rtc *)priv;
	struct rtc_time tm;
	int ret;

	ev_fd.fd = rtc->fd;
	ev_fd.events = POLLIN;
	ret = poll(&ev_fd, 1, 4600);	/* 4600 ms */
	if (ret < 0) {
		LOGE(TAG "poll failed (%d)\n", ret);
	} else if (ret == 0) {
		LOGE(TAG "poll timeout after 4600 ms\n");
	}

	if (rtc->alm_exit)
		goto ret;

	r = read(rtc->fd, &data, sizeof(unsigned long));
	if (r < 0) {
		LOGD(TAG "read rtc data failed\n");
		goto ret;
	}

	if (data & RTC_AF) {

			r = ioctl(rtc->fd, RTC_RD_TIME, &tm);
			if (r < 0) {
				LOGD(TAG "read rtc time failed\n");
				goto ret;
			}
			/* RTC alarm will postpone 1 seccond to avoid sending alarm
			event earlier than alarm manager's expection */
			if ((tm.tm_sec == 0 || tm.tm_sec == 1) && tm.tm_min == 0 && tm.tm_hour == 0 &&
			    tm.tm_mday == 1 && tm.tm_mon == 0 && tm.tm_year == 109) {
				Alarm_flag=1;
			}
			else
				Alarm_flag=2;

	}

ret:
	pthread_exit(NULL);
	return NULL;
}


static void *rtc_tm_pthread(void *priv)
{
	int r;
	struct rtc_time tm;
	struct rtc *rtc = (struct rtc *)priv;
	struct itemview *iv = rtc->iv;

	rtc_init_tm(&tm, 2008, 12, 31, 23, 59, 57);
	r = ioctl(rtc->fd, RTC_SET_TIME, &tm);
	if (r < 0) {
		LOGD(TAG "set rtc time failed\n");
		goto ret;
	}

	while (1) {
		if (rtc->tm_exit)
			break;

		r = ioctl(rtc->fd, RTC_RD_TIME, &tm);
		if (r < 0) {
			LOGD(TAG "read rtc time failed\n");
			goto ret;
		}

		sprintf(rtcEntry.value.name, "%d/%02d/%02d %02d:%02d:%02d\n",
		        tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday,
		        tm.tm_hour, tm.tm_min, tm.tm_sec);
		drawItemValueBehind(&rtcEntry);
		
		/* exit at 2009/01/01 00:00:00 */
		if (tm.tm_sec == 0 && tm.tm_min == 0 && tm.tm_hour == 0 &&
		    tm.tm_mday == 1 && tm.tm_mon == 0 && tm.tm_year == 109) {
			break;
		}
		usleep(100000);		/* 100 ms */
	}

ret:
	pthread_exit(NULL);
	return NULL;
}

static int rtc_start()
{
	int r, num;
	bool exit=false;
	struct rtc_wkalrm alm;
	struct rtc *rtc = (struct rtc *)calloc(sizeof(struct rtc),1);

	
	rtc->fd = open(RTC_DEV_PATH, O_RDWR);
	if (rtc->fd < 0) {
		LOGD(TAG "open %s failed\n", RTC_DEV_PATH);
		return rtc->fd;
	}


	rtc_init_tm(&alm.time, 2008, 12, 29, 0, 0, 0);
	r = ioctl(rtc->fd, RTC_SET_TIME, &alm.time);
	if (r < 0) {
		LOGD(TAG "set rtc time failed\n");
		goto ret;
	}

	alm.enabled = 1;
	rtc_init_tm(&alm.time, 2009, 1, 1, 0, 0, 0);
	r = ioctl(rtc->fd, RTC_WKALM_SET, &alm);
	if (r < 0) {
		rtcEntry.state = TEST_FAIL;
		LOGD(TAG "enable rtc alarm failed\n");
		goto ret;
	}


	rtc->tm_exit = false;
	rtc->alm_exit = false;
	pthread_create(&rtc->tm_pt, NULL, rtc_tm_pthread, rtc);
	pthread_create(&rtc->alm_pt, NULL, rtc_alm_pthread, rtc);


	while (1) {
			if(Alarm_flag==1)
			{
				Alarm_flag=0;
				num = ITEM_PASS;
				if (num == ITEM_PASS) {
					rtcEntry.state = TEST_PASS;
					//rtc->mod->test_result = FTM_TEST_PASS;
					exit = true;
				}
			}
			else if(Alarm_flag==2)
			{
				Alarm_flag=0;
				num = ITEM_FAIL;
				if (num == ITEM_FAIL) {
					rtcEntry.state = TEST_FAIL;
					//rtc->mod->test_result = FTM_TEST_FAIL;
					exit = true;
				}
			}
			if (exit) {
				rtc->tm_exit = true;
				rtc->alm_exit = true;
				break;
			}
	}

	pthread_join(rtc->tm_pt, NULL);
	pthread_join(rtc->alm_pt, NULL);

	alm.enabled = 0;
	rtc_init_tm(&alm.time, 2009, 1, 1, 0, 0, 0);
	r = ioctl(rtc->fd, RTC_WKALM_SET, &alm);
	if (r < 0)
		LOGD(TAG "disable rtc alarm failed\n");

ret:
	close(rtc->fd);
	if(rtc!=NULL)free(rtc);
	setProinfoItemResult(rtcEntry.id,rtcEntry.state);
	return r;
}



void * jlink_rtc_start(void*para){
    drawTestItem(&rtcEntry);
    rtc_start();
    return NULL;
}