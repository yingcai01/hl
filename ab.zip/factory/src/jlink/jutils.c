#include "jlinkui.h"
#include "libnvram.h"
#include "uistrings.h"
#include "Custom_NvRam_LID.h"
#include <cutils/properties.h>
#ifndef bool
#define bool    int
#endif
#define true 1
#define false 0

static bool isInit;

struct JLINK_ITEMMAP{
	int id;
	char *name;
};

struct JLINK_ITEMMAP jitem_map []= {
	{JILNK_ITEM_KEYS,							uistr_keys}, 										//1
	{JLINK_ITEM_JOGBALL,						uistr_jogball},										//2
    {JILNK_ITEM_OFN,							uistr_ofn},										//3
    {JILNK_ITEM_TOUCH,							uistr_touch},										//4
    {JILNK_ITEM_TOUCH_AUTO,						uistr_touch_auto},									//5
    {JILNK_ITEM_LCD,							uistr_backlight_level},								//6
    {JILNK_ITEM_LCM,							uistr_lcm},											//7
    {JILNK_ITEM_FLASH,							uistr_nand_flash},									//8
    {JILNK_ITEM_EMMC,							uistr_info_emmc	},										//9
    {JILNK_ITEM_MEMCARD,						uistr_memory_card},									//10
    {JILNK_ITEM_SIMCARD,						uistr_sim_card},									//11
	{JILNK_ITEM_SIM,							uistr_sim_detect},									//12
    {JILNK_ITEM_SIGNALTEST,						uistr_sig_test},									//13
    {JILNK_ITEM_VIBRATOR,						uistr_vibrator},									//14
    {JILNK_ITEM_VIBRATOR_PHONE,					uistr_vibrator_phone},								//15
    {JILNK_ITEM_LED,							uistr_led},											//16
    {JILNK_ITEM_RTC,							uistr_rtc},											//17
    {JILNK_ITEM_LOOPBACK_PHONEMICSPK,			uistr_info_audio_loopback_phone_mic_speaker	},		//18
    {JILNK_ITEM_RECEIVER,						uistr_info_audio_receiver},							//19
    {JILNK_ITEM_LOOPBACK,						uistr_info_audio_loopback_phone_mic_headset},		//20
    {JILNK_ITEM_ACOUSTICLOOPBACK,				uistr_info_audio_acoustic_loopback},				//21
    {JILNK_ITEM_LOOPBACK1,						uistr_info_audio_loopback_phone_mic_headset},		//22
    {JILNK_ITEM_LOOPBACK2,						uistr_info_audio_loopback_phone_mic_speaker},		//23
    {JILNK_ITEM_LOOPBACK3,						uistr_info_audio_loopback_headset_mic_speaker},		//24
    {JILNK_ITEM_WAVEPLAYBACK,					uistr_info_audio_loopback_waveplayback},			//25
    {JILNK_ITEM_MICBIAS,						uistr_info_audio_micbias},							//26
    {JILNK_ITEM_RECEIVER_PHONE,					uistr_info_audio_receiver_phone},					//27
    {JILNK_ITEM_HEADSET_PHONE,					uistr_info_headset_phone},							//28
    {JILNK_ITEM_LOOPBACK_PHONEMICSPK_PHONE,		uistr_info_audio_loopback_phone_mic_speaker_phone},	//29
    {JILNK_ITEM_HEADSET,						uistr_info_headset},								//30
    {JILNK_ITEM_SPK_OC,							uistr_info_speaker_oc},								//31
    {JILNK_ITEM_OTG,							uistr_info_otg_status},								//32
    {JILNK_ITEM_USB,							"USB"},												//33
    {JILNK_ITEM_GSENSOR,						uistr_g_sensor},									//34
    {JILNK_ITEM_GS_CALI,						uistr_g_sensor_c},									//35
    {JILNK_ITEM_MSENSOR,						uistr_m_sensor},									//36
    {JILNK_ITEM_ALSPS,							uistr_als_ps},										//37
    {JILNK_ITEM_BAROMETER,						uistr_barometer},									//38
    {JILNK_ITEM_GYROSCOPE,						uistr_gyroscope},									//39
    {JILNK_ITEM_GYROSCOPE_CALI,					uistr_gyroscope_c},									//40
    {JILNK_ITEM_MAIN_CAMERA,					uistr_main_sensor},									//41
    {JILNK_ITEM_MAIN2_CAMERA,					uistr_main2_sensor},								//42
    {JILNK_ITEM_SUB_CAMERA,						uistr_sub_sensor},									//43
    {JILNK_ITEM_STROBE,							uistr_strobe},										//44
    {JILNK_ITEM_GPS,							uistr_gps},											//45
    {JILNK_ITEM_NFC,							uistr_nfc},											//46
    {JILNK_ITEM_FM,								uistr_info_fmr_title},								//47
    {JILNK_ITEM_FMTX,							uistr_info_fmt_title},								//48
    {JILNK_ITEM_BT,								uistr_bluetooth},									//49
    {JILNK_ITEM_WIFI,							uistr_wifi},										//50
    {JILNK_ITEM_MATV_AUTOSCAN,					uistr_atv},											//51
    {JILNK_ITEM_MATV_NORMAL,					"MATV HW Test"},									//52
    {JILNK_ITEM_CHARGER,						uistr_info_title_battery_charger},					//53
    {JILNK_ITEM_IDLE,							uistr_idle},										//54
    {JILNK_ITEM_CFT,							uistr_cft_test},											//55
    {JILNK_ITEM_MEMORY,							uistr_memory},										//56
    {JILNK_ITEM_CMMB,							uistr_cmmb},										//57
    {JILNK_ITEM_EMI,							uistr_system_stability},							//58
    {JILNK_ITEM_HDMI,							"HDMI"},											//59
    {JILNK_ITEM_RF_TEST,						uistr_rf_test},										//60
};

#define START_INDEX 8
#define MAX_RETRY_COUNT 20


typedef struct
{
    unsigned char imei[8];
    unsigned char svn;
    unsigned char pad;
} nvram_ef_imei_imeisv_struct;


typedef struct{
		unsigned char barcode[64];
		nvram_ef_imei_imeisv_struct IMEI[4];
		unsigned char pt1_test[8];
		unsigned char pt2_test[8];
		unsigned char final_test[8];
		unsigned char final2_test[8];
		unsigned char auto_test[58];
		unsigned char reserved[830];
}PRODUCT_INFO_CUSTOM;
static PRODUCT_INFO_CUSTOM proinfo_data;





char* getItemName(int id){
	int i=1;
	for (;i<JLINK_ITEM_MAX;i++){
		if (jitem_map[i-1].id == id){
			return jitem_map[i-1].name;
		}
	}
	return (char*)NULL;
}

int getItemResult(int id){
	int i=1;
	for(;i<JLINK_ITEM_MAX;i++){
		if ((proinfo_data.auto_test[START_INDEX+i-1] >> 2)==id){
			return proinfo_data.auto_test[START_INDEX+i-1] & 0x3;
		}
	}
	return 0;
}




static bool readOrWriteResultFromNvram(PRODUCT_INFO_CUSTOM *proinfo, bool isread)
{
	int read_nvram_ready_retry = 0;
	F_ID fid;
	int rec_num;
	int rec_size = 0; 
	int pro_lid = AP_CFG_REEB_PRODUCT_INFO_LID; 
	char nvram_init_val[128] = {0};

	if(proinfo == NULL)
	{
		return false;
	}

	while(read_nvram_ready_retry < MAX_RETRY_COUNT)
	{
		read_nvram_ready_retry++;
		property_get("service.nvram_init", nvram_init_val, NULL);
		if(strcmp(nvram_init_val, "Ready") == 0)
		{
			break;
		}
		else
		{
			usleep(500000);
		}
	}

	if(read_nvram_ready_retry >= MAX_RETRY_COUNT)
	{
		LOGD("MYTEST NVRAM Get nvram restore ready failed!\n");
		return false;
	}
  
	fid = NVM_GetFileDesc(pro_lid, &rec_size, &rec_num, isread);

	if(fid.iFileDesc < 0)
	{
		return false;
	}

	if(isread)
	{
		if(rec_size != read(fid.iFileDesc, proinfo, rec_size))
		{
			return false;
		}
	}
	else
	{
		if(rec_size != write(fid.iFileDesc, proinfo, rec_size))
		{
			return false;
		}
	}
	if(!NVM_CloseFileDesc(fid))
	{ 
		return false;
	}
	return true;
}

static pthread_mutex_t nvram_mutex;
int initProinfoData(){
	pthread_mutex_init(&nvram_mutex,NULL);
	if(readOrWriteResultFromNvram(&proinfo_data,true)){
		isInit = true;
	}else{
		isInit = false;
	}
	return isInit;
}
void keepNvramResult(){
	readOrWriteResultFromNvram(&proinfo_data,false);
}

//需先初始化proinfo_data
void setProinfoItemResult(int id,int state){
	pthread_mutex_lock(&nvram_mutex);
	if (!isInit) {
		if (!initProinfoData())return;
	}
	int i = 1;
	for(;i<JLINK_ITEM_MAX;i++){
		if ((proinfo_data.auto_test[START_INDEX+i-1]>>2)==id || proinfo_data.auto_test[START_INDEX+i-1] ==0 || proinfo_data.auto_test[START_INDEX+i-1] ==0xff){
			proinfo_data.auto_test[START_INDEX+i-1] = ((id & 0xFF) << 2 | state);
			break;
		}
	}
	keepNvramResult();
	pthread_mutex_unlock(&nvram_mutex);
}
