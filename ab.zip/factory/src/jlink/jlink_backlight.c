#include "jlinkui.h"


#define BRIGHTNESS_FILE "/sys/class/leds/lcd-backlight/brightness"
static int auto_brightness_seq[] = {
	10, 255,10, 255,-1
};
extern TestEntry backlightEntry;
extern Button backbutton;

static pthread_mutex_t locker;
static int write_int(char const* path, int value)
{
    int fd;
    
    if (path == NULL)
        return -1;
    
    fd = open(path, O_RDWR);
    if (fd >= 0) {
        char buffer[20];
        int bytes = sprintf(buffer, "%d\n", value);
        int amt = write(fd, buffer, bytes);
        close(fd);
        return amt == -1 ? -errno : 0;
    }
    
    LOGE("write_int failed to open %s\n", path);
    return -errno;
}

static void *backlight_thread(void *priv)
{

    int times = 5;
    int seq_index = 0;
    int ret;
    LOGD("%s: Start\n", __FUNCTION__);
    do 
    {        
        pthread_mutex_lock(&locker);
		if (auto_brightness_seq[seq_index] == -1)
			seq_index = 0;
	 	ret = write_int(BRIGHTNESS_FILE, auto_brightness_seq[seq_index]);	
        seq_index++;
        pthread_mutex_unlock(&locker);  		
        sleep(1);
    } while (times--);
    ret = write_int(BRIGHTNESS_FILE, 250);
    if (ret==0){
        backlightEntry.state = TEST_PASS;
    }else{
        backlightEntry.state = TEST_FAIL;
    }
    setProinfoItemResult(backlightEntry.id, backlightEntry.state);
    LOGD("%s: Exit\n", __FUNCTION__);
	
    pthread_exit(NULL);

    return NULL;
}



ButtonEntry backbtnentry;
static void* start_backlight(void*para){
    strcpy(backlightEntry.value.name,uistr_info_testing);
    drawItemValueBehind(&backlightEntry);
	pthread_mutex_init(&locker,NULL);
	pthread_t backlight_handle;
	pthread_create(&backlight_handle, NULL,backlight_thread,NULL);
	pthread_join(backlight_handle, NULL);
    strcpy(backlightEntry.value.name,uistr_info_testover);
    drawItemValueBehind(&backlightEntry);
    DrawButtonBehindEntry(&backbutton,&backlightEntry);
    return NULL;
}


void * jlink_backlight_start(void*para){

    drawTestItem(&backlightEntry);
    initTestButton(&backbutton,start_backlight);
    backbtnentry.btn = &backbutton;
    backbtnentry.next = NULL;
    addButtionCallback(&backbtnentry);
    start_backlight(NULL);
    return NULL;
}
