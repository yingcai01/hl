#include "jlink.h"
#include <pthread.h>
#include <utils/Log.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include "miniui.h"
#include "jutils.h"
#include <unistd.h>
#define LOGD ALOGD
#define LOGE ALOGE
#define LOGI ALOGI
#define TAG "MYTEST"

//#define JLINK_ITEM_DEBUG //调试单个测试项打开
enum TEST_STATE{
	NO_TEST,
	TEST_PASS,
	TEST_FAIL,
	TEST_UNKOWN
};

typedef struct
{
	char name[1024];
	int color;
	int backcolor;
	int row;
	int col;
} JTextEntry;

typedef void* (*JCallBack)(void*);



typedef struct
{
	enum TEST_STATE state; 	//测试结果
	char errstr[100]; 	//测试未成功时错误信息
	JTextEntry entry;	//文本属性
	JTextEntry value;	//测试值
	JCallBack redraw;	//重绘函数
	int id;
	int hasani;
	int exit;
	int valuelinenum;
	int entryLastX;
	int entryLastY;
	int lastXpos;
	pthread_t pthread_handle;
}TestEntry;


typedef struct {
    int width;
    int height;
    int row_bytes;
    int pixel_bytes;
    unsigned char* data;
} GRSurface;


typedef struct
{
	int x;
	int y;
	float percent;
	GRSurface* pro_empty_surface;
	GRSurface* pro_fill_surface;	
} ProgressBar;

enum ButtonState{
	BTN_NORMAL,
	BTN_PRESSD,
	BTN_DISABLE,
	BTN_HIDDEN
};

enum ButtonDrawState{
	BTN_NO_DRAW,
	BTN_NORMAL_DRAW,
	BTN_PRESSD_DRAW,
	BTN_DISABLE_DRAW
};

typedef struct
{
	int x;
	int y;
	int width;
	int height;
	enum ButtonState state; 
	char text[100];
	int back_color;
	int text_color;
	int press_color;
	int disenable_color;
	void * para;
	pthread_t pthread_handle;
	JCallBack onClickListener;
	int isautohidden;
} Button;

typedef struct ButtonEntry
{
	Button *btn;
	struct ButtonEntry *next;
}ButtonEntry;


extern char rotate_lcm[];

#define BACKCOLOR 0x000000ff   
#define NOTESTCOLOR 0x0000ffff
#define PASSCOLOR 0x00ff00ff
#define FAILCOLOR 0xff0000ff
#define ITEMCOLOR 0xffff00ff
#define WRITECOLOR 0xffffffff
#define BLACKCOLOR 0x000000ff
#define YELLOWCOLOR 0xffff00ff
#define REDCOLOR 0xff0000ff
#define GREENCOLOR 0x00ff00ff
#define BLUECOLOR 0x0000ffff

#define CAMERA_PRE_WIDTH 320
#define CAMERA_PRE_HEIGHT 240

#define set_gr_color(c) \
    gr_color(color_r(c), color_g(c), color_b(c), color_a(c))



#define ITEMCOL 0
void drawTestItem(TestEntry *testentry);
void drawUpdateTestItem(TestEntry *testentry);
void drawItemValueBehind(TestEntry *testentry);
void drawItemValueBehindLine(TestEntry *testentry);
void draw_image(int x,int y,GRSurface* frame);
void updateProgressBar(ProgressBar bar,float percent);
void draw_button(Button* button);
void initButtonCallbcak();
void addButtionCallback(ButtonEntry* entry);
void rmButtonCallbak(ButtonEntry* entry);
void clearScreen();
void* startListener(void*param);
void drawColorBand();
void setButtonHidden(Button *btn);
void setButtonNormal(Button *btn);
void drawItemValueAuto(TestEntry *testentry);
void initTestButton(Button* button,JCallBack callback);
void DrawButtonBehindEntry(Button* button,TestEntry *entry);
void exitListener();
void* do_clip_loop(void*pram);
void do_grline(int x1, int y1, int x2, int y2, int width,int color);
void setJlinkTptest(int istest);
