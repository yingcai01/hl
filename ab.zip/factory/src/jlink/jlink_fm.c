#include "jlinkui.h"
#include "../test/ftm_audio_Common.h"
#include <linux/fm.h>
#include "ftm.h"

#include "Audio_FFT_Types.h"
#include "Audio_FFT.h"
#define FM_BAND_WIDTH  0x01
#define FM_SPACE_WIDTH   0x01
#define FM_FMD_BAND         FM_BAND_WIDTH

//暂时关闭耳机
//#define FM_GET_HEADSET_STATE 
static uint16_t fm_freq_list[] = {876, 900, 974, 1018}; //原型/custom/{project}}/factory/inc
static int g_fm_fd = -1;
static int g_setfreq = 0;
static int g_freq_item = 0;
static int g_rssi = 0;
static bool g_check_done = false;
static int fmthreadrun = 1;
extern TestEntry fmEntry;
extern struct fm_factory {
    char  info[1024];
    bool  exit_thd;
    int   result;

    /* for UI display */
    text_t    title;
    text_t    text;

    pthread_t update_thd;
    pthread_t record_thd;
#if (defined MT5192_FM || defined MT5193_FM) && defined FM_DIGITAL_INPUT
    pthread_t     mAudioThread;
#endif
    struct ftm_module *mod;
    struct textview tv;
    struct itemview *iv;
};


static void read_preferred_freq()
{
    uint16_t tmp_freq;
    unsigned int i = 0;
    char *pFreq = NULL;
    char channel_no[64]; //max path

    for (i = 0; i < sizeof(fm_freq_list)/sizeof(fm_freq_list[0]); i++) {
        memset(channel_no, 0, sizeof(channel_no));
        sprintf(channel_no, "FMRadio.CH%d", i+1);
        pFreq = ftm_get_prop(channel_no);

        if (pFreq != NULL) {
            fm_freq_list[i] = (uint16_t)atoi(pFreq);
            LOGD(TAG "preferred_freq: %d, %d\n", i, fm_freq_list[i]);
        } else {
            LOGD(TAG "preferred_freq %d can't get\n", i);
        }
    }
}

#if (defined MT5192_FM || defined MT5193_FM) && defined FM_DIGITAL_INPUT
static void *fm_audio_thread(void *priv)
{
    struct fm_factory *fmr = (struct fm_factory *)priv;
    struct itemview *iv = fmr->iv;
    int bufSize = 0;
    int numread = 0;

    LOGD(TAG "%s: Start\n", __FUNCTION__);

    bufSize = I2SGetReadBufferSize(mI2Sdriver);
    LOGV("got buffer size = %d", bufSize);
    mAudioBuffer = (char *)malloc(bufSize * 3);

    while (fmthreadrun) {
        if (fmr->exit_thd)
           break;

        if (Audio_enable == true) {
           memset(mAudioBuffer, 0x0,bufSize * 3);
           numread = I2SRead(mI2Sdriver, mI2Sid, mAudioBuffer, bufSize);
           ATV_AudioWrite(mAudioBuffer, numread);
        } else {
           usleep(500 * 1000);
        }
    }

    LOGD(TAG "%s: matv_audio_thread Exit\n", __FUNCTION__);

    if (mAudioBuffer) {
        free(mAudioBuffer);
        mAudioBuffer = NULL;
    }
    return NULL;
}
#endif

static void *fm_update_thread(void *priv)
{
    int ret = -1, rssi = 0;
    struct fm_factory *fmr = (struct fm_factory *)priv;
    struct itemview *iv = fmr->iv;
    struct fm_tune_parm parm_tune;
    float f_freq;
    uint32_t mute = 0;
    int type = -1;

    LOGD(TAG "%s: Start\n", __FUNCTION__);
    //memset(fmr->info, 0x00, sizeof(fmr->info));

#if (defined MT5192_FM || defined MT5193_FM)
    g_fm_fd=0;
#else
    g_fm_fd = open(FM_DEVICE_NAME, O_RDWR);
#endif
    if (g_fm_fd < 0) {
        printf("[FM] Factory Mode Open FM %s failed\n", FM_DEVICE_NAME);
        sprintf(fmEntry.value.name, "%s", uistr_info_fmr_open_fail);
        //iv->redraw(iv);
        drawItemValueBehind(&fmEntry);
        goto out;
    }

    parm_tune.band = FM_FMD_BAND;
#ifdef MTK_FM_50KHZ_SUPPORT
    parm_tune.freq = fm_freq_list[0]*10; //default value for FM power up.
#else
    parm_tune.freq = fm_freq_list[0]; //default value for FM power up.
#endif //MTK_FM_50KHZ_SUPPORT
    parm_tune.hilo = FM_AUTO_HILO_OFF;
    parm_tune.space = FM_SPACE_WIDTH;
#if (defined MT5192_FM || defined MT5193_FM)
    ret =fm_powerup(&parm_tune) ? 0 : 1;
#else
    ret = ioctl(g_fm_fd, FM_IOCTL_POWERUP, &parm_tune);
#endif
    if(ret) {
        printf("[FM] FM_OP_POWER_ON failed");
#if (!defined MT5192_FM && !defined MT5193_FM)
        close(g_fm_fd);
 #endif
        g_fm_fd = -1;
        sprintf(fmEntry.value.name, "%s", uistr_info_fmr_poweron_fail);
        //iv->redraw(iv);
        drawItemValueBehind(&fmEntry);
        goto out;
    }

#if (defined MT5192_FM || defined MT5193_FM)
    ret = fm_mute(mute) ? 0 : 1;
#else
    ret = ioctl(g_fm_fd, FM_IOCTL_MUTE, &mute);
#endif
    if(ret) {
        printf("[FM] FM_IOCTL_MUTE failed");
#if (!defined MT5192_FM && !defined MT5193_FM)
        close(g_fm_fd);
 #endif
        g_fm_fd = -1;
        sprintf(fmEntry.value.name, "%s", uistr_info_fmr_mute_fail);
        drawItemValueBehind(&fmEntry);
        goto out;
    }
#ifdef FM_ANALOG_INPUT
    FMLoopbackTest(true);
#else
    Audio_I2S_Play(true);
#endif

    sprintf(fmEntry.value.name, "%s", uistr_info_fmr_poweron_ok);
    //iv->redraw(iv);
    drawItemValueBehind(&fmEntry);

    while (fmthreadrun) {
        usleep(200000); // update every 200ms
        if (fmr->exit_thd)
            break;

        if (g_setfreq) {
#if (defined MT5192_FM || defined MT5193_FM) && defined FM_ANALOG_INPUT
         if (!FMAudioEnable) {
           ret= matv_set_chipdep(190,3) ? 0 : 1;
           if(ret) {
            g_fm_fd = -1;
            sprintf(fmEntry.value.name, "%s", "matv_set_chipdep failed\n");
            drawItemValueBehind(&fmEntry);
            return NULL;
            }
           FMAudioEnable = true;
        }
#endif
            g_setfreq = 0;
            f_freq = (float)fm_freq_list[g_freq_item]/10;
            sprintf(fmEntry.value.name, "%s %g%s\n", uistr_info_fmr_setfreq,  f_freq, uistr_info_fmr_mhz);
            drawItemValueBehind(&fmEntry);

            //set Freq and get RSSI
            parm_tune.band = FM_FMD_BAND;
#ifdef MTK_FM_50KHZ_SUPPORT
            parm_tune.freq = fm_freq_list[g_freq_item]*10;
#else
            parm_tune.freq = fm_freq_list[g_freq_item];
#endif //MTK_FM_50KHZ_SUPPORT
            parm_tune.hilo = FM_AUTO_HILO_OFF;
            parm_tune.space = FM_SPACE_100K;
#if (defined MT5192_FM || defined MT5193_FM)
           ret = fm_tune(&parm_tune) ? 0 : 1;
#else
            ret = ioctl(g_fm_fd, FM_IOCTL_TUNE, &parm_tune);
#endif
            if (ret) {
                //sprintf(fmr->info+strlen(fmr->info), uistr_info_fmr_fail);
                snprintf(fmEntry.value.name + strlen(fmEntry.value.name), sizeof(fmEntry.value.name) - strlen(fmEntry.value.name) - 1, uistr_info_fmr_fail);
                //iv->redraw(iv);
                drawItemValueBehind(&fmEntry);
                printf("[FM] FM_IOCTL_TUNE failed:%d:%d\n", ret, parm_tune.err);
            } else {
                //sprintf(fmr->info+strlen(fmr->info), uistr_info_fmr_success);
                //iv->redraw(iv);
#if (defined MT5192_FM || defined MT5193_FM)
               rssi = fm_getrssi();
               ret = 0;
#else
                ret = ioctl(g_fm_fd, FM_IOCTL_GETRSSI, &rssi);
#endif
                if (ret) {
                     printf("[FM] FM_IOCTL_GETRSSI failed\n");
                } else {
                     //sprintf(fmr->info+strlen(fmr->info), uistr_info_fmr_rssi, rssi);
                     snprintf(fmEntry.value.name + strlen(fmEntry.value.name), sizeof(fmEntry.value.name) - strlen(fmEntry.value.name) - 1, uistr_info_fmr_rssi, rssi);
                     LOGD("[FM] freq %d, rssi %d\n", parm_tune.freq, rssi);
                     drawItemValueBehind(&fmEntry);
                     g_rssi = rssi;
                     g_check_done = true;
                }

            }
        }
        //other control
    }
#ifdef FM_ANALOG_INPUT
    FMLoopbackTest(false);
#else
    // add delay to make sure sound can be heard
    sleep(1);
    Audio_I2S_Play(false);
#endif

#if (defined MT5192_FM || defined MT5193_FM)
    fm_powerdown(0);
#else
    type = FM_RX;
    ioctl(g_fm_fd, FM_IOCTL_POWERDOWN, &type);
    close(g_fm_fd);
#endif
    g_fm_fd = -1;

out:
    LOGD(TAG "%s: Exit\n", __FUNCTION__);
    g_check_done = fm_true;
    pthread_exit(NULL);
    return NULL;
}

static int read_rssi_th(void)
{
    unsigned int rssi = 0;
    char *pRSSI_TH = NULL;

    pRSSI_TH = ftm_get_prop("FMRadio.RSSITH");

    if (pRSSI_TH) {
        rssi = atoi(pRSSI_TH);
        LOGD(TAG "rssi th: %d\n", rssi);
    } else {
        LOGE(TAG "rssi th: failed\n");
    }

    return rssi;
}

static void * Audio_Record_thread(void *priv)
{
    struct fm_factory *fmr = (struct fm_factory *)priv;
    ALOGD(TAG "%s: Start", __FUNCTION__);
    usleep(100000);
    bool dumpFlag = 0;

    short pbuffer[8192]={0};
    short pbufferL[4096]={0};
    short pbufferR[4096]={0};
    unsigned int freqDataL[3]={0}, magDataL[3]={0};
    unsigned int freqDataR[3]={0}, magDataR[3]={0};

    uint32_t samplerate = 0;

    recordInit(BUILTIN_MIC, &samplerate);
    while (fmthreadrun) {
       memset(pbuffer,0,sizeof(pbuffer));
       memset(pbufferL,0,sizeof(pbufferL));
       memset(pbufferR,0,sizeof(pbufferR));

       int readSize  = readRecordData(pbuffer,8192*2);
       int i;
        for(i = 0 ; i < 4096 ; i++) {
            pbufferL[i] = pbuffer[2 * i];
            pbufferR[i] = pbuffer[2 * i + 1];
        }

        if (dumpFlag) {
            char filenameL[]="/data/record_dataL.pcm";
            char filenameR[]="/data/record_dataR.pcm";
            FILE * fpL= fopen(filenameL, "wb+");
            FILE * fpR= fopen(filenameR, "wb+");

            if (fpL!=NULL) {
                fwrite(pbufferL,readSize/2,1,fpL);
                fclose(fpL);
            }

            if(fpR!=NULL) {
                fwrite(pbufferR,readSize/2,1,fpR);
                fclose(fpR);
            }
        }
        memset(freqDataL,0,sizeof(freqDataL));
        memset(freqDataR,0,sizeof(freqDataR));
        memset(magDataL,0,sizeof(magDataL));
        memset(magDataR,0,sizeof(magDataR));
        ApplyFFT256(samplerate,pbufferL,0,freqDataL,magDataL);
        ApplyFFT256(samplerate,pbufferR,0,freqDataR,magDataR);

        ALOGD(TAG "FM FFT: FreqL = %d, FreqR = %d, AmpL = %d, AmpR = %d", freqDataL[0], freqDataR[0], magDataL[0], magDataR[0]);

        if (fmr->exit_thd) {
            break;
        }
      }

      ALOGD(TAG "FM FFT: FreqL = %d, FreqR = %d, AmpL = %d, AmpR = %d", freqDataL[0], freqDataR[0], magDataL[0], magDataR[0]);


      ALOGD(TAG "%s: Stop", __FUNCTION__);
      pthread_exit(NULL); // thread exit
      return NULL;
}

extern pthread_mutex_t audioMutex;
int fm_start()
{
    char *ptr;
    int chosen;
    bool exit = false;
    struct fm_factory *fmr = (struct fm_factory *)malloc(sizeof(struct fm_factory));
    int headset_state = 0;
    unsigned int rssi_th = 0;
    char *rawVal = NULL;
#ifdef FEATURE_FTM_TOUCH_MODE
    text_t* lbtn = NULL;
    text_t* cbtn = NULL;
    text_t* rbtn = NULL;
#endif

    LOGD(TAG "%s\n", __FUNCTION__);
    fmEntry.state = TEST_FAIL;
    //check headset state
#ifdef FM_GET_HEADSET_STATE
    int i;
    for (i=0; i<8; i++) {
        LOGD("[FM]init headset device\n");
        init_accdet();
        LOGD("[FM]get headset state\n");
        headset_state = fm_get_headset_info();
        if (headset_state > 0) {
            break;
        } else {
            LOGD("[FM]waiting for insert headset device\n");
            sprintf(fmEntry.value.name, "%s", uistr_info_fmr_no_headset_warning);
            //iv->redraw(iv);
            drawItemValueBehind(&fmEntry);
            usleep(1000*1000);//sleep 1s
        }
    }
    if (headset_state <= 0) {
        LOGD("[FM]no headset device\n");
        return -1;
    }
#endif
    LOGD("[FM]init audio device\n");
    strcpy(fmEntry.value.name,uistr_info_waiting);
    drawItemValueBehind(&fmEntry);
    pthread_mutex_lock(&audioMutex);//xuzhaoyou marked
    sleep(1);
    Common_Audio_init();

    /* initialize thread condition */
    read_preferred_freq();
    fmr->exit_thd = false;
    fmr->result = false;

    pthread_create(&fmr->update_thd, NULL, fm_update_thread, fmr);
    pthread_create(&fmr->record_thd, NULL, Audio_Record_thread, fmr);
#if (defined MT5192_FM || defined MT5193_FM) && defined FM_DIGITAL_INPUT
    Audio_enable = false;
    mI2Sdriver = I2SGetInstance();
    if(mI2Sdriver == NULL){
       LOGD("I2S driver doesn't exists\n");
       goto FM_EXIT;
    }
    mI2Sid = I2SOpen(mI2Sdriver);
    if(mI2Sid == 0){
       LOGD("I2S driver get ID fail\n");
       goto FM_EXIT;
    }
    pthread_create(&fmr->mAudioThread, NULL, fm_audio_thread, priv);
#endif

    drawItemValueBehind(&fmEntry);
    //iv->redraw(iv);


	do {
	    g_setfreq = 1;
	    g_freq_item = 0;
	    usleep(200 * 1000); // update every 200ms
	    LOGD("para checking\n");
	} while (false == g_check_done && fmthreadrun);
	g_setfreq = 0;

	rawVal = ftm_get_prop("FMRadio.PlayTime"); // Delay enough time for playing
	if (rawVal != NULL)
	{
	    LOGD("FTMFMPlayTime = %s\n", rawVal);
	    sleep(atoi(rawVal));
	}else{
		sleep(10);
	}

	rssi_th = read_rssi_th();
	if (g_rssi >= rssi_th) {
	    LOGD("check pass\n");
	    fmEntry.state = TEST_PASS;
	    fmEntry.value.color = GREENCOLOR;
		snprintf(fmEntry.value.name+strlen(fmEntry.value.name), sizeof(fmEntry.value.name)-strlen(fmEntry.value.name)-1, uistr_info_fmr_pass, rssi_th);
	} else {
	    fmEntry.state = TEST_FAIL;
	    LOGD("check fail\n");
		snprintf(fmEntry.value.name+strlen(fmEntry.value.name), sizeof(fmEntry.value.name)-strlen(fmEntry.value.name)-1, uistr_info_fmr_failed, rssi_th);
		
	}
	drawItemValueBehind(&fmEntry);
	fmr->exit_thd = true;

	usleep(2000 * 1000); // delay 2000ms
	g_check_done = false;
	exit = true;


FM_EXIT:
    pthread_join(fmr->update_thd, NULL);
    pthread_join(fmr->record_thd, NULL);
#if (defined MT5192_FM || defined MT5193_FM) && defined FM_DIGITAL_INPUT
    I2SClose(mI2Sdriver,mI2Sid);
    //free I2S instance
    I2SFreeInstance(mI2Sdriver);
    mI2Sdriver = NULL;
    pthread_join(fmr->mAudioThread, NULL);
#endif
    Common_Audio_deinit();
    pthread_mutex_unlock(&audioMutex);//xuzhaoyou marked
    if (fmr != NULL)
    {
    	free(fmr);
    }
    LOGD("FM out\n");
    setProinfoItemResult(fmEntry.id,fmEntry.state);
    return 0;
}

void * jlink_fm_start(void *para){

    fmthreadrun = 1;
    drawTestItem(&fmEntry);
    fm_start();
    //emmc_update_info(headsetEntry.value.name);
    //drawItemValueBehind(&headsetEntry);
    pthread_exit(NULL);
	return NULL;
}


void jlink_fm_stop(){
    fmthreadrun = 0;
}