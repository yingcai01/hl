#include "jlinkui.h"



#define LIMITNUM 3

extern TestEntry memEntry;


static int getMemSize(){
  char buf[100] = {0};
  FILE *file = fopen("/proc/meminfo","r");
  char * tem = NULL;
  if (file!=NULL){
    while((tem=fgets(buf,100,file))!=NULL){
      if (strstr(buf,"MemTotal:")!=NULL)
        break;
      tem = NULL;
    }
  }
  if (file != NULL) fclose(file);

  if (tem!=NULL){
    
    tem = strtok(buf," ");
    while(tem != NULL){
      if((tem = strtok(NULL," "))!=NULL){
        if (*tem>= '0' && *tem <= '9'){
          break;
        }
      }
    }
    int sizekb = atoi(tem);
    LOGD("MYTEST,sizekb:%d",sizekb);
    int size = sizekb/1024;
    //size = (size/512+1)*512;
    return size;
  }
    
  return 0;
}

static int getMemAvalSize(){
  char buf[100] = {0};
  FILE *file = fopen("/proc/meminfo","r");
  char * tem = NULL;
  if (file!=NULL){
    while((tem=fgets(buf,100,file))!=NULL){
      if (strstr(buf,"MemAvailable:")!=NULL)
        break;
      tem = NULL;
    }
  }
  if (file != NULL) fclose(file);

  if (tem!=NULL){
    
    tem = strtok(buf," ");
    while(tem != NULL){
      if((tem = strtok(NULL," "))!=NULL){
        if (*tem>= '0' && *tem <= '9'){
          break;
        }
      }
    }
    int sizekb = atoi(tem);
    LOGD("MYTEST,sizekb:%d",sizekb);
    int size = sizekb/1024;
    //size = (size/512+1)*512;
    return size;
  }
    
  return 0;
}

static void *mtest_update_iv_thread(void *priv)
{
	int i,numlog = 0;
	char buf[60][100] = {0};//60条足够不会溢出
  int sizeMaval = getMemAvalSize();
  char cmd[100]={0};
  if (sizeMaval>100){
    sprintf(cmd,"/system/bin/mem_test -M %d -s 10 -m 4 -C 4 -W\0",(sizeMaval-100));
  }else{
    sprintf(cmd,"/system/bin/mem_test -s 10 -m 4 -C 4 -W\0");
  }
  FILE *pf = popen((const char*)cmd,"r");
  int length;
  memEntry.state = TEST_FAIL;
	int mem_result = 0;
  while (fgets(buf[numlog],200,pf)!=NULL)
  {
    length = 0;
    LOGD("MYTEST,log:%s",buf[numlog]);
   	numlog++;
   	if(numlog>LIMITNUM){
      for (i = numlog-LIMITNUM; i < numlog; ++i)
      {
        length += sprintf(memEntry.value.name+length,"%s",buf[i]);
      }
 		}else{
      for (i = 0; i < numlog; ++i)
      {
        length += sprintf(memEntry.value.name+length,"%s",buf[i]);
      }
 		}
 		drawItemValueAuto(&memEntry);
      if (strstr(buf[numlog-1],"PASS")!=NULL){
        memEntry.state = TEST_PASS;
		mem_result = 1;
      }
  }
	if(mem_result == 0)
	{
		memEntry.value.color = REDCOLOR;
		drawItemValueAuto(&memEntry);
	}
  setProinfoItemResult(memEntry.id,memEntry.state);
  numlog = numlog-2;//最后一行有输出空白
  strcpy(memEntry.value.name, buf[numlog]);
  LOGD("MYTEST buf[%d]=%s",numlog,buf[numlog]);
  int sizeM = getMemSize();
  if (sizeM!=0){
    sprintf(memEntry.entry.name,"%s(%dM)",memEntry.entry.name,sizeM);
  }else{
    strcat(memEntry.entry.name,"(未知大小)");
  } 
  pclose(pf);
  return NULL;
}

static pthread_t mem_handle;
int jlink_mtest_entry()
{
    LOGD(TAG "%s\n", __FUNCTION__);
    pthread_create(&mem_handle, NULL, mtest_update_iv_thread, NULL);
    pthread_join(mem_handle, NULL);
    return 0;
}

extern void rebackEntryDisplay();
void * jlink_mem_start(void*para){

  memEntry.entry.row = 5;
  drawTestItem(&memEntry);
  jlink_mtest_entry();
  rebackEntryDisplay();
  return NULL;
}