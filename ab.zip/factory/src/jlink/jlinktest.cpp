#include <ctype.h>
#include <pthread.h>
#include <acdk/MdkIF.h>
#include <cutils/properties.h>


extern "C" {
	#include "jlinkui.h"
	#include "graphics.h"
}
typedef void* gr_surface;
void* jlink_start_camera(void* id);
void jlink_test_text();
void jlink_draw_image();
void* jlink_draw_button(void*);
void* jlink_draw_progressbar(void* para);
void* jlink_draw_exitbtn(void*);
void* jlink_draw_clearbtn(void*);
void* jlink_draw_speakerbtn(void*);
void loop();
void looptime(int count);
extern "C" {
//	void drawTestItem(TestEntry *testentry);
	void jlink_ui_init();
//	void drawUpdateTestItem(TestEntry *testentry);
	void runAnima(TestEntry *testentry);
//	void drawItemValueBehind(TestEntry *testentry);
	void clearRow(int row);
	int res_create_display_surface(const char* name, GRSurface** pSurface);
	void res_free_surface(GRSurface* surface);
//	void draw_image(int x,int y,GRSurface* frame);
	int res_create_surface(const char* fname, gr_surface* pSurface);
	void draw_background_locked(gr_surface icon);
	void draw_progressbar(ProgressBar bar);
//	void draw_button(Button* button);
//	void startListener();
//	void addButtionCallback(ButtonEntry* entry);
//	void drawColorBand();
	void* jlink_key_start(void*para);
	void jlink_key_stop();
	//void* start_touch_tp(void*para);
	void * jlink_heaset_start(void *para);
	void stopHeadset();
	void * jlink_emmc_start(void*para);
	void * jlink_sdcard_start(void*para);
	void * jlink_gps_start(void*para);
	void jlink_stop_gpstest();
	void * jlink_bt_start(void*para);
	void stopBt();
	void * jlink_vibrator_start(void*para);
	void * jlink_backlight_start(void*para);
	void * jlink_otg_start(void*para);
	void * jlink_gsensor_start(void*para);
	void jlink_gsensor_stop();
	void * jlink_alps_start(void*para);
	void stop_alps();
	void * jlink_mem_start(void*para);
	void * jlink_wifi_start(void*para);
	void   jlink_stop_tp();
	void * jlink_fm_start(void *para);
	void jlink_fm_stop();
	void* jlink_hdmi_start(void* para);
	void jlink_stop_hdmi();
	void* jlink_gyro_start(void *para);
	void stop_gyro();
    void * jlink_dc_start(void*para);
	//int jlink_audio_start();
	
}

extern void * jlink_rtc_start(void*para);
extern void * jlink_micspeaker_start(void*para);
extern 	void* jlink_camera_start(void *para);
void jlink_camerastop();
extern void * jlink_strobe_start(void*para);
extern void * jlink_receiver_start(void*para);
extern void * jlink_speaker_start(void*para);
extern void stopSpeaker();


pthread_t handle_image;
pthread_t handle_button;
extern int jlcd_width;
extern int jlcd_height;

static pthread_t alps_handle;
static pthread_t headset_handle;
static pthread_t key_handle;
static pthread_t touch_handle;
static pthread_t emmc_handle;
static pthread_t sdcard_handle;
static pthread_t gps_handle;
static pthread_t bt_handle;
static pthread_t camera_handle;
static pthread_t micspeaker_handle;
static pthread_t vibrator_handle;
static pthread_t backlight_handle;
static pthread_t otg_handle;
static pthread_t rtc_handle;
static pthread_t gsensor_handle;
static pthread_t mem_handle;
static pthread_t wifi_handle;
static pthread_t fm_handle;
static pthread_t strobe_handle;
static pthread_t receiver_handle;
static pthread_t hdmi_handle;
static pthread_t gyro_handle;
static pthread_t flip_handle;
static pthread_t dc_handle;
extern int currentrow;
static int id = 1;
enum testrow {
#ifdef HAS_ALPS
	alpsrow,
#endif
	headsetrow = 1,
#ifdef DC_PROJECT
    dcrow,
#endif
	keyrow,
	emmcrow,
	sdcardrow,
#ifdef PROJECT_GROSCOPE
	gyrorow,
#endif
#ifdef HDMI_PROJECT
	hdmirow,
#endif
	gpsrow,
#ifdef MTK_WLAN_SUPPORT
#ifdef FEATURE_FTM_WIFI
	wifirow,
#endif
#endif
	btrow,
#ifdef JRECEVIER_PROJECT
	recrow,
#endif
	micspkrow,
	vibrow,
	bklightrow,
	otgrow,
	rtcrow,
#ifndef PROJECT_NOCAM
	srtoberow,
#endif
	gsensorow,
	fmrow,
	memorow = fmrow+4,
};

TestEntry alpsEntry;
TestEntry micspkEntry;
TestEntry backlightEntry;
TestEntry btEntry;
TestEntry emmcEntry;
TestEntry fmEntry;
TestEntry gpsEntry;
TestEntry gsensorEntry;
TestEntry headsetEntry;
TestEntry keyentry;
TestEntry memEntry;
TestEntry otgEntry;
TestEntry rtcEntry;
TestEntry sdcardEntry;
TestEntry srobeEntry;
TestEntry vibEntry;
TestEntry wifiEntry;
TestEntry recEntry;
TestEntry hdmiEntry;
TestEntry mainCamEntry;
TestEntry subCamEntry;
TestEntry tpEntry;
TestEntry gyroEntry;
TestEntry nfcEntry;
TestEntry dcEntry;

Button backbutton;
Button cambutton;
Button strobebutton;
Button vibbutton;
Button sigbutton;
Button exitbutton;
Button wifibutton;//add
Button clearbutton;//自己刷新
Button recbutton;
Button speakerbutton;

static Button* btnlist[] = {
	&backbutton,
#ifndef PROJECT_NOCAM
	&cambutton,
#endif
#ifndef PROJECT_NOCAM
	&strobebutton,
#endif
	&vibbutton,
	&wifibutton,
//	&sigbutton,
	&exitbutton,
#ifdef JRECEVIER_PROJECT
	&recbutton,
#endif
        &speakerbutton,
};

static TestEntry* entryList[] ={
#ifdef HAS_ALPS
	&alpsEntry,
#endif
	&micspkEntry,
	&backlightEntry,
	&btEntry,
	&emmcEntry,
	&fmEntry,
	&gpsEntry,
	&gsensorEntry,
#ifdef PROJECT_GROSCOPE
	&gyroEntry,
#endif
	&headsetEntry,
	&keyentry,
	&memEntry,
	&otgEntry,
	&rtcEntry,
	&sdcardEntry,
#ifndef PROJECT_NOCAM
	&srobeEntry,
#endif
	&vibEntry,
#ifdef MTK_WLAN_SUPPORT
#ifdef FEATURE_FTM_WIFI
	&wifiEntry,
#endif
#endif
#ifdef PROJECT_NFC
	&nfcEntry,
#endif
#ifdef JRECEVIER_PROJECT
	&recEntry,
#endif
#ifdef HDMI_PROJECT
	&hdmiEntry,
#endif
#ifdef DC_PROJECT
    &dcEntry,
#endif
};


static TestEntry* reportEntryList[] ={
#ifdef HAS_ALPS
	&alpsEntry,
#endif
	&micspkEntry,
	&backlightEntry,
	&btEntry,
	&emmcEntry,
	&fmEntry,
	&gpsEntry,
	&gsensorEntry,
#ifdef PROJECT_GROSCOPE
	&gyroEntry,
#endif
	&headsetEntry,
	&keyentry,
	&memEntry,
	&otgEntry,
	&rtcEntry,
	&sdcardEntry,
#ifndef PROJECT_NOCAM
	&srobeEntry,
#endif
	&vibEntry,
#ifndef PROJECT_NOCAM
	&mainCamEntry,
	&subCamEntry,
#endif
	&tpEntry,
#ifdef MTK_WLAN_SUPPORT
#ifdef FEATURE_FTM_WIFI
	&wifiEntry,
#endif
#endif
#ifdef PROJECT_NFC
	&nfcEntry,
#endif

#ifdef JRECEVIER_PROJECT
	&recEntry,
#endif
#ifdef HDMI_PROJECT
	&hdmiEntry,
#endif
#ifdef DC_PROJECT
    &dcEntry,
#endif
};


static int loop_run = 1;
static int entrySize = sizeof(TestEntry);
static void initTestEntry(TestEntry *entry,const char* texttile,int row,int id,int valuecolor=REDCOLOR,JCallBack redraw=(JCallBack)drawItemValueBehind){
	memset(entry,0,entrySize);
    entry->entry.color = YELLOWCOLOR;
    entry->entry.row = row;
    entry->entry.backcolor = BACKCOLOR;
    entry->entry.col = ITEMCOL;
    strcpy(entry->entry.name,texttile);
    entry->value.color = valuecolor;
    entry->value.backcolor = BACKCOLOR;
    entry->redraw = redraw;
    entry->id = id;
}

extern "C" void rebackEntryDisplay(){
	memEntry.entry.row = memorow;
}

static void initAllEntry(){
#ifdef HAS_ALPS
	initTestEntry(&alpsEntry,uistr_als_ps_jlink,alpsrow,JILNK_ITEM_ALSPS);
#endif
	initTestEntry(&micspkEntry,uistr_info_phone_mic_speaker,micspkrow,JILNK_ITEM_LOOPBACK_PHONEMICSPK);
	initTestEntry(&backlightEntry,uistr_backlight_level,bklightrow,JILNK_ITEM_LCD,GREENCOLOR);
	initTestEntry(&btEntry,uistr_bluetooth,btrow,JILNK_ITEM_BT,REDCOLOR,(JCallBack)drawItemValueBehindLine);	
	initTestEntry(&fmEntry,uistr_info_fmr_title,fmrow,JILNK_ITEM_FM);
	initTestEntry(&emmcEntry,uistr_info_emmc,emmcrow,JILNK_ITEM_EMMC,GREENCOLOR);
	initTestEntry(&gpsEntry,uistr_gps,gpsrow,JILNK_ITEM_GPS,GREENCOLOR);
	initTestEntry(&gsensorEntry,uistr_g_sensor,gsensorow,JILNK_ITEM_GSENSOR,GREENCOLOR);

#ifdef PROJECT_GROSCOPE
	initTestEntry(&gyroEntry,uistr_info_gyro,gyrorow,JILNK_ITEM_GYROSCOPE,GREENCOLOR);
#endif
	initTestEntry(&headsetEntry,uistr_info_headset,headsetrow,JILNK_ITEM_HEADSET);

	initTestEntry(&keyentry,uistr_keys,keyrow,JILNK_ITEM_KEYS);

	initTestEntry(&otgEntry,uistr_info_otg_status,otgrow,JILNK_ITEM_OTG,REDCOLOR);
	initTestEntry(&rtcEntry,uistr_rtc,rtcrow,JILNK_ITEM_RTC,GREENCOLOR);
	initTestEntry(&sdcardEntry,uistr_info_sd,sdcardrow,JILNK_ITEM_MEMCARD,GREENCOLOR);
#ifndef PROJECT_NOCAM
	initTestEntry(&srobeEntry,uistr_strobe,srtoberow,JILNK_ITEM_STROBE,GREENCOLOR);
#endif
	initTestEntry(&vibEntry,uistr_vibrator,vibrow,JILNK_ITEM_VIBRATOR,GREENCOLOR);
#ifdef MTK_WLAN_SUPPORT
#ifdef FEATURE_FTM_WIFI
	initTestEntry(&wifiEntry,uistr_wifi,wifirow,JILNK_ITEM_WIFI);
#endif
#endif
	initTestEntry(&memEntry,uistr_info_memtest,memorow,JILNK_ITEM_MEMORY,GREENCOLOR,(JCallBack)drawItemValueAuto);
#ifdef JRECEVIER_PROJECT
	initTestEntry(&recEntry,uistr_info_audio_receiver,recrow,JILNK_ITEM_RECEIVER,GREENCOLOR);
#endif
#ifdef HDMI_PROJECT
	initTestEntry(&hdmiEntry,uistr_info_hdmi,hdmirow,JILNK_ITEM_HDMI);
#endif
#ifdef DC_PROJECT
    initTestEntry(&dcEntry,uistr_info_dctitle,dcrow,JILNK_ITEM_DC);
#endif

}
static void initAllButton(){
	int length = sizeof(btnlist)/sizeof(btnlist[0]);
	for(int i = 0;i<length;i++){
		btnlist[i]->state=BTN_HIDDEN;
	}
}

static void reDrawAllButton(){
	int length = sizeof(btnlist)/sizeof(btnlist[0]);
	for(int i = 0;i<length;i++){
		if (btnlist[i]->state!=BTN_HIDDEN)
		{
			draw_button(btnlist[i]);
		}
	}
}

static void reDrawAllItem(){
	int length = sizeof(entryList)/sizeof(entryList[0]);
	for(int i = 0;i<length;i++){
		drawTestItem(entryList[i]);
		entryList[i]->redraw(entryList[i]);
	}
}

static void* WashScreen(void*para){
	clearScreen();
	reDrawAllItem();
	reDrawAllButton();//后绘按钮不然会被刷掉
	drawColorBand();
	draw_button(&clearbutton);
	return NULL;
}


extern "C" void jlink_start_gamekey();
extern "C" void jlink_start_gamekey_H69();
void start_all_test(){



#ifdef PROJECT_NOKEY
	clearScreen();
    #ifdef PROJECT_H69
	jlink_start_gamekey_H69();
    #else
	jlink_start_gamekey();
	#endif
#endif
	WashScreen(NULL);

#ifndef PROJECT_NOCAM
	pthread_create(&camera_handle,NULL,jlink_camera_start,NULL);
#endif
#ifdef HAS_ALPS
	pthread_create(&alps_handle,NULL,jlink_alps_start,NULL);
#endif
	pthread_create(&headset_handle,NULL,jlink_heaset_start,NULL);
#ifndef PROJECT_NOKEY
	pthread_create(&key_handle,NULL,jlink_key_start,NULL);
#endif

	pthread_create(&emmc_handle,NULL,jlink_emmc_start,NULL);
	pthread_create(&sdcard_handle,NULL,jlink_sdcard_start,NULL);

	pthread_create(&gps_handle,NULL,jlink_gps_start,NULL);
	pthread_create(&bt_handle,NULL,jlink_bt_start,NULL);
	pthread_create(&micspeaker_handle,NULL,jlink_micspeaker_start,NULL);

	pthread_create(&vibrator_handle,NULL,jlink_vibrator_start,NULL);
	pthread_create(&backlight_handle,NULL,jlink_backlight_start,NULL);

	pthread_create(&otg_handle,NULL,jlink_otg_start,NULL);
	pthread_create(&rtc_handle,NULL,jlink_rtc_start,NULL);
#ifndef PROJECT_NOCAM
	pthread_create(&strobe_handle,NULL,jlink_strobe_start,NULL);
#endif
#ifdef MTK_WLAN_SUPPORT
#ifdef FEATURE_FTM_WIFI
	pthread_create(&wifi_handle,NULL,jlink_wifi_start,NULL);
#endif
#endif
	pthread_create(&gsensor_handle,NULL,jlink_gsensor_start,NULL);
	pthread_create(&fm_handle,NULL,jlink_fm_start,NULL);
#ifdef JRECEVIER_PROJECT
	pthread_create(&receiver_handle,NULL,jlink_receiver_start,NULL);
#endif
#ifdef HDMI_PROJECT
	pthread_create(&hdmi_handle,NULL,jlink_hdmi_start,NULL);
#endif
#ifdef PROJECT_GROSCOPE
	pthread_create(&gyro_handle,NULL,jlink_gyro_start,NULL);
#endif
#ifdef DC_PROJECT
    pthread_create(&dc_handle,NULL,jlink_dc_start,NULL);
#endif

}
extern "C" void ui_clear_key_queue();
void createTestPort(){
	jlink_ui_init();
	clearScreen();
	ui_flip();
#ifdef PROJECT_H55
	int i = 1;
#else
	int i = 0;
#endif
	initProinfoData();
#ifdef HAS_ALPS
	initTestEntry(&alpsEntry,uistr_als_ps_jlink,i++,JILNK_ITEM_ALSPS);
#endif
	initTestEntry(&micspkEntry,uistr_info_phone_mic_speaker,i++,JILNK_ITEM_LOOPBACK_PHONEMICSPK);
	initTestEntry(&backlightEntry,uistr_backlight_level,i++,JILNK_ITEM_LCD,GREENCOLOR);
	initTestEntry(&btEntry,uistr_bluetooth,i++,JILNK_ITEM_BT,REDCOLOR,(JCallBack)drawItemValueBehindLine);	
	initTestEntry(&fmEntry,uistr_info_fmr_title,i++,JILNK_ITEM_FM);
	initTestEntry(&emmcEntry,uistr_info_emmc,i++,JILNK_ITEM_EMMC,GREENCOLOR);
	initTestEntry(&gpsEntry,uistr_gps,i++,JILNK_ITEM_GPS,GREENCOLOR);


	initTestEntry(&gsensorEntry,uistr_g_sensor,i++,JILNK_ITEM_GSENSOR,GREENCOLOR);


	initTestEntry(&headsetEntry,uistr_info_headset,i++,JILNK_ITEM_HEADSET);
	initTestEntry(&keyentry,uistr_keys,i++,JILNK_ITEM_KEYS);
	initTestEntry(&otgEntry,uistr_info_otg_status,i++,JILNK_ITEM_OTG,GREENCOLOR);
	initTestEntry(&rtcEntry,uistr_rtc,i++,JILNK_ITEM_RTC,GREENCOLOR);
	initTestEntry(&sdcardEntry,uistr_info_sd,i++,JILNK_ITEM_MEMCARD,GREENCOLOR);
#ifndef PROJECT_NOCAM
	initTestEntry(&srobeEntry,uistr_strobe,i++,JILNK_ITEM_STROBE,GREENCOLOR);
#endif
	initTestEntry(&vibEntry,uistr_vibrator,i++,JILNK_ITEM_VIBRATOR,GREENCOLOR);
#ifdef MTK_WLAN_SUPPORT
#ifdef FEATURE_FTM_WIFI
	initTestEntry(&wifiEntry,uistr_wifi,i++,JILNK_ITEM_WIFI);
#endif
#endif
	initTestEntry(&memEntry,uistr_info_memtest,i++,JILNK_ITEM_MEMORY,GREENCOLOR,(JCallBack)drawItemValueAuto);
#ifndef PROJECT_NOCAM
	initTestEntry(&mainCamEntry,uistr_main_sensor,i++,JILNK_ITEM_MAIN_CAMERA);
	initTestEntry(&subCamEntry,uistr_sub_sensor,i++,JILNK_ITEM_SUB_CAMERA);
#endif
	initTestEntry(&tpEntry,uistr_touch,i++,JILNK_ITEM_TOUCH);
#ifdef JRECEVIER_PROJECT
	initTestEntry(&recEntry,uistr_info_audio_receiver,i++,JILNK_ITEM_RECEIVER,GREENCOLOR);
#endif
#ifdef PROJECT_GROSCOPE
	initTestEntry(&gyroEntry,uistr_info_gyro,i++,JILNK_ITEM_GYROSCOPE,GREENCOLOR);
#endif
#ifdef HDMI_PROJECT
	initTestEntry(&hdmiEntry,uistr_info_hdmi,i++,JILNK_ITEM_HDMI);
#endif
#ifdef DC_PROJECT
    initTestEntry(&dcEntry,uistr_info_dctitle,i++,JILNK_ITEM_DC);
#endif


	int length = sizeof(reportEntryList)/sizeof(reportEntryList[0]);
	int result = 0;
	for(i = 0;i<length;i++){
		result = getItemResult(reportEntryList[i]->id);
		if (result == 1){
			reportEntryList[i]->value.color = GREENCOLOR;
			strcpy(reportEntryList[i]->value.name, uistr_info_pass);
		}else if (result == 2){
			reportEntryList[i]->value.color = REDCOLOR;
			strcpy(reportEntryList[i]->value.name, uistr_info_fail);
		}else{
			reportEntryList[i]->value.color = REDCOLOR;
			strcpy(reportEntryList[i]->value.name, uistr_info_notest);
		}
		drawTestItem(reportEntryList[i]);
		drawItemValueBehind(reportEntryList[i]);
	}

	ui_flip();
	struct timespec ntime;
	ntime.tv_sec= time(NULL)+20;
	ntime.tv_nsec=0;
	ui_clear_key_queue();
	int key;
	while(1){
		key = jlink_wait_key(&ntime);
		if(key==114 || key == 115 || key == 116){
			break;
		}
	}
}

void wait_thread_quit(){
	int length = sizeof(btnlist)/sizeof(btnlist[0]);
	for(int i=0;i<length;i++){
		if (btnlist[i]->pthread_handle!=0)
		{
			if(pthread_kill(btnlist[i]->pthread_handle,0)==0){
				pthread_join(btnlist[i]->pthread_handle,NULL);
			}
		}
	}
}

extern void jlink_camerastaop();
void* doExit(void*para){
        stopSpeaker();
	//首先退出camera,若让刷新屏幕线程先退出,camera退出后会把屏幕刷黑屏一段时间
	LOGD("MYTEST doExit camera");
	jlink_camerastop();
	if (pthread_kill(camera_handle,0)==0){
		LOGD("MYTEST doExit camera1");
		pthread_join(camera_handle,NULL);
		LOGD("MYTEST doExit camera2");
	}
	exitListener();	
	if (pthread_kill(flip_handle,0)==0){
		pthread_join(flip_handle,NULL);
	}

#ifndef PROJECT_NOKEY
	LOGD("MYTEST doExit key");
	if (pthread_kill(key_handle,0)==0){
		jlink_key_stop();
		pthread_join(key_handle,NULL);
	}
#endif

#ifdef HAS_ALPS
	LOGD("MYTEST doExit alps");
	if (pthread_kill(alps_handle,0)==0){
		stop_alps();
		pthread_join(alps_handle,NULL);
	}
#endif
	
	LOGD("MYTEST doExit headset");
	if (pthread_kill(headset_handle,0)==0){
		stopHeadset();
		pthread_join(headset_handle,NULL);
	}
	LOGD("MYTEST doExit emmc");
	if (pthread_kill(emmc_handle,0)==0){
		pthread_join(emmc_handle,NULL);
	}
	LOGD("MYTEST doExit sdcard");
	if (pthread_kill(sdcard_handle,0)==0){
		pthread_join(sdcard_handle,NULL);
	}

	LOGD("MYTEST doExit gps");
	if (pthread_kill(gps_handle,0)==0){
		jlink_stop_gpstest();
		pthread_join(gps_handle,NULL);
	}
	LOGD("MYTEST doExit bt");
	stopBt();
	if (pthread_kill(bt_handle,0)==0){
		pthread_join(bt_handle,NULL);
	}
#if 0
	LOGD("MYTEST doExit micspeaker");
	if (pthread_kill(micspeaker_handle,0)==0){
		pthread_join(micspeaker_handle,NULL);
	}
#endif
	LOGD("MYTEST doExit vibrator");
	if (pthread_kill(vibrator_handle,0)==0){
		pthread_join(vibrator_handle,NULL);
	}
	LOGD("MYTEST doExit backliaght");
	if (pthread_kill(backlight_handle,0)==0){
		pthread_join(backlight_handle,NULL);
	}
	LOGD("MYTEST doExit otg");
	if (pthread_kill(otg_handle,0)==0){
		pthread_join(otg_handle,NULL);
	}
	LOGD("MYTEST doExit rtc");
	if (pthread_kill(rtc_handle,0)==0){
		pthread_join(rtc_handle,NULL);
	}
	#ifndef PROJECT_NOCAM
	LOGD("MYTEST doExit strobe");
	if (pthread_kill(strobe_handle,0)==0){
		pthread_join(strobe_handle,NULL);
	}
	#endif
	LOGD("MYTEST doExit wifi");
	if (pthread_kill(wifi_handle,0)==0){
		pthread_join(wifi_handle,NULL);
	}
	LOGD("MYTEST doExit gsensor");
	if (pthread_kill(gsensor_handle,0)==0){
		jlink_gsensor_stop();
		pthread_join(gsensor_handle,NULL);
	}
	LOGD("MYTEST doExit mem");
	if (pthread_kill(mem_handle,0)==0){
		pthread_join(mem_handle,NULL);
	}
	LOGD("MYTEST doExit fm");
	if (pthread_kill(fm_handle,0)==0){
		jlink_fm_stop();
		pthread_join(fm_handle,NULL);
	}
#ifdef JRECEVIER_PROJECT
	LOGD("MYTEST doExit receiver");
	if (pthread_kill(receiver_handle,0)==0){
		pthread_join(receiver_handle,NULL);
	}
#endif
#ifdef PROJECT_GROSCOPE
	stop_gyro();
	LOGD("MYTEST doExit gyroscope");
	if (pthread_kill(gyro_handle,0)==0){
		pthread_join(gyro_handle,NULL);
	}
#endif
#ifdef HDMI_PROJECT
	LOGD("MYTEST doExit hdmi");
	if (pthread_kill(hdmi_handle,0)==0){
		jlink_stop_hdmi();
		pthread_join(hdmi_handle,NULL);
	}
#endif
#ifdef DC_PROJECT
	LOGD("MYTEST doExit dc");
	if (pthread_kill(dc_handle,0)==0){
		pthread_join(dc_handle,NULL);
	}
#endif
	LOGD("MYTEST doExit btn");
	wait_thread_quit();
	LOGD("MYTEST doExit end");
	loop_run = 0;
	return NULL;
}

int ismodemboot = 0;
void*waitForModem(void*para){
	char modemStatus[PROPERTY_VALUE_MAX] = {0};
	while(1){
		property_get("mtk.md1.status", modemStatus, "");
		if (strcmp(modemStatus, "ready") == 0){
			ismodemboot = 1;
			break;
		} 
		usleep(300000);
	}
	return NULL;	
}


void ChangeRows(){
	if (jlcd_width<jlcd_height)
	{
		memEntry.entry.row += 1;
	}
}


static pthread_t modem_handle;
static pthread_t exit_handle;
static pthread_t listener_handle;
static pthread_t tp_handle;
extern pthread_mutex_t jlink_tp_mutext;
extern "C" void jlink_tp_touch();
extern "C" void drawKeyPad();
int jlink_all_start(){
	loop_run = 1;
	//pthread_create(&modem_handle,NULL,waitForModem, NULL);
	ChangeRows();
	jlink_ui_init();
	show_slash_screen(uistr_factory_mode, 500);
	clearScreen();
	initProinfoData();
	initAllEntry();
	initAllButton();
	initButtonCallbcak();
#ifndef JLINK_ITEM_DEBUG
	pthread_create(&flip_handle,NULL,do_clip_loop, NULL);
	jlink_mem_start(NULL);
	pthread_create(&tp_handle,NULL,startListener,NULL);
#endif
	jlink_tp_touch();
	pthread_mutex_lock(&jlink_tp_mutext);
	start_all_test();
	pthread_mutex_unlock(&jlink_tp_mutext);
	//drawColorBand();
	pthread_create(&exit_handle,NULL,jlink_draw_exitbtn,NULL);
        jlink_draw_speakerbtn(NULL);
	jlink_draw_clearbtn(NULL);
	//startListener(); //start_touch_tp处理
	loop();
	return 0;
}

void loop(){
	while (loop_run)
    {
    	usleep(1000000);
    };
}

void looptime(int count){
	while (count--)
    {
    	usleep(1000000);
    };
}

extern void setJCameraPara(int x,int y,int width,int height,int orientation);
extern int acdkIFInit();
extern MINT32 camera_preview_test();
extern int camera_preview_stop(void);
extern int camera_reset_layer_buffer(void);
extern int camera_capture_test();
extern int gcamera_autoTest;
extern void setCameraID(int id);
static int iscameraopen = 0;


void* jlink_start_camera(void *id){
	if (iscameraopen==1)
	{
		return NULL;
	}
	iscameraopen=1;
	int cameraid = *((int*)id);
	LOGD("MYTEST cameraid=%d",cameraid);
	setCameraID(cameraid);
	gcamera_autoTest = 0;
	//最小176x144,320x240,352x288,480x320,480x368,640x480,720x480,800x480,800x600,864x480,
	//960x540,1024x768,1280x720,1280x736,1280x768,1280x960,1920x1080,1920x1088,1920x1280
	//最大大小以实际屏分辨率为准
	//注意屏幕的方向,可能图像方向的宽和高与实际屏不一致需调整宽和高位置同时旋转摄像头方向
	int prevw = 320;
	int prevh = 480;
	if (0 == strncmp(rotate_lcm, "90", 2))
	{
		setJCameraPara(jlcd_height-prevw,jlcd_width-prevh,prevw,prevh,270);
	}else if (0 == strncmp(rotate_lcm, "180", 3))
	{
		setJCameraPara(0,jlcd_height-prevh,prevw,prevh,270);
	}else if(0 == strncmp(rotate_lcm, "270", 3)){
		setJCameraPara(0,0,prevw,prevh,270);
	}else{
		setJCameraPara(jlcd_width-prevw,0,prevw,prevh,270);
	}
	
	if(acdkIFInit()!=0){
		Mdk_DeInit();
        Mdk_Close();
        return NULL;
	}else{
		camera_preview_test();
		loop();
        camera_preview_stop();
		camera_reset_layer_buffer();
	}
	iscameraopen=0;
	pthread_exit(NULL);
	return NULL;
}



static int prevw = CAMERA_PRE_HEIGHT;
static int prevh = CAMERA_PRE_WIDTH;
ButtonEntry exittnentry;
void* jlink_draw_exitbtn(void*){
	memset(&exitbutton, '\0', sizeof(exitbutton));
	exitbutton.disenable_color = 0x555555FF;
	exitbutton.back_color = 0x348646FF;
	exitbutton.press_color = 0xff0000ff;
	exitbutton.text_color = 0x989234ff;
	exitbutton.width=250;
	exitbutton.height=60;
	if (0 == strncmp(rotate_lcm, "90", 2))
	{
		exitbutton.x=jlcd_width-(exitbutton.width+prevh)/2;
		exitbutton.y=prevw+240;
	}else if (0 == strncmp(rotate_lcm, "180", 3))
	{
		exitbutton.x=jlcd_width-(exitbutton.width+prevw)/2;
		exitbutton.y=prevh+240;
	}else if(0 == strncmp(rotate_lcm, "270", 3)){
		exitbutton.x=jlcd_width-(exitbutton.width+prevh)/2;
		exitbutton.y=prevw+240;
	}else{
		exitbutton.x=jlcd_width-(exitbutton.width+prevw)/2;;
		exitbutton.y=prevh+240;
	}
	exitbutton.onClickListener=doExit;
	strcpy(exitbutton.text,uistr_info_testexit);
	exitbutton.state = BTN_HIDDEN;//防止被清理屏幕按钮刷出来
	sleep(15);//15秒后才显示
	exitbutton.state = BTN_NORMAL;
	draw_button(&exitbutton);
	exittnentry.btn = &exitbutton;
	exittnentry.next=NULL;
	addButtionCallback(&exittnentry);
	pthread_exit(NULL);
	return NULL;
}

ButtonEntry clearbtnentry;
void* jlink_draw_clearbtn(void*){
	memset(&clearbutton, '\0', sizeof(clearbutton));
	clearbutton.disenable_color = 0x555555FF;
	clearbutton.back_color = 0x348646FF;
	clearbutton.press_color = 0xff0000ff;
	clearbutton.text_color = 0x989234ff;
	clearbutton.width=250;
	clearbutton.height=60;
	if (0 == strncmp(rotate_lcm, "90", 2))
	{
		clearbutton.x=jlcd_width-(clearbutton.width+prevh)/2;
		clearbutton.y=prevw+100;
	}else if (0 == strncmp(rotate_lcm, "180", 3))
	{
		clearbutton.x=jlcd_width-(clearbutton.width+prevw)/2;
		clearbutton.y=prevh+100;
	}else if(0 == strncmp(rotate_lcm, "270", 3)){
		clearbutton.x=jlcd_width-(clearbutton.width+prevh)/2;
		clearbutton.y=prevw+100;
	}else{
		clearbutton.x=jlcd_width-(clearbutton.width+prevw)/2;;
		clearbutton.y=prevh+100;
	}
	
	clearbutton.onClickListener=WashScreen;
	strcpy(clearbutton.text,uistr_info_testwash);
	draw_button(&clearbutton);
	clearbtnentry.btn = &clearbutton;
	clearbtnentry.next=NULL;
	addButtionCallback(&clearbtnentry);
	return NULL;
}


ButtonEntry speakerbtnentry;
void* jlink_draw_speakerbtn(void*){
	memset(&speakerbutton, '\0', sizeof(speakerbutton));
	speakerbutton.disenable_color = 0x555555FF;
	speakerbutton.back_color = 0x348646FF;
	speakerbutton.press_color = 0xff0000ff;
	speakerbutton.text_color = 0x989234ff;
	speakerbutton.width=250;
	speakerbutton.height=60;
	if (0 == strncmp(rotate_lcm, "90", 2))
	{
		speakerbutton.x=jlcd_width-(speakerbutton.width+prevh)/2;
		speakerbutton.y=prevw+170;
	}else if (0 == strncmp(rotate_lcm, "180", 3))
	{
		speakerbutton.x=jlcd_width-(speakerbutton.width+prevw)/2;
		speakerbutton.y=prevh+170;
	}else if(0 == strncmp(rotate_lcm, "270", 3)){
		speakerbutton.x=jlcd_width-(speakerbutton.width+prevh)/2;
		speakerbutton.y=prevw+170;
	}else{
		speakerbutton.x=jlcd_width-(speakerbutton.width+prevw)/2;;
		speakerbutton.y=prevh+170;
	}
	speakerbutton.onClickListener=jlink_speaker_start;
	strcpy(speakerbutton.text,uistr_info_speakerbtntxt);
	speakerbutton.state = BTN_NORMAL;
	draw_button(&speakerbutton);
	speakerbtnentry.btn = &speakerbutton;
	speakerbtnentry.next=NULL;
	addButtionCallback(&speakerbtnentry);
	return NULL;
}


//*****************************demo****************************************/
//demo
/*
void jlink_test_text(){
	TestEntry entry;
	memset(&entry,'\0',sizeof(entry));
	entry.entry.row=1;
	entry.entry.col=1;
	strcpy(entry.entry.name,uistr_test_str);
	entry.entry.color=0xFFFF00FF;
	entry.hasani = 1;
	drawTestItem(&entry);
	strcpy(entry.value.name,uistr_test_str);
	entry.value.color=0x005012FF;
	drawItemValueBehind(&entry);
	TestEntry entry1;
	memset(&entry1,'\0',sizeof(entry1));
	entry1.entry.row=2;
	entry1.entry.col=4;
	entry1.hasani = 1;
	strcpy(entry1.entry.name,uistr_test2_str);
	entry1.entry.color=0xFF0000FF;
	drawUpdateTestItem(&entry1);
	TestEntry entry2;
	memset(&entry2,'\0',sizeof(entry1));
	entry2.entry.row=3;
	entry2.entry.col=4;
	entry2.hasani = 1;
	strcpy(entry2.entry.name,uistr_test2_str);
	entry2.entry.color=0xFF0000FF;
	drawUpdateTestItem(&entry2);
*/
	/*looptime(10);
	entry.state=TEST_PASS;
	entry.exit=1;
	looptime(5);
	entry1.state=NO_TEST;
	entry1.exit=1;
	looptime(5);
	entry2.state=TEST_FAIL;
	entry2.exit=1;*/

/*	
}

//demo
void jlink_draw_image(){
	gr_surface surface;
	//int ret = res_create_display_surface("icon_error",&surface);
	int ret = res_create_surface("/sdcard/icon_error.png",&surface);
	if(surface==NULL){
		return;
	}
	draw_image(100,300,(GRSurface*)surface);
	if (surface)
	{
		free(surface);
	}
}

//demo
void* jlink_draw_progressbar(void* para){
	gr_surface pro_empty_surface,pro_fill_surface;
	ProgressBar bar;
	res_create_surface("/sdcard/progress_empty.png",&pro_empty_surface);
	res_create_surface("/sdcard/progress_fill.png",&pro_fill_surface);
	bar.percent=0.5;
	bar.pro_empty_surface=(GRSurface *)pro_empty_surface;
	bar.pro_fill_surface=(GRSurface *)pro_fill_surface;
	bar.x = 100;
	bar.y = 600;
	struct timeval tpstart;
	gettimeofday(&tpstart,NULL);
	srand(tpstart.tv_usec);
	while(1) {
	    usleep(500000);
	    bar.percent=rand()/(RAND_MAX+1.0);
	    //LOGD("MYTEST bar.percent=%f",bar.percent);
	    draw_progressbar(bar);
	}
	if (pro_empty_surface)
	{
		free(pro_empty_surface);
	}
	if (pro_fill_surface)
	{
		free(pro_fill_surface);
	}
	return NULL;
	
}

//demo
void* jlink_draw_button(void*){
	Button button;
	memset(&button, '\0', sizeof(button));
	button.disenable_color = 0x555555FF;
	button.back_color = 0x348646FF;
	button.press_color = 0xff0000ff;
	button.text_color = 0x989234ff;
	button.x=100,
	button.y=800;
	button.width=500;
	button.height=100;
	int cameraid = 1;
	button.para = &cameraid;
	button.onClickListener=jlink_start_camera;
	char* text = "测试";//编码不文字不显示,此处文字不会显示
	strcpy(button.text,uistr_test4_str);
	draw_button(&button);
	ButtonEntry btnentry;
	btnentry.btn = &button;
	btnentry.next=NULL;

	addButtionCallback(&btnentry);
	startListener();
	return NULL;
}
*/



